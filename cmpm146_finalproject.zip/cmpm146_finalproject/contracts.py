"""Canonical cross-module contracts for Adaptive AI Dungeon Master.

All modules should import these types and validators to keep boundary payloads
consistent across narrative policy, resolver, player modeling, DDA, and logging.
"""

from __future__ import annotations

import math
from typing import Any, Literal, TypedDict

BeatType = Literal[
    "exploration",
    "combat",
    "social",
    "mystery",
    "recovery",
    "revelation",
    "travel",
]

ActionType = Literal[
    "attack",
    "defend",
    "talk",
    "investigate",
    "explore",
    "use_item",
    "retreat",
    "wait",
]

ResolutionTier = Literal[
    "favorable",
    "neutral",
    "negative",
]


class SceneSpec(TypedDict, total=False):
    """Canonical scene specification produced by DM policy."""

    scene_id: str
    title: str
    beat_type: BeatType
    template_id: str
    template_group: str
    text_vars: dict[str, Any]
    choices: list[ActionType]
    choice_text: dict[str, str]
    choice_tags: dict[str, list[str]]
    base_risk: dict[str, float]
    effects: dict[str, dict[str, Any]]
    tags: list[str]
    location_id: str
    difficulty: float
    thread_ids: list[str]
    metadata: dict[str, Any]


class Observation(TypedDict, total=False):
    """Canonical player-behavior evidence payload for PlayerModel."""

    choice: ActionType
    choice_tags: list[str]
    risk_level: float
    social_intent: float
    exploration_intent: float
    aggression_signal: float
    success: bool
    failure: bool
    beat_type: BeatType
    resolution_tier: ResolutionTier
    metadata: dict[str, Any]


class Outcome(TypedDict, total=False):
    """Canonical resolver delta payload applied by GameState."""

    player: dict[str, Any]
    inventory_add: list[str]
    inventory_remove: list[str]
    flags: dict[str, bool]
    relationships: dict[str, float]
    tension_delta: float
    plot_threads: list[dict[str, Any]]
    world_facts: dict[str, Any]
    events: list[dict[str, Any]]
    success: bool
    resolution_tier: ResolutionTier
    difficulty_signal: float
    metadata: dict[str, Any]


class TurnRecord(TypedDict, total=False):
    """Structured turn log record written by RunLogger."""

    turn_index: int
    timestamp: str
    beat_type: BeatType
    scene_spec: SceneSpec
    rendered_scene: str
    choice: ActionType
    outcome: Outcome
    observation: Observation
    player_traits: dict[str, float]
    archetype: str
    performance_score: float
    difficulty_target: float
    state_summary: dict[str, Any]


_BEAT_TYPES: frozenset[str] = frozenset(
    {
        "exploration",
        "combat",
        "social",
        "mystery",
        "recovery",
        "revelation",
        "travel",
    }
)

_ACTION_TYPES: frozenset[str] = frozenset(
    {
        "attack",
        "defend",
        "talk",
        "investigate",
        "explore",
        "use_item",
        "retreat",
        "wait",
    }
)

_REQUIRED_SCENE_KEYS: tuple[str, ...] = (
    "scene_id",
    "beat_type",
    "template_id",
    "choices",
    "choice_text",
    "difficulty",
    "tags",
    "location_id",
)

_SCENE_KEYS: frozenset[str] = frozenset(
    {
        "scene_id",
        "title",
        "beat_type",
        "template_id",
        "template_group",
        "text_vars",
        "choices",
        "choice_text",
        "choice_tags",
        "base_risk",
        "effects",
        "tags",
        "location_id",
        "difficulty",
        "thread_ids",
        "metadata",
    }
)

_OBSERVATION_KEYS: frozenset[str] = frozenset(
    {
        "choice",
        "choice_tags",
        "risk_level",
        "social_intent",
        "exploration_intent",
        "aggression_signal",
        "success",
        "failure",
        "beat_type",
        "resolution_tier",
        "metadata",
    }
)

_OUTCOME_KEYS: frozenset[str] = frozenset(
    {
        "player",
        "inventory_add",
        "inventory_remove",
        "flags",
        "relationships",
        "tension_delta",
        "plot_threads",
        "world_facts",
        "events",
        "success",
        "resolution_tier",
        "difficulty_signal",
        "metadata",
    }
)

_RESOLUTION_TIERS: frozenset[str] = frozenset({"favorable", "neutral", "negative"})


def _validate_str_list(values: Any, *, field_name: str, allow_empty: bool = False) -> None:
    if not isinstance(values, list):
        raise TypeError(f"{field_name} must be a list")
    if not allow_empty and not values:
        raise ValueError(f"{field_name} must not be empty")
    for idx, value in enumerate(values):
        if not isinstance(value, str):
            raise TypeError(f"{field_name}[{idx}] must be a str")
        if not value:
            raise ValueError(f"{field_name}[{idx}] must be non-empty")


def _validate_float(value: Any, *, field_name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError(f"{field_name} must be numeric")
    numeric = float(value)
    if not math.isfinite(numeric):
        raise ValueError(f"{field_name} must be finite")
    return numeric


def validate_scene_spec(scene_spec: SceneSpec) -> None:
    """Validate cross-module `SceneSpec` payloads."""
    if not isinstance(scene_spec, dict):
        raise TypeError("scene_spec must be a dict")

    for key in scene_spec:
        if key not in _SCENE_KEYS:
            raise ValueError(f"scene_spec contains unknown key: {key!r}")

    for key in _REQUIRED_SCENE_KEYS:
        if key not in scene_spec:
            raise KeyError(f"scene_spec missing required key: {key!r}")

    for key in ("scene_id", "template_id", "location_id"):
        value = scene_spec[key]
        if not isinstance(value, str):
            raise TypeError(f"scene_spec[{key!r}] must be a str")
        if not value:
            raise ValueError(f"scene_spec[{key!r}] must be non-empty")

    if "title" in scene_spec:
        title = scene_spec["title"]
        if not isinstance(title, str):
            raise TypeError("scene_spec['title'] must be a str")

    beat_type = scene_spec["beat_type"]
    if not isinstance(beat_type, str):
        raise TypeError("scene_spec['beat_type'] must be a str")
    if beat_type not in _BEAT_TYPES:
        raise ValueError(f"scene_spec['beat_type'] is invalid: {beat_type!r}")

    difficulty = _validate_float(scene_spec["difficulty"], field_name="scene_spec['difficulty']")
    if difficulty < 0.0 or difficulty > 1.0:
        raise ValueError("scene_spec['difficulty'] must be in [0.0, 1.0]")

    _validate_str_list(scene_spec["tags"], field_name="scene_spec['tags']", allow_empty=False)

    choices = scene_spec["choices"]
    if not isinstance(choices, list):
        raise TypeError("scene_spec['choices'] must be a list")
    if not choices:
        raise ValueError("scene_spec['choices'] must not be empty")

    seen_choices: set[str] = set()
    for idx, choice in enumerate(choices):
        if not isinstance(choice, str):
            raise TypeError(f"scene_spec['choices'][{idx}] must be a str")
        if choice not in _ACTION_TYPES:
            raise ValueError(f"scene_spec['choices'][{idx}] is invalid: {choice!r}")
        if choice in seen_choices:
            raise ValueError(f"scene_spec['choices'] contains duplicate action: {choice!r}")
        seen_choices.add(choice)

    choice_text = scene_spec["choice_text"]
    if not isinstance(choice_text, dict):
        raise TypeError("scene_spec['choice_text'] must be a dict")
    for action, label in choice_text.items():
        if action not in seen_choices:
            raise ValueError(f"scene_spec['choice_text'] has unknown action key: {action!r}")
        if not isinstance(label, str) or not label:
            raise ValueError(f"scene_spec['choice_text'][{action!r}] must be a non-empty str")

    if "choice_tags" in scene_spec:
        choice_tags = scene_spec["choice_tags"]
        if not isinstance(choice_tags, dict):
            raise TypeError("scene_spec['choice_tags'] must be a dict")
        for action, tags in choice_tags.items():
            if action not in seen_choices:
                raise ValueError(f"scene_spec['choice_tags'] has unknown action key: {action!r}")
            _validate_str_list(tags, field_name=f"scene_spec['choice_tags'][{action!r}]", allow_empty=True)

    if "base_risk" in scene_spec:
        base_risk = scene_spec["base_risk"]
        if not isinstance(base_risk, dict):
            raise TypeError("scene_spec['base_risk'] must be a dict")
        for action, value in base_risk.items():
            if action not in seen_choices:
                raise ValueError(f"scene_spec['base_risk'] has unknown action key: {action!r}")
            risk = _validate_float(value, field_name=f"scene_spec['base_risk'][{action!r}]")
            if risk < 0.0 or risk > 1.0:
                raise ValueError(f"scene_spec['base_risk'][{action!r}] must be in [0.0, 1.0]")

    if "effects" in scene_spec and not isinstance(scene_spec["effects"], dict):
        raise TypeError("scene_spec['effects'] must be a dict")

    if "thread_ids" in scene_spec:
        _validate_str_list(scene_spec["thread_ids"], field_name="scene_spec['thread_ids']", allow_empty=True)

    if "text_vars" in scene_spec and not isinstance(scene_spec["text_vars"], dict):
        raise TypeError("scene_spec['text_vars'] must be a dict")

    if "metadata" in scene_spec and not isinstance(scene_spec["metadata"], dict):
        raise TypeError("scene_spec['metadata'] must be a dict")


def validate_observation(observation: Observation) -> None:
    """Validate cross-module `Observation` payloads."""
    if not isinstance(observation, dict):
        raise TypeError("observation must be a dict")

    for key in observation:
        if key not in _OBSERVATION_KEYS:
            raise ValueError(f"observation contains unknown key: {key!r}")

    if "choice" in observation:
        choice = observation["choice"]
        if not isinstance(choice, str):
            raise TypeError("observation['choice'] must be a str")
        if choice not in _ACTION_TYPES:
            raise ValueError(f"observation['choice'] is invalid: {choice!r}")

    if "choice_tags" in observation:
        _validate_str_list(observation["choice_tags"], field_name="observation['choice_tags']", allow_empty=True)

    for key in ("risk_level", "social_intent", "exploration_intent", "aggression_signal"):
        if key in observation:
            value = _validate_float(observation[key], field_name=f"observation[{key!r}]")
            if value < 0.0 or value > 1.0:
                raise ValueError(f"observation[{key!r}] must be in [0.0, 1.0]")

    for key in ("success", "failure"):
        if key in observation and not isinstance(observation[key], bool):
            raise TypeError(f"observation[{key!r}] must be a bool")

    if "success" in observation and "failure" in observation:
        if observation["success"] == observation["failure"]:
            raise ValueError("observation['success'] and observation['failure'] cannot match")

    if "beat_type" in observation:
        beat_type = observation["beat_type"]
        if not isinstance(beat_type, str):
            raise TypeError("observation['beat_type'] must be a str")
        if beat_type not in _BEAT_TYPES:
            raise ValueError(f"observation['beat_type'] is invalid: {beat_type!r}")

    if "resolution_tier" in observation:
        tier = observation["resolution_tier"]
        if not isinstance(tier, str):
            raise TypeError("observation['resolution_tier'] must be a str")
        if tier not in _RESOLUTION_TIERS:
            raise ValueError(f"observation['resolution_tier'] is invalid: {tier!r}")

    if "metadata" in observation and not isinstance(observation["metadata"], dict):
        raise TypeError("observation['metadata'] must be a dict")


def validate_outcome(outcome: Outcome) -> None:
    """Validate cross-module `Outcome` delta payloads."""
    if not isinstance(outcome, dict):
        raise TypeError("outcome must be a dict")

    for key in outcome:
        if key not in _OUTCOME_KEYS:
            raise ValueError(f"outcome contains unknown key: {key!r}")

    if "player" in outcome:
        player = outcome["player"]
        if not isinstance(player, dict):
            raise TypeError("outcome['player'] must be a dict")
        for name in player:
            if not isinstance(name, str) or not name:
                raise ValueError("outcome['player'] keys must be non-empty strings")

    for key in ("inventory_add", "inventory_remove"):
        if key in outcome:
            _validate_str_list(outcome[key], field_name=f"outcome[{key!r}]", allow_empty=True)

    if "flags" in outcome:
        flags = outcome["flags"]
        if not isinstance(flags, dict):
            raise TypeError("outcome['flags'] must be a dict")
        for flag, value in flags.items():
            if not isinstance(flag, str) or not flag:
                raise ValueError("outcome['flags'] keys must be non-empty strings")
            if not isinstance(value, bool):
                raise TypeError(f"outcome['flags'][{flag!r}] must be bool")

    if "relationships" in outcome:
        relationships = outcome["relationships"]
        if not isinstance(relationships, dict):
            raise TypeError("outcome['relationships'] must be a dict")
        for entity, delta in relationships.items():
            if not isinstance(entity, str) or not entity:
                raise ValueError("outcome['relationships'] keys must be non-empty strings")
            _validate_float(delta, field_name=f"outcome['relationships'][{entity!r}]")

    for key in ("tension_delta", "difficulty_signal"):
        if key in outcome:
            _validate_float(outcome[key], field_name=f"outcome[{key!r}]")

    for key in ("plot_threads", "events"):
        if key in outcome:
            entries = outcome[key]
            if not isinstance(entries, list):
                raise TypeError(f"outcome[{key!r}] must be a list")
            for idx, entry in enumerate(entries):
                if not isinstance(entry, dict):
                    raise TypeError(f"outcome[{key!r}][{idx}] must be a dict")

    if "world_facts" in outcome:
        world_facts = outcome["world_facts"]
        if not isinstance(world_facts, dict):
            raise TypeError("outcome['world_facts'] must be a dict")

    if "success" in outcome and not isinstance(outcome["success"], bool):
        raise TypeError("outcome['success'] must be a bool")

    if "resolution_tier" in outcome:
        tier = outcome["resolution_tier"]
        if not isinstance(tier, str):
            raise TypeError("outcome['resolution_tier'] must be a str")
        if tier not in _RESOLUTION_TIERS:
            raise ValueError(f"outcome['resolution_tier'] is invalid: {tier!r}")

    if "metadata" in outcome and not isinstance(outcome["metadata"], dict):
        raise TypeError("outcome['metadata'] must be a dict")


__all__ = [
    "ActionType",
    "BeatType",
    "Observation",
    "Outcome",
    "ResolutionTier",
    "SceneSpec",
    "TurnRecord",
    "validate_observation",
    "validate_outcome",
    "validate_scene_spec",
]
