"""Procedural consequence-chain story generation for DM follow-up arcs."""

from __future__ import annotations

import re
from typing import Any

from contracts import ActionType, BeatType, SceneSpec

_VALID_BEATS: set[str] = {
    "exploration",
    "combat",
    "social",
    "mystery",
    "recovery",
    "revelation",
    "travel",
}

_ACTION_BASE_RISK: dict[ActionType, float] = {
    "attack": 0.84,
    "defend": 0.42,
    "talk": 0.32,
    "investigate": 0.48,
    "explore": 0.62,
    "use_item": 0.28,
    "retreat": 0.31,
    "wait": 0.18,
}

_ACTION_TAGS: dict[ActionType, list[str]] = {
    "attack": ["combat", "aggressive"],
    "defend": ["combat", "caution"],
    "talk": ["social", "revelation"],
    "investigate": ["mystery", "exploration"],
    "explore": ["exploration", "travel", "risk"],
    "use_item": ["recovery", "resourceful"],
    "retreat": ["travel", "recovery", "caution"],
    "wait": ["recovery", "caution"],
}

_STABILIZING_ACTIONS: set[ActionType] = {"retreat", "wait", "defend", "use_item", "talk", "investigate"}

_FOCUS_PREFERRED_TAGS: set[str] = {
    "vault", "gate", "waystone", "route", "path", "trail", "convoy",
    "caravan", "shrine", "archive", "market", "catacombs", "tunnel",
    "oracle", "siege", "raid", "spy", "courier", "rebel", "beacon", "ledger",
}

_LOCATION_FOCUS_SEEDS: dict[str, tuple[str, ...]] = {
    "crossroads": ("waystone", "route", "beacon", "market", "courier"),
    "glass_marsh": ("tunnel", "catacombs", "oracle"),
    "moonmarket": ("market", "spy", "ledger"),
    "emberkeep": ("gate", "siege", "rebel"),
    "forgotten_archive": ("archive", "oracle", "vault"),
}

_SPATIAL_FOCUS_TAGS: set[str] = {
    "waystone", "route", "path", "trail", "vault", "gate", "convoy",
    "caravan", "shrine", "archive", "market", "catacombs", "tunnel",
    "siege", "raid",
}

_ROMAN_NUMERALS: tuple[str, ...] = (
    "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII",
)

_QUESTLINE_PLANS: dict[str, dict[str, Any]] = {
    "moonmarket": {
        "name": "Moonmarket Conspiracy",
        "thread_ids": ["moonmarket_conspiracy", "eclipse_prophecy"],
        "chapters": [
            {
                "title": "Lantern Debt",
                "beat": "social",
                "focus": "market",
                "hook": "three broker houses demand to know which debt you came to collect, and each one offers a different lie first.",
                "goal": "Choose which broker faction gets your public trust before the street turns against you.",
                "tags": ["market", "social", "broker"],
            },
            {
                "title": "Rooftop Couriers",
                "beat": "travel",
                "focus": "spy",
                "hook": "couriers sprint the slate rooftops with split messages, and one sealed packet carries a map to the hidden exchanges.",
                "goal": "Intercept the true courier trail without exposing your own route through the district.",
                "tags": ["spy", "travel", "courier"],
            },
            {
                "title": "The Hidden Auction",
                "beat": "mystery",
                "focus": "ledger",
                "hook": "beneath a perfumed silk hall, an off-book auction is trading military schedules for relic components.",
                "goal": "Identify the buyer behind the false names before the ledgers are burned.",
                "tags": ["ledger", "mystery", "market"],
            },
            {
                "title": "Bellhour Knives",
                "beat": "combat",
                "focus": "raid",
                "hook": "when the bell tolls, hired blades flood the alley grid and try to pin your allies before witnesses can scatter.",
                "goal": "Break the coordinated strike and keep control of the central lanes.",
                "tags": ["raid", "combat", "market"],
            },
            {
                "title": "The Cipher Vault",
                "beat": "revelation",
                "focus": "vault",
                "hook": "a hidden vault door opens beneath the moon fountain, revealing transaction ciphers tied to royal couriers and rebel financiers.",
                "goal": "Extract proof that links the conspiracy to regional power brokers.",
                "tags": ["vault", "revelation", "ledger"],
            },
            {
                "title": "Masks in the Rain",
                "beat": "social",
                "focus": "spy",
                "hook": "informants gather under rain cloth canopies, each claiming to know who authored the black contracts, but all demand a price.",
                "goal": "Secure one credible witness without letting rival houses rewrite the testimony.",
                "tags": ["spy", "social", "market"],
            },
            {
                "title": "The Broker War",
                "beat": "combat",
                "focus": "market",
                "hook": "open fighting erupts between broker militias, and every stall becomes cover while citizens try to flee the crossfire.",
                "goal": "Decide who holds the square by dawn and prevent mass casualties.",
                "tags": ["market", "combat", "raid"],
            },
            {
                "title": "Midnight Settlement",
                "beat": "revelation",
                "focus": "ledger",
                "hook": "with the ledger chain exposed, the surviving houses gather for a final settlement that can end the conspiracy or bury it deeper.",
                "goal": "Force binding terms that close this network and secure the next route toward Emberkeep.",
                "tags": ["ledger", "revelation", "social"],
            },
        ],
    },
    "emberkeep": {
        "name": "Emberkeep Rebellion",
        "thread_ids": ["emberkeep_rebellion", "eclipse_prophecy"],
        "chapters": [
            {
                "title": "Ashgate Muster",
                "beat": "travel",
                "focus": "gate",
                "hook": "inside Emberkeep, militia lines form at the Ashgate while displaced families crowd the breach lanes.",
                "goal": "Secure a stable entry corridor before command fractures at the walls.",
                "tags": ["gate", "travel", "rebel"],
            },
            {
                "title": "Powder Quarter Whispers",
                "beat": "mystery",
                "focus": "rebel",
                "hook": "powder stores vanish between watch rotations, and every faction blames a different quartermaster.",
                "goal": "Unmask the saboteur cell before the next bombardment begins.",
                "tags": ["rebel", "mystery", "siege"],
            },
            {
                "title": "Banner Hall Ultimatum",
                "beat": "social",
                "focus": "rebel",
                "hook": "captains in Banner Hall demand immediate oaths, and one signature can decide whether the keep fights united or divided.",
                "goal": "Hold the command council together long enough to issue a single battle plan.",
                "tags": ["rebel", "social", "siege"],
            },
            {
                "title": "Red Stair Assault",
                "beat": "combat",
                "focus": "siege",
                "hook": "assault squads push the Red Stairs under boiling pitch and crossbow fire while defenders rotate through collapsing shield lines.",
                "goal": "Seize the stairwell chokepoint and stop the enemy from cutting the keep in two.",
                "tags": ["siege", "combat", "gate"],
            },
            {
                "title": "Underkeep Breach",
                "beat": "exploration",
                "focus": "tunnel",
                "hook": "old smuggler tunnels beneath the keep reopen, offering a dangerous flank route toward the command tower.",
                "goal": "Navigate the underkeep safely and identify which exits are still defensible.",
                "tags": ["tunnel", "exploration", "rebel"],
            },
            {
                "title": "Names on the Oathwall",
                "beat": "revelation",
                "focus": "rebel",
                "hook": "an oathwall ledger reveals which commanders were funded by outside houses and which deaths were planned.",
                "goal": "Expose the traitor bloc and reclaim legitimacy before the final push.",
                "tags": ["rebel", "revelation", "ledger"],
            },
            {
                "title": "Dawnfire Countercharge",
                "beat": "combat",
                "focus": "gate",
                "hook": "at first light, both armies commit reserves to the inner gate and the next charge decides who controls Emberkeep proper.",
                "goal": "Win the countercharge while keeping your command structure intact.",
                "tags": ["gate", "combat", "siege"],
            },
            {
                "title": "Terms at the Ember Throne",
                "beat": "social",
                "focus": "rebel",
                "hook": "with the citadel secured, surviving leaders demand terms, reparations, and arrests before they stand down.",
                "goal": "Settle the rebellion on enforceable terms and prevent a second civil break within the week.",
                "tags": ["rebel", "social", "revelation"],
            },
        ],
    },
}

# --- STATIC LOGIC DICTIONARIES ---

_STAGE_TWO_BEAT_MAP: dict[str, str] = {
    "travel": "mystery", "exploration": "mystery", "mystery": "social",
    "social": "mystery", "combat": "combat", "recovery": "social", "revelation": "revelation",
}

_STAGE_THREE_RECOVERY_BEAT_MAP: dict[str, str] = {
    "travel": "recovery", "exploration": "recovery", "mystery": "social",
    "social": "recovery", "combat": "combat", "recovery": "social", "revelation": "recovery",
}

_STAGE_THREE_BEAT_MAP: dict[str, str] = {
    "travel": "revelation", "exploration": "revelation", "mystery": "revelation",
    "social": "social", "combat": "combat", "recovery": "social", "revelation": "revelation",
}

_STAGE_FOUR_BEAT_MAP: dict[str, str] = {
    "travel": "combat", "exploration": "combat", "mystery": "combat",
    "social": "revelation", "combat": "combat", "recovery": "social", "revelation": "revelation",
}

_ARC_TITLES: dict[BeatType, list[str]] = {
    "travel": ["Forked Paths at Dusk", "Broken Milestones", "Night in the Wrong Valley", "Ridge of No Return", "Dawn at the True Road"],
    "exploration": ["Unmapped Ground", "Signs in the Dust", "Collapsed Passage", "The Last Turning", "A Way Through"],
    "combat": ["First Clash in the Dark", "Pressure at the Line", "Counterstrike Window", "The Hard Hold", "Break or Be Broken"],
    "social": ["Fraying Terms", "Voices at the Edge", "Bargain Under Strain", "Witnesses and Rumors", "Terms of Passage"],
    "recovery": ["Breathing Room, Briefly", "Bandages and Doubt", "A Moment to Regroup", "Quiet Before Motion", "Steady Hands, Moving Feet"],
    "mystery": ["Unfinished Signals", "Marks in the Wrong Place", "Echoes of a False Lead", "Pattern Under Pressure", "The Key Detail"],
    "revelation": ["Truth at a Cost", "The Missing Link", "Names Behind the Mask", "What the Signs Mean", "The Reveal in Full"],
}

_TIER_OPEN_OPTIONS: dict[str, list[str]] = {
    "favorable": ["The opening is yours for a breath, and", "People are finally moving with you, and", "You have a fragile edge right now, and"],
    "neutral": ["Nobody has control yet, and", "Everyone is waiting to see who commits first, and", "The whole scene is balanced on one decision, and"],
    "negative": ["Your group is still off-balance, and", "People are reeling and shouting over each other, and", "Rivals are pressing while you try to recover, and"],
    "default": ["Pressure never really dropped, and", "The next moment is already on top of you, and", "Nothing here is willing to stay still, and"],
}

_CANDIDATE_ACTIONS_MAP: dict[BeatType, list[ActionType]] = {
    "travel": ["investigate", "retreat", "explore", "use_item", "wait", "talk", "defend"],
    "exploration": ["explore", "investigate", "retreat", "use_item", "defend", "talk", "wait"],
    "combat": ["defend", "attack", "wait", "retreat", "talk", "use_item", "investigate"],
    "social": ["talk", "investigate", "retreat", "use_item", "wait", "defend"],
    "recovery": ["wait", "use_item", "talk", "retreat", "investigate", "defend"],
    "mystery": ["investigate", "talk", "use_item", "explore", "retreat", "wait", "defend"],
    "revelation": ["investigate", "talk", "use_item", "defend", "explore", "retreat", "wait"],
}

_ACTION_BEAT_WEIGHTS: dict[BeatType, dict[ActionType, float]] = {
    "travel": {"investigate": 0.9, "retreat": 0.8, "explore": 1.0, "use_item": 0.55, "wait": 0.35, "talk": 0.45, "defend": 0.5, "attack": 0.15},
    "exploration": {"explore": 1.0, "investigate": 0.9, "retreat": 0.65, "use_item": 0.5, "wait": 0.3, "talk": 0.35, "defend": 0.4, "attack": 0.18},
    "combat": {"attack": 1.0, "defend": 0.9, "retreat": 0.7, "talk": 0.35, "use_item": 0.5, "investigate": 0.25, "explore": 0.2, "wait": 0.15},
    "social": {"talk": 1.0, "investigate": 0.8, "retreat": 0.7, "use_item": 0.55, "wait": 0.4, "defend": 0.45, "explore": 0.2, "attack": 0.12},
    "recovery": {"wait": 1.0, "use_item": 0.95, "talk": 0.7, "retreat": 0.6, "investigate": 0.35, "defend": 0.5, "explore": 0.2, "attack": 0.08},
    "mystery": {"investigate": 1.0, "talk": 0.75, "use_item": 0.65, "explore": 0.7, "retreat": 0.5, "wait": 0.4, "defend": 0.35, "attack": 0.1},
    "revelation": {"investigate": 0.9, "talk": 0.85, "use_item": 0.75, "defend": 0.55, "explore": 0.45, "retreat": 0.4, "wait": 0.35, "attack": 0.12},
}


# --- HELPER FUNCTIONS ---

def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))

def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def _safe_str(value: Any) -> str:
    return str(value) if isinstance(value, str) else ""

def _slug(text: str) -> str:
    normalized = "".join(ch if (ch.isalnum() or ch == "_") else "_" for ch in text.lower())
    return re.sub(r"_+", "_", normalized).strip("_") or "arc"

def _stable_pick(options: list[str], key: str) -> str:
    if not options:
        return ""
    idx = sum(ord(ch) for ch in key) % len(options)
    return options[idx]

def _join_story_lines(*parts: str) -> str:
    cleaned = [" ".join(p.split()).strip() for p in parts if " ".join(p.split()).strip()]
    return " ".join(cleaned).strip()


class StoryGenerator:
    """Generate stage-aware branching continuation scenes from follow-up context."""

    def _base_followup_beat(self, followup: dict[str, Any], requested_beat: BeatType) -> BeatType:
        candidate = _safe_str(followup.get("primary_tag"))
        if candidate in _VALID_BEATS:
            return candidate  # type: ignore[return-value]
        return requested_beat

    def _stage(self, followup: dict[str, Any]) -> int:
        depth = max(1, _safe_int(followup.get("depth"), 1))
        # Clamp to a five-step arc to avoid cyclical-feeling resets in long chains.
        return min(depth, 5)

    def _roman(self, value: int) -> str:
        if value <= 0:
            return "I"
        if value <= len(_ROMAN_NUMERALS):
            return _ROMAN_NUMERALS[value - 1]
        return str(value)

    def _questline_context(self, followup: dict[str, Any], location_id: str) -> dict[str, Any] | None:
        followup_location = _safe_str(followup.get("questline_location")).strip()
        plan_location = followup_location if followup_location in _QUESTLINE_PLANS else (location_id if location_id in _QUESTLINE_PLANS else "")
        
        if not plan_location:
            return None

        plan = _QUESTLINE_PLANS[plan_location]
        chapters_raw = plan.get("chapters", [])
        if not isinstance(chapters_raw, list) or not chapters_raw:
            return None

        chapter_depth = max(1, _safe_int(followup.get("depth"), 1))
        chapter_index = min(chapter_depth, len(chapters_raw))
        chapter_payload = chapters_raw[chapter_index - 1]
        if not isinstance(chapter_payload, dict):
            return None

        beat_type = _safe_str(chapter_payload.get("beat")) or "mystery"
        if beat_type not in _VALID_BEATS:
            beat_type = "mystery"

        chapter_focus = _safe_str(chapter_payload.get("focus")).strip().lower()
        chapter_title = _safe_str(chapter_payload.get("title")).strip() or f"Turning Point {chapter_index}"
        chapter_hook = _safe_str(chapter_payload.get("hook")).strip()
        chapter_goal = _safe_str(chapter_payload.get("goal")).strip()
        chapter_tags = [t.strip().lower() for t in chapter_payload.get("tags", []) if isinstance(t, str) and t.strip()]
        thread_ids = [t for t in plan.get("thread_ids", []) if isinstance(t, str) and t]

        questline_name = _safe_str(plan.get("name")).strip() or plan_location.replace("_", " ").title()
        
        return {
            "location_id": plan_location,
            "name": questline_name,
            "chapter_index": chapter_index,
            "total_chapters": len(chapters_raw),
            "beat_type": beat_type,
            "focus": chapter_focus,
            "chapter_title": chapter_title,
            "chapter_hook": chapter_hook,
            "chapter_goal": chapter_goal,
            "chapter_tags": chapter_tags,
            "thread_ids": thread_ids,
        }

    def _questline_title(self, questline_name: str, chapter_index: int, chapter_title: str) -> str:
        return f"Chapter {self._roman(chapter_index)}: {chapter_title}"

    def _questline_chapter_line(self, questline_name: str, chapter_index: int, total_chapters: int) -> str:
        return (
            f"{questline_name} chapter {self._roman(chapter_index)} of {total_chapters}."
            " The city remembers every move from this point."
        )

    def _questline_hook(self, chapter_hook: str, source_tier: str) -> str:
        prefix = {
            "favorable": "With momentum still behind you,",
            "neutral": "With the district holding its breath,",
            "negative": "With the last setback still fresh,",
        }.get(source_tier, "With pressure building,")
        
        clean_hook = chapter_hook.strip()
        return f"{prefix} {clean_hook}" if clean_hook else f"{prefix} the next chapter starts under unstable terms."

    def _beat_for_followup(self, followup: dict[str, Any], requested_beat: BeatType, state: Any) -> BeatType:
        base = self._base_followup_beat(followup, requested_beat)
        stage = self._stage(followup)
        source_tier = _safe_str(followup.get("source_tier")) or "neutral"
        health = _safe_int(getattr(getattr(state, "player", object()), "health", 100), 100)

        if stage <= 1:
            return base
        if stage == 2:
            return _STAGE_TWO_BEAT_MAP.get(base, base)  # type: ignore[return-value]
        if stage == 3:
            return _STAGE_THREE_RECOVERY_BEAT_MAP.get(base, base) if source_tier == "negative" else _STAGE_THREE_BEAT_MAP.get(base, base)  # type: ignore[return-value]
        if stage == 4:
            if health < 60:
                return "recovery"
            return _STAGE_FOUR_BEAT_MAP.get(base, base)  # type: ignore[return-value]

        # Stage 5 is the payoff/transition beat.
        if health < 70:
            return "recovery"
        if source_tier == "favorable":
            return "revelation"
        if base in {"social", "mystery"}:
            return "social"
        return "travel"

    def _arc_title(self, beat_type: BeatType, stage: int, key: str) -> str:
        choices = _ARC_TITLES.get(beat_type, _ARC_TITLES["mystery"])
        return choices[stage - 1] if stage <= len(choices) else _stable_pick(choices, key)

    def _definite(self, phrase: str) -> str:
        clean = phrase.strip()
        if not clean:
            return ""
        lower = clean.lower()
        return clean if lower.startswith(("the ", "a ", "an ")) else f"the {clean}"

    def _focus_terms(self, focus_label: str) -> tuple[str, str]:
        clean = focus_label.strip()
        if not clean:
            return "the situation", "the situation"

        focus_slug = _slug(clean)
        subject = self._definite(clean)

        if focus_slug in _SPATIAL_FOCUS_TAGS:
            return subject, subject

        route_focus = f"the trail tied to {subject}"
        return route_focus, subject

    def _arc_hook(
        self,
        *,
        beat_type: BeatType,
        stage: int,
        focus_label: str,
        source_tier: str,
        npc_goal: str,
        key: str,
    ) -> str:
        normalized_focus = focus_label.strip().lower()
        travel_focus, subject_focus = self._focus_terms(focus_label)
        if normalized_focus in {"route", "path", "trail"}:
            travel_focus = "the surrounding ground"

        tier_open = _stable_pick(
            _TIER_OPEN_OPTIONS.get(source_tier, _TIER_OPEN_OPTIONS["default"]),
            f"{key}:{beat_type}:{stage}:{source_tier}:tier_open",
        )

        stage_lines = []
        if beat_type in {"travel", "exploration"}:
            stage_lines = [
                f"{tier_open} a cart wheel snaps near {travel_focus} and the lead wagon jackknifes across the path. Animals scream, cargo spills, and everyone looks at you for the next command.",
                f"{tier_open} cairns near {travel_focus} point in opposite directions, and your guide swears the landmarks were different an hour ago.",
                f"{tier_open} the trail around {travel_focus} turns to mud and broken stone, and each hurried step risks another injury.",
                f"{tier_open} a rope bridge near {travel_focus} frays under your weight and starts to fail mid-crossing.",
                f"{tier_open} a narrow pass opens beyond {travel_focus}; it is your best chance, but it could close behind you.",
            ]
        elif beat_type == "combat":
            stage_lines = [
                f"{tier_open} a man in the crowd lunges at you with a knife near {subject_focus}. The blade flashes up from his sleeve with almost no warning.",
                f"{tier_open} two raiders crash through the line near {subject_focus}, and one is already winding up for a killing strike.",
                f"{tier_open} crossbow bolts crack past your ear around {subject_focus}, and the next second decides whether the line holds.",
                f"{tier_open} the enemy champion breaks through near {subject_focus} and charges straight at you.",
                f"{tier_open} steel rings out around {subject_focus}, and one decisive move can end the exchange right now.",
            ]
        elif beat_type == "social":
            stage_lines = [
                f"{tier_open} a furious merchant shoves through the crowd around {subject_focus} and points straight at you, demanding answers in front of everyone.",
                f"{tier_open} rumors around {subject_focus} split the room into shouting factions, and every eye is on your reaction.",
                f"{tier_open} a courier arrives breathless at {subject_focus} with a blood-stained message and refuses to hand it to anyone else.",
                f"{tier_open} allies around {subject_focus} begin arguing over command, and one more insult could turn this into open conflict.",
                f"{tier_open} you have one chance to control the room around {subject_focus} before it tears itself apart.",
            ]
        elif beat_type == "recovery":
            stage_lines = [
                f"{tier_open} the noise drops around {subject_focus} and you finally get a heartbeat to treat wounds and count who's still standing.",
                f"{tier_open} your group slumps against stone and wagons around {subject_focus}, but everyone is waiting for your next call.",
                f"{tier_open} you can stabilize here around {subject_focus}, if nobody panics and breaks formation.",
                f"{tier_open} this is the last quiet pocket near {subject_focus} before danger rolls back in.",
                f"{tier_open} breath returns around {subject_focus}, and discipline now can save lives later.",
            ]
        else: # mystery/revelation
            lead = "and tension spikes." if npc_goal == "assert_control" else "and answers feel close."
            stage_lines = [
                f"{tier_open} you notice fresh blood where there should be dust around {subject_focus}, and someone nearby is lying to your face {lead}",
                f"{tier_open} three details around {subject_focus} suddenly match, and they all point to the same hidden actor.",
                f"{tier_open} the evidence around {subject_focus} almost fits, but one bad assumption could send you into a trap.",
                f"{tier_open} the pattern around {subject_focus} is visible for a moment, if you test it before it is scrubbed.",
                f"{tier_open} the truth around {subject_focus} is finally close enough to grab, but only if you move now.",
            ]

        idx = min(stage, len(stage_lines)) - 1
        return stage_lines[idx]

    def _arc_goal_line(self, beat_type: BeatType, stage: int, focus_label: str, source_tier: str) -> str:
        _, subject_focus = self._focus_terms(focus_label)
        if stage == 1:
            return f"Right now the goal is simple: survive the immediate fallout around {subject_focus} and keep initiative."
        if stage == 2:
            return f"You need a clean read on what is happening around {subject_focus} before your rivals set the narrative."
        if stage == 3:
            return f"The story turns here; what you prove around {subject_focus} decides whether this remains a setback or becomes leverage."
        if stage == 4:
            if source_tier == "negative":
                return f"You are out of buffer. A wrong move around {subject_focus} now can fracture the entire operation."
            return f"This is the pressure point. If you hold control around {subject_focus}, you can force the next chapter on your terms."
        
        if beat_type == "recovery":
            return "This is your chance to consolidate gains and keep everyone alive long enough to act on what you have learned."
        if beat_type == "revelation":
            return f"The pieces are finally aligning; if you capitalize now, the truth around {subject_focus} can rewrite who holds power."
        if beat_type == "social":
            return "The next exchange decides whether people follow you by trust, fear, or not at all."
        return "The next move will decide whether this chain closes in your favor or opens a wider crisis."

    def _action_score(
        self,
        *,
        action: ActionType,
        beat_type: BeatType,
        stage: int,
        source_tier: str,
        aggression: float,
        caution: float,
        exploration: float,
        social: float,
        npc_goal: str,
    ) -> float:
        base = _ACTION_BEAT_WEIGHTS.get(beat_type, _ACTION_BEAT_WEIGHTS["mystery"]).get(action, 0.1)

        trait_delta = 0.0
        if action == "attack":
            trait_delta += aggression * 0.55 - caution * 0.2
        elif action == "defend":
            trait_delta += caution * 0.45
        elif action == "talk":
            trait_delta += social * 0.5
        elif action == "investigate":
            trait_delta += exploration * 0.36 + caution * 0.12
        elif action == "explore":
            trait_delta += exploration * 0.44 + aggression * 0.1 - caution * 0.08
        elif action == "retreat":
            trait_delta += caution * 0.4
        elif action == "wait":
            trait_delta += caution * 0.35
        elif action == "use_item":
            trait_delta += caution * 0.2 + social * 0.05

        stage_delta = 0.0
        if stage >= 3 and action in _STABILIZING_ACTIONS:
            stage_delta += 0.08
        if stage >= 4 and action == "investigate":
            stage_delta += 0.08
        if source_tier == "negative" and action in _STABILIZING_ACTIONS:
            stage_delta += 0.12
        if source_tier == "favorable" and action in {"explore", "attack"}:
            stage_delta += 0.1

        npc_delta = 0.0
        if npc_goal == "build_trust" and action == "talk":
            npc_delta += 0.16
        elif npc_goal == "offer_safety" and action in {"retreat", "defend", "wait"}:
            npc_delta += 0.14
        elif npc_goal == "assert_control" and action in {"attack", "defend"}:
            npc_delta += 0.14
        elif npc_goal == "trade_information" and action == "investigate":
            npc_delta += 0.12

        return base + trait_delta + stage_delta + npc_delta

    def _select_actions(
        self,
        *,
        beat_type: BeatType,
        stage: int,
        source_tier: str,
        traits: dict[str, float],
        npc_goal: str,
        key: str,
    ) -> list[ActionType]:
        candidates = _CANDIDATE_ACTIONS_MAP.get(beat_type, _CANDIDATE_ACTIONS_MAP["mystery"])
        aggression = _clamp(float(traits.get("aggression", 0.5)))
        caution = _clamp(float(traits.get("caution", 0.5)))
        exploration = _clamp(float(traits.get("exploration", 0.5)))
        social = _clamp(float(traits.get("social", 0.5)))

        scored = [
            (
                self._action_score(
                    action=action, beat_type=beat_type, stage=stage, source_tier=source_tier,
                    aggression=aggression, caution=caution, exploration=exploration,
                    social=social, npc_goal=npc_goal,
                ),
                action,
            )
            for action in candidates
        ]
        scored.sort(key=lambda pair: pair[0], reverse=True)

        selected: list[ActionType] = []
        for _, action in scored:
            if action not in selected:
                selected.append(action)
            if len(selected) == 3:
                break

        # Guarantee at least one stabilizing option in prolonged/negative arcs.
        if (stage >= 3 or source_tier == "negative") and not any(a in _STABILIZING_ACTIONS for a in selected):
            for action in ("retreat", "defend", "wait"):
                if action in candidates:
                    selected[-1] = action  # replace the weakest chosen option
                    break

        # Deterministic tie-break shuffle for same option scores across runs.
        seed_offset = sum(ord(ch) for ch in key) % 3
        if len(selected) == 3:
            if seed_offset == 1:
                selected[1], selected[2] = selected[2], selected[1]
            elif seed_offset == 2:
                selected[0], selected[1] = selected[1], selected[0]

        return selected

    def _choice_text(
        self,
        action: ActionType,
        focus_label: str,
        beat_type: BeatType,
        stage: int,
        npc_goal: str,
        key: str,
    ) -> str:
        route_focus, subject_focus = self._focus_terms(focus_label)
        if beat_type == "combat":
            options: dict[ActionType, list[str]] = {
                "defend": ["Duck under the strike and guard your head.", "Raise your guard and absorb the first hit.", "Drop low, protect your core, and weather the attack."],
                "attack": ["Try to grab the knife hand and wrench it away.", "Lunge first and strike before the next swing.", "Drive forward and force the attacker back."],
                "wait": ["Freeze and accept your fate.", "Hold still and trust pure luck.", "Do nothing and pray the blow misses."],
                "retreat": ["Dive backward and make space.", "Break contact and fall back two steps.", "Disengage fast before you get surrounded."],
                "talk": ["Shout for them to stop and buy one heartbeat.", "Call out a warning and try to break their focus.", "Yell a command to reset your line."],
                "use_item": ["Rip out a tool and improvise a defense.", "Throw a gadget to disrupt the attack.", "Use a supply now to survive this exchange."],
                "investigate": ["Watch their footing and wait for a tell.", "Read their pattern before you commit.", "Track the attacker’s shoulders to predict the next strike."],
                "explore": ["Side-step into a new angle and force a better position.", "Slip around the flank to open space.", "Move through the chaos and create a route out."],
            }
            return _stable_pick(options[action], f"{key}:{action}:{beat_type}:{stage}:{npc_goal}")

        if beat_type in {"travel", "exploration"}:
            investigate_opts = [f"Read the tracks around {route_focus} before anyone moves.", f"Check landmarks near {route_focus} and choose a safer line.", f"Test the ground around {route_focus} for hidden danger."]
            explore_opts = [f"Push through {route_focus} before the window closes.", f"Take the bold route across {route_focus} right now.", f"Move fast through {route_focus} and force progress."]
        elif beat_type in {"mystery", "revelation"}:
            investigate_opts = [f"Check the evidence around {subject_focus} before it disappears.", "Press the witness and test your best theory now.", f"Trace the clue chain around {subject_focus} one step at a time."]
            explore_opts = [f"Follow the strongest lead around {subject_focus} before it goes cold.", f"Chase the next clue around {subject_focus} immediately.", f"Commit to one lead around {subject_focus} and run it down."]
        else:
            investigate_opts = [f"Read the room around {subject_focus} before you act.", f"Scan for weak points around {subject_focus}.", f"Check what is changing around {subject_focus} first."]
            explore_opts = [f"Push toward {subject_focus} and seize initiative.", f"Move now around {subject_focus} before rivals react.", f"Force progress around {subject_focus}, risk and all."]

        talk_opts = ["Talk them down before this gets worse.", "Call for calm and force one clear plan.", "Speak up now and keep the group from splitting."]
        if npc_goal == "assert_control":
            talk_opts[0] = "Take command now and shut the argument down."

        action_options: dict[ActionType, list[str]] = {
            "investigate": investigate_opts,
            "retreat": ["Fall back to the last safe position.", "Pull everyone back and regroup.", "Withdraw now before this gets worse."],
            "explore": explore_opts,
            "talk": talk_opts,
            "attack": ["Hit first and try to break the threat.", "Commit to a hard strike and seize momentum.", "Charge and force the danger to react to you."],
            "defend": ["Duck and cover the vulnerable.", "Hold your ground and absorb the next hit.", "Brace and keep the line from breaking."],
            "use_item": ["Use a tool now to tilt the odds.", "Burn supplies to stabilize the moment.", "Commit resources for one clean advantage."],
            "wait": ["Hold still for one heartbeat and read the pattern.", "Wait and let the danger show its hand.", "Do nothing for a moment and watch carefully."],
        }
        return _stable_pick(
            action_options.get(action, [action.replace("_", " ").title()]),
            f"{key}:{action}:{beat_type}:{stage}:{npc_goal}",
        )

    def _choice_tags(self, action: ActionType, beat_type: BeatType) -> list[str]:
        tags = list(_ACTION_TAGS.get(action, []))
        if beat_type not in tags:
            tags.append(beat_type)
        return tags

    def _base_risk(self, action: ActionType, *, stage: int, source_tier: str, difficulty_target: float) -> float:
        base = _ACTION_BASE_RISK[action]
        stage_delta = (stage - 1) * 0.05
        tier_delta = 0.08 if source_tier == "negative" else (-0.04 if source_tier == "favorable" else 0.0)
        target_delta = (difficulty_target - 0.5) * 0.18
        return _clamp(base + stage_delta + tier_delta + target_delta, 0.08, 0.95)

    def _effects(
        self,
        *,
        actions: list[ActionType],
        thread_ids: list[str],
        focus_slug: str,
        stage: int,
        beat_type: BeatType,
        chapter_index: int,
        final_chapter: int,
        allow_early_exit: bool,
    ) -> dict[str, dict[str, Any]]:
        effects: dict[str, dict[str, Any]] = {}
        focus_key = focus_slug or "arc"
        exit_ready = chapter_index >= final_chapter

        for action in actions:
            favorable_world_key = f"{focus_key}_stage_{stage}_{action}_gain"
            neutral_world_key = f"{focus_key}_stage_{stage}_{action}_partial"
            unfavorable_world_key = f"{focus_key}_stage_{stage}_{action}_setback"

            progress_gain = min(0.18, 0.05 + stage * 0.03)
            health_cost = -int(round(3 + stage * 1.8 + (_ACTION_BASE_RISK[action] * 4.0)))
            tension_gain = round(0.03 + stage * 0.02 + (_ACTION_BASE_RISK[action] * 0.05), 3)
            tension_relief = round(max(0.01, 0.05 - (stage * 0.006)), 3)

            on_favorable: dict[str, Any] = {
                "world_facts": {
                    favorable_world_key: True,
                    "arc_exit_hint": exit_ready or (allow_early_exit and action in _STABILIZING_ACTIONS and chapter_index >= 3),
                },
                "tension_delta": -tension_relief if beat_type in {"recovery", "social", "travel"} else 0.01,
            }
            if thread_ids:
                on_favorable["plot_threads"] = [{"thread_id": tid, "progress_delta": progress_gain} for tid in thread_ids]
            if action in {"wait", "use_item", "defend"}:
                on_favorable["player"] = {"health_delta": min(10, 2 + stage * 2)}

            on_neutral: dict[str, Any] = {
                "world_facts": {
                    neutral_world_key: True,
                    "arc_exit_hint": exit_ready and action in _STABILIZING_ACTIONS,
                },
                "tension_delta": round(tension_gain * 0.35, 3),
            }
            if action in {"investigate", "talk"} and thread_ids:
                on_neutral["plot_threads"] = [{"thread_id": thread_ids[0], "progress_delta": round(progress_gain * 0.5, 3)}]

            on_negative: dict[str, Any] = {
                "world_facts": {
                    unfavorable_world_key: True,
                    "arc_exit_hint": exit_ready,
                },
                "player": {"health_delta": health_cost},
                "tension_delta": tension_gain,
            }

            effects[action] = {
                "on_favorable": on_favorable,
                "on_neutral": on_neutral,
                "on_negative": on_negative,
            }

        return effects

    def generate_followup_scene(
        self,
        *,
        state: Any,
        followup: dict[str, Any],
        requested_beat: BeatType,
        player_model: Any,
        dda: Any,
        npc_context: dict[str, Any],
    ) -> SceneSpec:
        """Create a dynamic continuation scene for an active consequence arc."""
        source_tier = _safe_str(followup.get("source_tier")) or "neutral"
        source_scene = _safe_str(followup.get("source_scene")) or "prior event"
        location_id = _safe_str(followup.get("required_location")) or str(
            getattr(getattr(state, "player", object()), "location_id", "crossroads")
        )
        
        questline = self._questline_context(followup, location_id)

        if questline is not None:
            location_id = str(questline["location_id"])
            chapter_index = int(questline["chapter_index"])
            total_chapters = int(questline["total_chapters"])
            stage = min(chapter_index, 5)
            beat_type = str(questline["beat_type"])
        else:
            beat_type = self._beat_for_followup(followup, requested_beat, state)
            stage = self._stage(followup)
            chapter_index = stage
            total_chapters = 5

        active_entity = _safe_str(followup.get("active_entity")).strip().lower()
        active_entity_location = _safe_str(followup.get("active_entity_location")).strip()
        active_entity_chapter = max(0, _safe_int(followup.get("active_entity_chapter"), 0))
        
        location_transition = bool(active_entity_location and location_id and active_entity_location != location_id)
        chapter_transition = bool(chapter_index > 0 and chapter_index != active_entity_chapter)
        allow_entity_refresh = location_transition or chapter_transition

        focus = active_entity if (active_entity and not allow_entity_refresh) else _safe_str(followup.get("focus")).strip().lower()
        
        if questline is not None:
            chapter_focus = _safe_str(questline.get("focus")).strip().lower()
            if chapter_focus and (not active_entity or allow_entity_refresh):
                focus = chapter_focus

        if not focus:
            required_tags = [t for t in followup.get("required_tags", []) if isinstance(t, str)]
            preferred_focus = next((t for t in required_tags if t in _FOCUS_PREFERRED_TAGS), "")
            if preferred_focus:
                focus = preferred_focus
            elif source_scene:
                for token in _FOCUS_PREFERRED_TAGS:
                    if token in source_scene.lower():
                        focus = token
                        break

        if not focus:
            focus = "route" if beat_type in {"travel", "exploration"} else beat_type

        if active_entity and not allow_entity_refresh:
            focus = active_entity
        elif questline is None and stage >= 3 and focus in {"waystone", "route", "path", "trail"}:
            location_focus = _LOCATION_FOCUS_SEEDS.get(location_id, ())
            if location_focus:
                focus = _stable_pick(list(location_focus), f"{location_id}:{stage}:{source_scene}")

        focus_label = focus.replace("_", " ")
        focus_slug = _slug(focus)
        chain_id = _safe_str(followup.get("chain_id")) or f"{source_scene}:{focus_slug}"
        branch_signature = _safe_str(followup.get("branch_signature"))
        key = f"{chain_id}:{chapter_index}:{branch_signature}:{beat_type}"

        thread_ids = [tid for tid in followup.get("required_thread_ids", []) if isinstance(tid, str) and tid]
        if questline is not None:
            thread_ids.extend(tid for tid in questline.get("thread_ids", []) if isinstance(tid, str) and tid and tid not in thread_ids)
            
        if not thread_ids:
            if questline is not None:
                thread_ids = [tid for tid in questline.get("thread_ids", []) if isinstance(tid, str) and tid]
            if not thread_ids:
                thread_ids = list(getattr(getattr(state, "narrative", object()), "active_thread_ids", []))[:2]

        traits = player_model.trait_vector()
        difficulty_target = _clamp(float(dda.difficulty_target()))
        npc_goal = _safe_str(npc_context.get("goal")) or "trade_information"
        npc_tone = _safe_str(npc_context.get("tone")) or "measured"
        branch_hook = _safe_str(followup.get("branch_hook")).strip()
        branch_goal = _safe_str(followup.get("branch_goal")).strip()
        continuity_line = _safe_str(followup.get("narrative")).strip()

        chapter_line = ""
        questline_name = ""
        chapter_tags: list[str] = []
        
        if questline is not None:
            questline_name = _safe_str(questline.get("name")).strip() or location_id.replace("_", " ").title()
            chapter_title = _safe_str(questline.get("chapter_title")) or f"Turning Point {chapter_index}"
            chapter_hook = _safe_str(questline.get("chapter_hook"))
            chapter_goal = _safe_str(questline.get("chapter_goal"))
            chapter_tags = [t for t in questline.get("chapter_tags", []) if isinstance(t, str) and t]
            title = self._questline_title(questline_name, chapter_index, chapter_title)
            hook = self._questline_hook(chapter_hook, source_tier)
            goal_line = chapter_goal or self._arc_goal_line(beat_type, stage, focus_label, source_tier)
            chapter_line = self._questline_chapter_line(questline_name, chapter_index, total_chapters)
        else:
            title = self._arc_title(beat_type, stage, key)
            hook = self._arc_hook(
                beat_type=beat_type, stage=stage, focus_label=focus_label,
                source_tier=source_tier, npc_goal=npc_goal, key=key,
            )
            goal_line = self._arc_goal_line(beat_type, stage, focus_label, source_tier)

        if branch_hook and not continuity_line:
            hook = _join_story_lines(branch_hook, hook)

        if branch_goal:
            goal_line = _join_story_lines(branch_goal, goal_line) if questline is not None else branch_goal

        choices = self._select_actions(
            beat_type=beat_type, stage=stage, source_tier=source_tier,
            traits=traits, npc_goal=npc_goal, key=key,
        )
        
        choice_text = {a: self._choice_text(a, focus_label, beat_type, stage, npc_goal, key) for a in choices}
        choice_tags = {a: self._choice_tags(a, beat_type) for a in choices}
        base_risk = {a: self._base_risk(a, stage=stage, source_tier=source_tier, difficulty_target=difficulty_target) for a in choices}
        
        effects = self._effects(
            actions=choices, thread_ids=thread_ids, focus_slug=focus_slug,
            stage=stage, beat_type=beat_type, chapter_index=chapter_index,
            final_chapter=total_chapters, allow_early_exit=(questline is None),
        )

        health = _safe_int(getattr(getattr(state, "player", object()), "health", 100), 100)
        
        if questline is not None:
            stage_difficulty = _clamp(
                0.32 + difficulty_target * 0.34 + chapter_index * 0.025 
                + (0.06 if source_tier == "negative" else (-0.04 if source_tier == "favorable" else 0.0)) 
                + (-0.06 if health < 70 else 0.0), 0.18, 0.9
            )
        else:
            stage_difficulty = _clamp(
                0.35 + difficulty_target * 0.35 + stage * 0.07 
                + (0.07 if source_tier == "negative" else (-0.05 if source_tier == "favorable" else 0.0)), 0.18, 0.92
            )

        turn_index = _safe_int(getattr(getattr(state, "narrative", object()), "turn_index", 0), 0)
        scene_id = f"chain_{_slug(chain_id)}_chapter_{chapter_index}_{turn_index}" if questline is not None else f"chain_{_slug(chain_id)}_stage_{stage}_{turn_index}"

        text_vars: dict[str, Any] = {
            "continuity_line": continuity_line,
            "hook": hook,
            "goal_line": goal_line,
            "npc_goal": npc_goal,
            "npc_tone": npc_tone,
            "active_entity": focus_label,
            "previous_location": _safe_str(followup.get("previous_location")),
            "last_player_action": _safe_str(followup.get("player_action")),
            "last_player_action_label": _safe_str(followup.get("player_action_label")),
            "action_success_level": _safe_str(followup.get("resolution_tier")) or source_tier,
            "dda_event_triggered": _safe_str(followup.get("dda_event_triggered")),
            "source_entity": _safe_str(followup.get("source_entity")) or focus_label,
            "current_location": location_id,
        }
        if chapter_line:
            text_vars["chapter_line"] = chapter_line

        raw_tags = [beat_type, "consequence", "progression", focus_slug]
        if questline is not None:
            raw_tags.extend(["questline", location_id, f"chapter_{chapter_index}", f"questline_{location_id}"])
            raw_tags.extend(chapter_tags)
        else:
            raw_tags.append(f"stage_{stage}")

        tags: list[str] = []
        for token in raw_tags:
            if isinstance(token, str) and token.strip() and token.strip().lower() not in tags:
                tags.append(token.strip().lower())

        metadata: dict[str, Any] = {
            "generated_followup": True,
            "followup": followup,
            "progression_mode": "direct_consequence",
            "arc_stage": stage,
            "arc_chain_id": chain_id,
            "active_entity": focus,
            "active_entity_locked": bool(active_entity and not allow_entity_refresh),
            "npc_context": npc_context,
            "questline_location": location_id if questline is not None else "",
            "questline_name": questline_name,
            "questline_chapter": chapter_index if questline is not None else 0,
            "questline_total_chapters": total_chapters if questline is not None else 0,
        }

        scene_spec: SceneSpec = {
            "scene_id": scene_id,
            "title": title,
            "beat_type": beat_type,
            "template_id": "dynamic_followup",
            "text_vars": text_vars,
            "choices": choices,
            "choice_text": choice_text,
            "choice_tags": choice_tags,
            "base_risk": base_risk,
            "effects": effects,
            "tags": tags,
            "location_id": location_id,
            "difficulty": stage_difficulty,
            "thread_ids": thread_ids,
            "metadata": metadata,
        }
        return scene_spec