"""NPC decision agent with optional GOAP planning."""

from __future__ import annotations

from typing import Any

from ai.goap import GOAPPlanner


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


class NPCAgent:
    """Select NPC intent and optional action plan for a given scene context."""

    def __init__(self, planner: GOAPPlanner | None = None) -> None:
        self._planner = planner or GOAPPlanner()

    def decide(self, state: Any, player_model: Any) -> dict[str, Any]:
        """Return an NPC decision artifact based on state and player traits."""
        narrative = getattr(state, "narrative", object())
        tension = _clamp(float(getattr(narrative, "tension", 0.3)))
        traits = player_model.trait_vector()

        aggression = _clamp(float(traits.get("aggression", 0.5)))
        social = _clamp(float(traits.get("social", 0.5)))
        caution = _clamp(float(traits.get("caution", 0.5)))

        if tension > 0.7 and aggression > 0.55:
            goal = "assert_control"
            tone = "tense"
        elif social > 0.65:
            goal = "build_trust"
            tone = "warm"
        elif caution > 0.65:
            goal = "offer_safety"
            tone = "careful"
        else:
            goal = "trade_information"
            tone = "measured"

        actions = [
            {
                "id": "observe_player",
                "preconditions": {},
                "effects": {"intel": True},
                "cost": 1.0,
            },
            {
                "id": "offer_hint",
                "preconditions": {"intel": True},
                "effects": {"trust": True},
                "cost": 1.2,
            },
            {
                "id": "set_condition",
                "preconditions": {"intel": True},
                "effects": {"leverage": True},
                "cost": 1.1,
            },
            {
                "id": "forge_pact",
                "preconditions": {"trust": True},
                "effects": {"alliance": True},
                "cost": 1.6,
            },
        ]

        goal_facts = {
            "build_trust": {"alliance": True},
            "offer_safety": {"trust": True},
            "trade_information": {"intel": True},
            "assert_control": {"leverage": True},
        }.get(goal, {"intel": True})

        plan = self._planner.plan(start_facts={}, goal_facts=goal_facts, actions=actions)

        return {
            "goal": goal,
            "tone": tone,
            "plan": plan,
            "tension": round(tension, 3),
        }
