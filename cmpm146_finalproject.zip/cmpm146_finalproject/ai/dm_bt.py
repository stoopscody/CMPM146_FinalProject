"""Behavior-tree-like beat selector for narrative pacing."""

from __future__ import annotations

from typing import Any

from contracts import BeatType


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


class DMBT:
    """Select the next beat type from pacing/tension/adaptation signals.

    The selector uses weighted priorities rather than a full BT library to keep
    the project compact while preserving behavior-tree style decision ordering.
    """

    def __init__(self) -> None:
        self._beats: tuple[BeatType, ...] = (
            "exploration",
            "combat",
            "social",
            "mystery",
            "recovery",
            "revelation",
            "travel",
        )

    def choose_beat(self, state: Any, player_model: Any, dda: Any) -> BeatType:
        """Choose high-level narrative beat based on state/model/dda signals."""
        current_turn = int(getattr(getattr(state, "narrative", object()), "turn_index", 0))
        tension = _clamp(float(getattr(getattr(state, "narrative", object()), "tension", 0.3)))
        health = int(getattr(getattr(state, "player", object()), "health", 100))
        recent_beats = list(getattr(getattr(state, "narrative", object()), "beat_history", []))[-3:]
        world_facts = getattr(state, "world_facts", {})

        traits = player_model.trait_vector()
        aggression = _clamp(float(traits.get("aggression", 0.5)))
        caution = _clamp(float(traits.get("caution", 0.5)))
        exploration = _clamp(float(traits.get("exploration", 0.5)))
        social = _clamp(float(traits.get("social", 0.5)))

        difficulty_target = _clamp(float(dda.difficulty_target()))
        unresolved_threads = len(getattr(getattr(state, "narrative", object()), "active_thread_ids", []))

        scores: dict[BeatType, float] = {
            "exploration": 0.45 + (1.0 - tension) * 0.4 + exploration * 0.35,
            "combat": 0.35 + tension * 0.5 + aggression * 0.4 + difficulty_target * 0.3,
            "social": 0.3 + social * 0.5 + (1.0 - tension) * 0.25,
            "mystery": 0.35 + exploration * 0.3 + unresolved_threads * 0.08,
            "recovery": 0.25 + caution * 0.45 + tension * 0.2 + (1.0 - difficulty_target) * 0.25,
            "revelation": 0.2 + tension * 0.45 + unresolved_threads * 0.12,
            "travel": 0.22 + exploration * 0.25 + (1.0 - tension) * 0.2,
        }

        # Priority ordering and novelty control: penalize very recent beats.
        for beat in recent_beats:
            if beat in scores:
                scores[beat] -= 0.25

        if len(recent_beats) >= 2 and recent_beats[-1] == recent_beats[-2]:
            repeated = recent_beats[-1]
            scores[repeated] -= 0.65
            scores["recovery"] += 0.22
            scores["social"] += 0.18

        if tension > 0.78:
            scores["combat"] += 0.18
            scores["revelation"] += 0.12
            scores["recovery"] -= 0.08

        if tension < 0.25:
            scores["exploration"] += 0.12
            scores["social"] += 0.08
            scores["travel"] += 0.1

        if caution > 0.7 and aggression < 0.4:
            scores["combat"] -= 0.12
            scores["recovery"] += 0.16

        if health < 70:
            deficit = _clamp((70.0 - float(health)) / 70.0, 0.0, 1.0)
            scores["recovery"] += 0.28 + (deficit * 0.35)
            scores["social"] += 0.08 + (deficit * 0.12)
            scores["combat"] -= 0.12 + (deficit * 0.2)
            scores["exploration"] -= 0.08 + (deficit * 0.12)

        if health < 45:
            scores["recovery"] += 0.25
            scores["travel"] += 0.08
            scores["combat"] -= 0.1

        followup_turn = world_facts.get("followup_turn")
        if isinstance(followup_turn, int) and followup_turn == current_turn:
            required_tags = world_facts.get("followup_required_tags", [])
            if isinstance(required_tags, list):
                tag_to_beats: dict[str, tuple[BeatType, ...]] = {
                    "combat": ("combat", "revelation"),
                    "social": ("social", "mystery"),
                    "mystery": ("mystery", "revelation"),
                    "exploration": ("exploration", "travel"),
                    "travel": ("travel", "exploration"),
                    "recovery": ("recovery", "social"),
                    "revelation": ("revelation", "mystery"),
                }
                for raw_tag in required_tags:
                    if not isinstance(raw_tag, str):
                        continue
                    for beat in tag_to_beats.get(raw_tag, ()):
                        scores[beat] += 0.28

        # Immediate consequence steering from the previous turn.
        last_choice = world_facts.get("last_choice")
        last_success = world_facts.get("last_success")
        last_resolution_tier = world_facts.get("last_resolution_tier")
        if isinstance(last_choice, str):
            if last_choice == "attack":
                scores["combat"] += 0.22
                scores["revelation"] += 0.12
                if last_success is False:
                    scores["recovery"] += 0.1
            elif last_choice == "defend":
                scores["recovery"] += 0.14
                scores["social"] += 0.08
            elif last_choice == "talk":
                scores["social"] += 0.22
                scores["mystery"] += 0.12
            elif last_choice == "investigate":
                scores["mystery"] += 0.22
                scores["exploration"] += 0.1
            elif last_choice == "explore":
                scores["travel"] += 0.18
                scores["exploration"] += 0.16
            elif last_choice == "retreat":
                scores["recovery"] += 0.2
                scores["travel"] += 0.1
            elif last_choice == "use_item":
                scores["recovery"] += 0.16
            elif last_choice == "wait":
                scores["mystery"] += 0.08
                scores["social"] += 0.08

        if last_success is False:
            scores["combat"] -= 0.1
            scores["recovery"] += 0.12

        if last_resolution_tier == "favorable":
            scores["revelation"] += 0.08
            scores["exploration"] += 0.06
        elif last_resolution_tier == "neutral":
            scores["mystery"] += 0.08
            scores["social"] += 0.05
        elif last_resolution_tier == "negative":
            scores["recovery"] += 0.16
            scores["combat"] -= 0.08

        return max(self._beats, key=lambda beat: scores.get(beat, -1e9))
