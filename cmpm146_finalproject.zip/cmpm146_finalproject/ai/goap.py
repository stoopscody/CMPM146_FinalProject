"""Simple GOAP forward-search planner."""

from __future__ import annotations

import heapq
from typing import Any


class GOAPPlanner:
    """Plan action sequences from symbolic preconditions/effects/costs."""

    def __init__(self, max_expansions: int = 500) -> None:
        self.max_expansions = max_expansions

    def _narrative_lock_active(self, facts: dict[str, Any]) -> bool:
        lock_flag = bool(facts.get("is_in_narrative_chain", False))
        current_chapter = facts.get("current_chapter")
        max_chapters = facts.get("max_chapters")
        chapter_lock = (
            isinstance(current_chapter, (int, float))
            and isinstance(max_chapters, (int, float))
            and int(max_chapters) > 0
            and int(current_chapter) < int(max_chapters)
        )
        return lock_flag or chapter_lock

    def _goal_met(self, facts: dict[str, Any], key: str, value: Any) -> bool:
        actual = facts.get(key)
        if key == "threads_resolved" and isinstance(actual, (int, float)) and isinstance(value, (int, float)):
            return float(actual) >= float(value)
        return actual == value

    def _facts_satisfied(self, facts: dict[str, Any], goals: dict[str, Any]) -> bool:
        narrative_lock = self._narrative_lock_active(facts)
        node_type = str(facts.get("node_type", "scene"))
        suppressed_global_goal = False

        for key, value in goals.items():
            # Narrative lock suppresses global win checks until hub/transition nodes.
            if key == "threads_resolved" and narrative_lock and node_type not in {"hub", "transition"}:
                suppressed_global_goal = True
                continue
            if not self._goal_met(facts, key, value):
                return False
        if suppressed_global_goal:
            return False
        return True

    def _facts_signature(self, facts: dict[str, Any]) -> tuple[tuple[str, Any], ...]:
        return tuple(sorted(facts.items(), key=lambda item: item[0]))

    def _preconditions_met(self, facts: dict[str, Any], preconditions: dict[str, Any]) -> bool:
        return all(facts.get(key) == value for key, value in preconditions.items())

    def _apply_effects(self, facts: dict[str, Any], effects: dict[str, Any]) -> dict[str, Any]:
        updated = dict(facts)
        for key, value in effects.items():
            updated[key] = value
        return updated

    def evaluate_goals(self, facts: dict[str, Any], goals: dict[str, Any]) -> bool:
        """Evaluate goals with narrative-lock masking for global win conditions."""
        return self._facts_satisfied(facts, goals)

    def build_travel_actions(self, from_location: str, to_location: str) -> list[dict[str, Any]]:
        """Return GOAP actions that force an intermediate transition node for travel."""
        transition_node = f"path_to_{to_location}_from_{from_location}"
        return [
            {
                "id": f"enter_{transition_node}",
                "preconditions": {"location": from_location},
                "effects": {"location": transition_node, "node_type": "transition", "in_transition": True},
                "cost": 1.0,
            },
            {
                "id": f"arrive_{to_location}",
                "preconditions": {"location": transition_node},
                "effects": {"location": to_location, "node_type": "hub", "in_transition": False},
                "cost": 1.0,
            },
        ]

    def plan(
        self,
        start_facts: dict[str, Any],
        goal_facts: dict[str, Any],
        actions: list[dict[str, Any]],
    ) -> list[str]:
        """Run forward search and return lowest-cost action id sequence."""
        if not goal_facts:
            return []

        queue: list[tuple[float, int, int, dict[str, Any], list[str]]] = []
        push_index = 0
        heapq.heappush(queue, (0.0, 0, push_index, dict(start_facts), []))

        visited_cost: dict[tuple[tuple[str, Any], ...], float] = {}
        expansions = 0

        while queue and expansions < self.max_expansions:
            total_cost, steps, _, facts, plan = heapq.heappop(queue)
            signature = self._facts_signature(facts)

            if signature in visited_cost and visited_cost[signature] <= total_cost:
                continue
            visited_cost[signature] = total_cost

            if self._facts_satisfied(facts, goal_facts):
                return plan

            expansions += 1
            for action in actions:
                if not isinstance(action, dict):
                    continue
                action_id = action.get("id")
                preconditions = action.get("preconditions", {})
                effects = action.get("effects", {})
                cost = action.get("cost", 1.0)

                if not isinstance(action_id, str) or not action_id:
                    continue
                if not isinstance(preconditions, dict) or not isinstance(effects, dict):
                    continue
                if not isinstance(cost, (int, float)):
                    continue

                if not self._preconditions_met(facts, preconditions):
                    continue

                next_facts = self._apply_effects(facts, effects)
                next_plan = [*plan, action_id]
                next_cost = total_cost + float(cost)
                push_index += 1
                heapq.heappush(queue, (next_cost, steps + 1, push_index, next_facts, next_plan))

        return []
