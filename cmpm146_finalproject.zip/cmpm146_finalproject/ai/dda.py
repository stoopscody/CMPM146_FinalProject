"""Dynamic Difficulty Adjustment controller."""

from __future__ import annotations

from collections import deque

from contracts import Outcome, validate_outcome


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


class DDAController:
    """Track rolling performance and map it to difficulty target.

    Performance uses a bounded rolling window where each turn contributes a
    score based on success, health cost, and thread progression.
    """

    def __init__(self, window_size: int = 8) -> None:
        self._window: deque[float] = deque(maxlen=max(3, window_size))
        self._target = 0.45

    def push_outcome(self, outcome: Outcome) -> None:
        """Ingest outcome delta and update rolling performance statistics."""
        validate_outcome(outcome)

        score = 0.0
        if outcome.get("success") is True:
            score += 0.35
        elif outcome.get("success") is False:
            score -= 0.35
        else:
            resolution_tier = outcome.get("resolution_tier")
            if resolution_tier == "favorable":
                score += 0.2
            elif resolution_tier == "negative":
                score -= 0.2

        player = outcome.get("player", {})
        health_delta = float(player.get("health_delta", 0.0)) if isinstance(player, dict) else 0.0
        if health_delta < 0:
            score -= min(0.35, abs(health_delta) / 30.0)
        elif health_delta > 0:
            score += min(0.15, health_delta / 40.0)

        plot_threads = outcome.get("plot_threads", [])
        if isinstance(plot_threads, list):
            progress_gain = 0.0
            for update in plot_threads:
                if isinstance(update, dict) and isinstance(update.get("progress_delta"), (int, float)):
                    progress_gain += float(update["progress_delta"])
            score += min(0.25, progress_gain * 0.3)

        score += float(outcome.get("difficulty_signal", 0.0)) * 0.1
        score = _clamp(score, -1.0, 1.0)
        self._window.append(score)

        current = self.performance_score()
        raw_target = _clamp(0.5 + current * 0.35, 0.15, 0.95)
        self._target = _clamp(self._target * 0.7 + raw_target * 0.3, 0.15, 0.95)

    def performance_score(self) -> float:
        """Return rolling average performance in [-1.0, 1.0]."""
        if not self._window:
            return 0.0
        return sum(self._window) / len(self._window)

    def difficulty_target(self) -> float:
        """Return smoothed difficulty target in [0.15, 0.95]."""
        return round(self._target, 4)
