"""Player behavior modeling using EMA traits and confidence gating."""

from __future__ import annotations

from contracts import Observation, validate_observation


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


class PlayerModel:
    """Infer player style traits from observations over time.

    Traits tracked:
    - aggression
    - caution
    - exploration
    - social

    Update rule uses exponential moving averages. Confidence starts low and
    increases with observations, gating how strongly raw trait estimates affect
    downstream systems.
    """

    def __init__(self, alpha: float = 0.24) -> None:
        self._alpha = _clamp(alpha, 0.05, 0.6)
        self._raw_traits: dict[str, float] = {
            "aggression": 0.5,
            "caution": 0.5,
            "exploration": 0.5,
            "social": 0.5,
        }
        self._observation_count = 0

    def observe(self, observation: Observation) -> None:
        """Update trait estimates from one validated observation payload."""
        validate_observation(observation)

        self._observation_count += 1

        risk = float(observation.get("risk_level", 0.5))
        social_intent = float(observation.get("social_intent", 0.5))
        exploration_intent = float(observation.get("exploration_intent", 0.5))
        aggression_signal = float(observation.get("aggression_signal", 0.5))

        success = bool(observation.get("success", False))
        failure = bool(observation.get("failure", False))

        # Slightly faster adaptation in early turns.
        warmup = max(0.0, 1.0 - (self._observation_count / 16.0))
        alpha = _clamp(self._alpha + warmup * 0.08, 0.05, 0.45)

        targets = {
            "aggression": _clamp(aggression_signal),
            "caution": _clamp(1.0 - risk),
            "exploration": _clamp(exploration_intent),
            "social": _clamp(social_intent),
        }

        if failure and risk > 0.6:
            targets["caution"] = _clamp(targets["caution"] + 0.12)

        if success and observation.get("choice") in {"attack", "investigate", "explore"}:
            targets["aggression"] = _clamp(targets["aggression"] + 0.06)
            targets["exploration"] = _clamp(targets["exploration"] + 0.05)

        for trait, target in targets.items():
            current = self._raw_traits[trait]
            self._raw_traits[trait] = _clamp(current + alpha * (target - current))

    def confidence(self) -> float:
        """Return confidence in [0, 1] based on number of observations."""
        return _clamp(self._observation_count / 12.0)

    def archetype(self) -> str:
        """Return current archetype label from confidence-gated traits."""
        traits = self.trait_vector()
        ordered = sorted(traits.items(), key=lambda item: item[1], reverse=True)
        top_name, top_score = ordered[0]
        second_score = ordered[1][1]

        if top_score - second_score < 0.08:
            return "Balanced Wanderer"

        mapping = {
            "aggression": "Vanguard",
            "caution": "Survivor",
            "exploration": "Seeker",
            "social": "Diplomat",
        }
        return mapping.get(top_name, "Adaptive")

    def trait_vector(self) -> dict[str, float]:
        """Return confidence-gated trait vector for downstream AI scoring."""
        confidence = self.confidence()
        neutral = 0.5
        return {
            name: round(_clamp(neutral + confidence * (value - neutral)), 4)
            for name, value in self._raw_traits.items()
        }
