"""Utility-based AI Dungeon Master scene selection policy."""

from __future__ import annotations

import random
from typing import Any

from ai.npc_agent import NPCAgent
from ai.story_generator import StoryGenerator
from contracts import ActionType, BeatType, SceneSpec, validate_scene_spec
from game.content import ContentDB

FollowupContext = dict[str, Any]
_VALID_BEAT_TYPES: set[str] = {
    "exploration",
    "combat",
    "social",
    "mystery",
    "recovery",
    "revelation",
    "travel",
}


def _clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, value))


def _stable_pick(options: list[str], key: str) -> str:
    if not options:
        return ""
    index = sum(ord(ch) for ch in key) % len(options)
    return options[index]


class DMPolicy:
    """Generate scene specs by filtering and utility-scoring encounter candidates.

    Adaptivity is driven by:
    - player traits
    - DDA target
    - world facts produced by recent outcomes
    - relationship/inventory/thread state
    - scene cooldown + repetition penalties
    """

    def __init__(
        self,
        content_db: ContentDB,
        npc_agent: NPCAgent | None = None,
    ) -> None:
        self._content_db = content_db
        self._npc_agent = npc_agent or NPCAgent()
        self._story_generator = StoryGenerator()
        self._default_scene_cooldown_turns = 4

    def _focus_label_from_scene(self, scene_spec: SceneSpec, followup: FollowupContext | None) -> str:
        focus_keywords = {
            "waystone",
            "route",
            "path",
            "trail",
            "market",
            "vault",
            "gate",
            "shrine",
            "oracle",
            "catacombs",
            "tunnel",
            "courier",
            "siege",
            "rebel",
            "ledger",
            "archive",
            "spy",
            "caravan",
        }
        metadata = scene_spec.get("metadata", {})
        if isinstance(metadata, dict):
            scene_active_entity = metadata.get("active_entity")
            if isinstance(scene_active_entity, str) and scene_active_entity.strip():
                return scene_active_entity.strip().replace("_", " ")

        if followup is not None:
            active_entity = followup.get("active_entity")
            if isinstance(active_entity, str) and active_entity.strip():
                return active_entity.strip().replace("_", " ")

            focus = followup.get("focus")
            if isinstance(focus, str) and focus.strip():
                return focus.strip().replace("_", " ")

        searchable = " ".join(
            [
                str(scene_spec.get("scene_id", "")).lower(),
                str(scene_spec.get("title", "")).lower(),
            ]
        )
        for keyword in focus_keywords:
            if keyword in searchable:
                return keyword.replace("_", " ")

        tags = scene_spec.get("tags", [])
        if isinstance(tags, list):
            for tag in tags:
                if not isinstance(tag, str):
                    continue
                normalized = tag.strip().lower()
                if normalized in focus_keywords:
                    return normalized.replace("_", " ")
        return "threat"

    def _immersive_choice_text(
        self,
        *,
        action: ActionType,
        beat_type: BeatType,
        focus_label: str,
        scene_id: str,
    ) -> str:
        focus = focus_label.strip().lower() or "threat"
        anchor = focus if focus.startswith(("the ", "a ", "an ")) else f"the {focus}"

        if beat_type == "combat":
            options: dict[ActionType, list[str]] = {
                "defend": [
                    "Duck under the strike and guard your head.",
                    "Raise your guard and take the hit on your forearm.",
                    "Drop low and protect your center.",
                ],
                "attack": [
                    "Try to grab the knife hand and wrench it away.",
                    "Lunge first and hit before the next strike.",
                    "Drive forward and force the attacker back.",
                ],
                "wait": [
                    "Freeze and accept your fate.",
                    "Hold still and trust pure luck.",
                    "Do nothing and pray the blow misses.",
                ],
                "retreat": [
                    "Dive backward and make space.",
                    "Break contact and fall back.",
                    "Disengage fast before you get surrounded.",
                ],
                "talk": [
                    "Shout for them to stop and buy one heartbeat.",
                    "Call out and try to break their focus.",
                    "Bark an order to reset your line.",
                ],
                "use_item": [
                    "Rip out a tool and improvise a defense.",
                    "Throw a gadget to disrupt the attack.",
                    "Burn a supply now to survive this exchange.",
                ],
                "investigate": [
                    "Watch their footing and wait for a tell.",
                    "Read their shoulders before you commit.",
                    "Track the attacker’s rhythm and predict the next move.",
                ],
                "explore": [
                    "Side-step into a better angle and reposition.",
                    "Slip around the flank to make space.",
                    "Move through the chaos and open a path out.",
                ],
            }
            return _stable_pick(options[action], f"{scene_id}:{action}:{beat_type}:{anchor}")

        options = {
            "investigate": [
                f"Inspect {anchor} closely before you move.",
                f"Read the details around {anchor}.",
                f"Check the evidence tied to {anchor}.",
            ],
            "retreat": [
                "Fall back to safer ground.",
                "Pull everyone back and regroup.",
                "Withdraw before this gets worse.",
            ],
            "explore": [
                f"Push deeper toward {anchor}.",
                f"Move now and force progress near {anchor}.",
                f"Take the risky route around {anchor}.",
            ],
            "talk": [
                "Talk them down before this escalates.",
                "Speak up and force one clear plan.",
                "Call for calm and hold the room together.",
            ],
            "attack": [
                f"Strike hard at the threat around {anchor}.",
                f"Hit first and seize momentum.",
                f"Commit to force and break resistance.",
            ],
            "defend": [
                "Shield yourself and the nearest ally.",
                "Brace and absorb the next impact.",
                "Hold your ground and protect the line.",
            ],
            "use_item": [
                "Use a tool now to tilt the odds.",
                "Burn supplies for an immediate edge.",
                "Commit resources to stabilize the moment.",
            ],
            "wait": [
                "Hold still for one heartbeat and read the room.",
                "Wait and let the danger reveal itself.",
                "Do nothing for a moment and watch.",
            ],
        }
        return _stable_pick(options[action], f"{scene_id}:{action}:{beat_type}:{anchor}")

    def _apply_immersive_choice_text(self, scene_spec: SceneSpec, followup: FollowupContext | None) -> SceneSpec:
        choices = scene_spec.get("choices", [])
        if not isinstance(choices, list) or not choices:
            return scene_spec

        beat_type = scene_spec.get("beat_type", "mystery")
        if not isinstance(beat_type, str) or beat_type not in _VALID_BEAT_TYPES:
            beat_type = "mystery"
        typed_beat: BeatType = beat_type  # type: ignore[assignment]

        focus_label = self._focus_label_from_scene(scene_spec, followup)
        scene_id = str(scene_spec.get("scene_id", "scene"))

        choice_text: dict[str, str] = {}
        for action in choices:
            if not isinstance(action, str):
                continue
            choice_text[action] = self._immersive_choice_text(
                action=action,  # type: ignore[arg-type]
                beat_type=typed_beat,
                focus_label=focus_label,
                scene_id=scene_id,
            )
        if choice_text:
            scene_spec["choice_text"] = choice_text
        return scene_spec

    def _recent_scene_ids(self, state: Any, limit: int = 30) -> list[str]:
        event_history = getattr(state, "event_history", [])
        if not isinstance(event_history, list):
            return []

        recent: list[str] = []
        for event in reversed(event_history):
            if not isinstance(event, dict):
                continue
            scene_id = event.get("scene_id")
            if isinstance(scene_id, str) and scene_id:
                recent.append(scene_id)
                if len(recent) >= limit:
                    break
        return recent

    def _scene_repeat_count(self, state: Any, scene_id: str) -> int:
        return sum(1 for entry in self._recent_scene_ids(state, limit=50) if entry == scene_id)

    def _world_fact_filters_ok(self, encounter: dict[str, Any], state: Any) -> bool:
        world_facts = getattr(state, "world_facts", {})
        if not isinstance(world_facts, dict):
            world_facts = {}

        required_world_facts = encounter.get("required_world_facts", {})
        if isinstance(required_world_facts, dict):
            for key, expected in required_world_facts.items():
                if world_facts.get(key) != expected:
                    return False

        banned_world_facts = encounter.get("banned_world_facts", {})
        if isinstance(banned_world_facts, dict):
            for key, banned_value in banned_world_facts.items():
                if world_facts.get(key) == banned_value:
                    return False

        required_world_keys = encounter.get("required_world_keys", [])
        if isinstance(required_world_keys, list):
            for key in required_world_keys:
                if not isinstance(key, str) or not world_facts.get(key):
                    return False

        required_world_keys_any = encounter.get("required_world_keys_any", [])
        if isinstance(required_world_keys_any, list) and required_world_keys_any:
            any_match = any(isinstance(key, str) and bool(world_facts.get(key)) for key in required_world_keys_any)
            if not any_match:
                return False

        return True

    def _inventory_filters_ok(self, encounter: dict[str, Any], state: Any) -> bool:
        inventory = set(getattr(getattr(state, "player", object()), "inventory", []))

        required_items = encounter.get("required_items", [])
        if isinstance(required_items, list):
            for item in required_items:
                if isinstance(item, str) and item not in inventory:
                    return False

        banned_items = encounter.get("banned_items", [])
        if isinstance(banned_items, list):
            for item in banned_items:
                if isinstance(item, str) and item in inventory:
                    return False

        return True

    def _relationship_filters_ok(self, encounter: dict[str, Any], state: Any) -> bool:
        relationships = getattr(getattr(state, "player", object()), "relationships", {})
        if not isinstance(relationships, dict):
            relationships = {}

        required_relationships = encounter.get("required_relationships", {})
        if isinstance(required_relationships, dict):
            for entity_id, minimum in required_relationships.items():
                if not isinstance(entity_id, str):
                    return False
                if not isinstance(minimum, (int, float)):
                    return False
                if float(relationships.get(entity_id, 0.0)) < float(minimum):
                    return False

        return True

    def _thread_progress_filters_ok(self, encounter: dict[str, Any], state: Any) -> bool:
        threads = getattr(state, "plot_threads", {})
        if not isinstance(threads, dict):
            threads = {}

        min_progress = encounter.get("min_thread_progress", {})
        if isinstance(min_progress, dict):
            for thread_id, minimum in min_progress.items():
                if not isinstance(thread_id, str) or not isinstance(minimum, (int, float)):
                    return False
                thread = threads.get(thread_id)
                progress = float(getattr(thread, "progress", 0.0)) if thread is not None else 0.0
                if progress < float(minimum):
                    return False

        max_progress = encounter.get("max_thread_progress", {})
        if isinstance(max_progress, dict):
            for thread_id, maximum in max_progress.items():
                if not isinstance(thread_id, str) or not isinstance(maximum, (int, float)):
                    return False
                thread = threads.get(thread_id)
                progress = float(getattr(thread, "progress", 0.0)) if thread is not None else 0.0
                if progress > float(maximum):
                    return False

        return True

    def _scene_repeat_constraints_ok(
        self,
        encounter: dict[str, Any],
        state: Any,
        *,
        enforce_cooldown: bool,
    ) -> bool:
        scene_id = encounter.get("id")
        if not isinstance(scene_id, str) or not scene_id:
            return True

        if bool(encounter.get("one_shot", False)):
            if self._scene_repeat_count(state, scene_id) > 0:
                return False

        if enforce_cooldown:
            cooldown_turns = encounter.get("cooldown_turns", self._default_scene_cooldown_turns)
            if isinstance(cooldown_turns, (int, float)):
                cooldown_n = max(0, int(cooldown_turns))
                if cooldown_n > 0:
                    recent_scene_ids = self._recent_scene_ids(state, limit=cooldown_n)
                    if scene_id in recent_scene_ids:
                        return False

        return True

    def _scene_blocklist_ok(self, encounter: dict[str, Any], state: Any) -> bool:
        scene_id = encounter.get("id")
        if not isinstance(scene_id, str) or not scene_id:
            return True

        world_facts = getattr(state, "world_facts", {})
        if not isinstance(world_facts, dict):
            return True

        blocklist = world_facts.get("scene_blocklist", {})
        if not isinstance(blocklist, dict):
            return True

        current_turn = int(getattr(getattr(state, "narrative", object()), "turn_index", 0))
        blocked_until = blocklist.get(scene_id)
        if isinstance(blocked_until, int) and current_turn <= blocked_until:
            return False
        return True

    def _active_followup(self, state: Any) -> FollowupContext | None:
        world_facts = getattr(state, "world_facts", {})
        if not isinstance(world_facts, dict):
            return None

        current_turn = int(getattr(getattr(state, "narrative", object()), "turn_index", 0))
        followup_turn = world_facts.get("followup_turn")
        if not isinstance(followup_turn, int) or followup_turn != current_turn:
            return None

        required_tags_raw = world_facts.get("followup_required_tags", [])
        required_tags = [tag for tag in required_tags_raw if isinstance(tag, str) and tag]

        primary_tag = world_facts.get("followup_primary_tag")
        if isinstance(primary_tag, str):
            primary_tag = primary_tag.strip()
        else:
            primary_tag = ""
        if not primary_tag and required_tags:
            primary_tag = required_tags[0]

        required_location = world_facts.get("followup_required_location")
        if not isinstance(required_location, str):
            required_location = ""

        required_thread_ids_raw = world_facts.get("followup_required_thread_ids", [])
        required_thread_ids = [
            thread_id
            for thread_id in required_thread_ids_raw
            if isinstance(thread_id, str) and thread_id
        ]

        followup_narrative = world_facts.get("followup_narrative")
        if not isinstance(followup_narrative, str):
            followup_narrative = ""

        followup_story_opening = world_facts.get("followup_story_opening")
        if not isinstance(followup_story_opening, str):
            followup_story_opening = ""

        followup_story_consequence = world_facts.get("followup_story_consequence")
        if not isinstance(followup_story_consequence, str):
            followup_story_consequence = ""

        followup_story_aftermath = world_facts.get("followup_story_aftermath")
        if not isinstance(followup_story_aftermath, str):
            followup_story_aftermath = ""

        followup_branch_hook = world_facts.get("followup_branch_hook")
        if not isinstance(followup_branch_hook, str):
            followup_branch_hook = ""

        followup_branch_goal = world_facts.get("followup_branch_goal")
        if not isinstance(followup_branch_goal, str):
            followup_branch_goal = ""

        source_scene = world_facts.get("followup_source_scene")
        if not isinstance(source_scene, str):
            source_scene = ""

        source_choice = world_facts.get("followup_source_choice")
        if not isinstance(source_choice, str):
            source_choice = ""

        source_tier = world_facts.get("followup_source_tier")
        if not isinstance(source_tier, str):
            source_tier = ""

        focus = world_facts.get("followup_focus")
        if not isinstance(focus, str):
            focus = ""

        mode = world_facts.get("followup_mode")
        if not isinstance(mode, str):
            mode = "catalog"

        depth = world_facts.get("followup_depth")
        if isinstance(depth, bool) or not isinstance(depth, (int, float)):
            depth = 0

        chain_id = world_facts.get("followup_chain_id")
        if not isinstance(chain_id, str):
            chain_id = ""

        branch_signature = world_facts.get("followup_branch_signature")
        if not isinstance(branch_signature, str):
            branch_signature = ""

        questline_location = world_facts.get("questline_location")
        if not isinstance(questline_location, str):
            questline_location = ""

        questline_name = world_facts.get("questline_name")
        if not isinstance(questline_name, str):
            questline_name = ""

        questline_chapter = world_facts.get("questline_chapter")
        if isinstance(questline_chapter, bool) or not isinstance(questline_chapter, (int, float)):
            questline_chapter = 0

        questline_total_chapters = world_facts.get("questline_total_chapters")
        if isinstance(questline_total_chapters, bool) or not isinstance(questline_total_chapters, (int, float)):
            questline_total_chapters = 0

        followup_previous_location = world_facts.get("followup_previous_location")
        if not isinstance(followup_previous_location, str):
            followup_previous_location = ""

        followup_player_action = world_facts.get("followup_player_action")
        if not isinstance(followup_player_action, str):
            followup_player_action = ""

        followup_player_action_label = world_facts.get("followup_player_action_label")
        if not isinstance(followup_player_action_label, str):
            followup_player_action_label = ""

        followup_resolution_tier = world_facts.get("followup_resolution_tier")
        if not isinstance(followup_resolution_tier, str):
            followup_resolution_tier = ""

        followup_roll_value = world_facts.get("followup_roll_value")
        if isinstance(followup_roll_value, bool) or not isinstance(followup_roll_value, (int, float)):
            followup_roll_value = 0

        followup_dda_event = world_facts.get("followup_dda_event")
        if not isinstance(followup_dda_event, str):
            followup_dda_event = ""

        followup_source_entity = world_facts.get("followup_source_entity")
        if not isinstance(followup_source_entity, str):
            followup_source_entity = ""

        active_entity = world_facts.get("active_entity")
        if not isinstance(active_entity, str):
            active_entity = ""

        active_entity_location = world_facts.get("active_entity_location")
        if not isinstance(active_entity_location, str):
            active_entity_location = ""

        active_entity_chapter = world_facts.get("active_entity_chapter")
        if isinstance(active_entity_chapter, bool) or not isinstance(active_entity_chapter, (int, float)):
            active_entity_chapter = 0

        active_entity_locked = world_facts.get("active_entity_locked")
        if not isinstance(active_entity_locked, bool):
            active_entity_locked = False

        current_chapter = world_facts.get("current_chapter")
        if isinstance(current_chapter, bool) or not isinstance(current_chapter, (int, float)):
            current_chapter = 0

        max_chapters = world_facts.get("max_chapters")
        if isinstance(max_chapters, bool) or not isinstance(max_chapters, (int, float)):
            max_chapters = 0

        is_in_narrative_chain = world_facts.get("is_in_narrative_chain")
        if not isinstance(is_in_narrative_chain, bool):
            is_in_narrative_chain = False

        node_type = world_facts.get("node_type")
        if not isinstance(node_type, str):
            node_type = "hub"

        return {
            "required_tags": required_tags,
            "primary_tag": primary_tag,
            "required_location": required_location,
            "required_thread_ids": required_thread_ids,
            "narrative": followup_narrative,
            "story_opening": followup_story_opening,
            "story_consequence": followup_story_consequence,
            "story_aftermath": followup_story_aftermath,
            "branch_hook": followup_branch_hook,
            "branch_goal": followup_branch_goal,
            "source_scene": source_scene,
            "source_choice": source_choice,
            "source_tier": source_tier,
            "focus": focus,
            "mode": mode,
            "depth": int(depth),
            "chain_id": chain_id,
            "branch_signature": branch_signature,
            "turn": followup_turn,
            "questline_location": questline_location,
            "questline_name": questline_name,
            "questline_chapter": int(questline_chapter),
            "questline_total_chapters": int(questline_total_chapters),
            "previous_location": followup_previous_location,
            "player_action": followup_player_action,
            "player_action_label": followup_player_action_label,
            "resolution_tier": followup_resolution_tier,
            "roll_value": int(followup_roll_value),
            "dda_event_triggered": followup_dda_event,
            "source_entity": followup_source_entity,
            "active_entity": active_entity,
            "active_entity_location": active_entity_location,
            "active_entity_chapter": int(active_entity_chapter),
            "active_entity_locked": active_entity_locked,
            "current_chapter": int(current_chapter),
            "max_chapters": int(max_chapters),
            "is_in_narrative_chain": is_in_narrative_chain,
            "node_type": node_type,
        }

    def _use_dynamic_followup(self, state: Any, followup: FollowupContext) -> bool:
        mode = followup.get("mode")
        depth = followup.get("depth")
        if mode != "dynamic":
            return False
        if isinstance(depth, bool) or not isinstance(depth, int):
            return False
        if depth <= 0:
            return False

        questline_total_raw = followup.get("questline_total_chapters")
        questline_total = questline_total_raw if isinstance(questline_total_raw, int) else 0
        max_depth = max(12, questline_total + 2)
        if depth > max_depth:
            return False

        world_facts = getattr(state, "world_facts", {})
        if questline_total > 0 and depth <= questline_total:
            return True
        if isinstance(world_facts, dict) and world_facts.get("arc_exit_hint") is True and depth >= 3:
            return False
        return True

    def _followup_beat(self, followup: FollowupContext, requested_beat: BeatType) -> BeatType:
        primary_tag = followup.get("primary_tag")
        if isinstance(primary_tag, str) and primary_tag in _VALID_BEAT_TYPES:
            return primary_tag
        return requested_beat

    def _special_followup_scene(
        self,
        state: Any,
        followup: FollowupContext,
        requested_beat: BeatType,
    ) -> SceneSpec | None:
        depth = followup.get("depth")
        if isinstance(depth, int) and depth > 1:
            return None

        source_scene = str(followup.get("source_scene", ""))
        source_choice = str(followup.get("source_choice", ""))
        source_tier = str(followup.get("source_tier", ""))
        if source_scene != "waystone_path" or source_choice != "use_item" or source_tier != "negative":
            return None

        current_turn = int(getattr(getattr(state, "narrative", object()), "turn_index", 0))
        location_id = str(getattr(getattr(state, "player", object()), "location_id", "crossroads"))
        thread_ids = [
            thread_id
            for thread_id in followup.get("required_thread_ids", [])
            if isinstance(thread_id, str) and thread_id
        ]
        if not thread_ids:
            thread_ids = ["eclipse_prophecy"]

        beat_type = self._followup_beat(followup, requested_beat)
        if beat_type not in {"travel", "exploration", "mystery"}:
            beat_type = "travel"

        choices: list[ActionType] = ["investigate", "retreat", "explore"]
        scene_spec: SceneSpec = {
            "scene_id": f"followup_waystone_lost_route_{current_turn}",
            "title": "Lost in the Unmarked Expanse",
            "beat_type": beat_type,
            "template_id": "dynamic_followup",
            "text_vars": {
                "continuity_line": (
                    "Your attempt to anchor the route has failed; the waystone pulse scrambles the caravan markers, "
                    "and your convoy drifts off the known trail."
                ),
                "hook": (
                    "Cold wind drags ash across the track and every cairn points a different direction. "
                    "Lantern light catches worried faces as the caravan waits for your call."
                ),
            },
            "choices": choices,
            "choice_text": {
                "investigate": "Try to find a path by reading landmarks and star-lines.",
                "retreat": "Backtrack toward the last stable marker.",
                "explore": "Keep going on the current heading and force a way through.",
            },
            "choice_tags": {
                "investigate": ["mystery", "travel", "caution"],
                "retreat": ["recovery", "travel", "caution"],
                "explore": ["exploration", "travel", "risk"],
            },
            "base_risk": {
                "investigate": 0.45,
                "retreat": 0.3,
                "explore": 0.68,
            },
            "effects": {
                "investigate": {
                    "on_favorable": {
                        "world_facts": {"caravan_route_recovered": True},
                        "tension_delta": -0.05,
                    },
                    "on_neutral": {
                        "world_facts": {"caravan_partial_route": True},
                        "tension_delta": 0.02,
                    },
                    "on_negative": {
                        "player": {"health_delta": -4},
                        "world_facts": {"caravan_still_lost": True},
                        "tension_delta": 0.07,
                    },
                },
                "retreat": {
                    "on_favorable": {
                        "world_facts": {"caravan_regrouped": True},
                        "tension_delta": -0.08,
                    },
                    "on_neutral": {
                        "tension_delta": -0.02,
                    },
                    "on_negative": {
                        "player": {"health_delta": -3},
                        "tension_delta": 0.04,
                    },
                },
                "explore": {
                    "on_favorable": {
                        "world_facts": {"caravan_pressed_forward": True},
                        "plot_threads": [{"thread_id": "eclipse_prophecy", "progress_delta": 0.12}],
                    },
                    "on_neutral": {
                        "tension_delta": 0.04,
                    },
                    "on_negative": {
                        "player": {"health_delta": -7},
                        "world_facts": {"caravan_scattered": True},
                        "tension_delta": 0.1,
                    },
                },
            },
            "tags": ["travel", "exploration", "waystone", "caravan", "consequence"],
            "location_id": location_id,
            "difficulty": 0.68,
            "thread_ids": thread_ids,
            "metadata": {
                "generated_followup": True,
                "followup": followup,
                "progression_mode": "direct_consequence",
            },
        }
        return scene_spec

    def _generic_followup_pack(
        self,
        *,
        beat_type: BeatType,
        focus: str,
        source_tier: str,
        source_scene: str,
    ) -> tuple[str, str, list[ActionType], dict[str, str], dict[str, list[str]], dict[str, float], dict[str, dict[str, Any]], list[str]]:
        focus_label = focus.replace("_", " ").strip() if focus else "situation"
        focus_phrase = f"the {focus_label}" if focus_label else "the situation"
        source_name = source_scene.replace("_", " ").strip() if source_scene else ""
        source_suffix = f" after what happened at the {source_name}" if source_name else ""
        if source_name and focus_label and focus_label in source_name:
            source_suffix = ""
        tier_lead = {
            "favorable": "With momentum still behind you,",
            "neutral": "With little room for error,",
            "negative": "With the recent setback still biting,",
        }.get(source_tier, "With pressure still active,")

        if beat_type in {"travel", "exploration"}:
            title = "Forked Paths at Dusk"
            hook = (
                f"{tier_lead} the route fractures around {focus_phrase}{source_suffix}; tracks split, landmarks disagree, "
                "and your group looks to you for direction."
            )
            choices: list[ActionType] = ["investigate", "retreat", "explore"]
            choice_text = {
                "investigate": "Read the terrain and pick the most likely route.",
                "retreat": "Backtrack and re-establish your bearings.",
                "explore": "Push forward before conditions get worse.",
            }
            choice_tags = {
                "investigate": ["mystery", "travel", "caution"],
                "retreat": ["recovery", "travel", "caution"],
                "explore": ["exploration", "travel", "risk"],
            }
            base_risk = {"investigate": 0.44, "retreat": 0.28, "explore": 0.62}
            effects = {
                "investigate": {
                    "on_favorable": {"world_facts": {"route_locked_in": True}, "tension_delta": -0.04},
                    "on_neutral": {"world_facts": {"route_uncertain": True}, "tension_delta": 0.02},
                    "on_negative": {"player": {"health_delta": -4}, "tension_delta": 0.07},
                },
                "retreat": {
                    "on_favorable": {"world_facts": {"regroup_complete": True}, "tension_delta": -0.06},
                    "on_neutral": {"tension_delta": -0.02},
                    "on_negative": {"player": {"health_delta": -3}, "tension_delta": 0.03},
                },
                "explore": {
                    "on_favorable": {"world_facts": {"forward_breakthrough": True}},
                    "on_neutral": {"tension_delta": 0.03},
                    "on_negative": {"player": {"health_delta": -6}, "tension_delta": 0.09},
                },
            }
            tags = ["travel", "exploration", "consequence"]
            return title, hook, choices, choice_text, choice_tags, base_risk, effects, tags

        if beat_type in {"social"}:
            title = "Fraying Terms"
            hook = f"{tier_lead} voices rise around {focus_phrase}{source_suffix}; one wrong word can harden every side against you."
            choices = ["talk", "investigate", "retreat"]
            choice_text = {
                "talk": "Take control of the conversation before it fractures.",
                "investigate": "Read the room and identify who is steering the conflict.",
                "retreat": "Step back and keep your people out of the center of it.",
            }
            choice_tags = {
                "talk": ["social", "revelation"],
                "investigate": ["mystery", "social"],
                "retreat": ["recovery", "travel", "caution"],
            }
            base_risk = {"talk": 0.42, "investigate": 0.46, "retreat": 0.31}
            effects = {
                "talk": {
                    "on_favorable": {"world_facts": {"social_ground_held": True}, "tension_delta": -0.04},
                    "on_neutral": {"tension_delta": 0.01},
                    "on_negative": {"tension_delta": 0.08},
                },
                "investigate": {
                    "on_favorable": {"world_facts": {"instigator_identified": True}},
                    "on_neutral": {"world_facts": {"instigator_uncertain": True}},
                    "on_negative": {"player": {"health_delta": -3}, "tension_delta": 0.05},
                },
                "retreat": {
                    "on_favorable": {"world_facts": {"group_safe_distance": True}, "tension_delta": -0.05},
                    "on_neutral": {"tension_delta": -0.01},
                    "on_negative": {"tension_delta": 0.03},
                },
            }
            tags = ["social", "mystery", "consequence"]
            return title, hook, choices, choice_text, choice_tags, base_risk, effects, tags

        if beat_type in {"combat"}:
            title = "Line Under Pressure"
            hook = f"{tier_lead} the clash around {focus_phrase}{source_suffix} surges back toward you before anyone can reset."
            choices = ["attack", "defend", "retreat"]
            choice_text = {
                "attack": "Break their front before they regroup.",
                "defend": "Hold formation and absorb the next wave.",
                "retreat": "Withdraw to better ground while you still can.",
            }
            choice_tags = {
                "attack": ["combat", "aggressive"],
                "defend": ["combat", "caution"],
                "retreat": ["travel", "recovery", "caution"],
            }
            base_risk = {"attack": 0.86, "defend": 0.48, "retreat": 0.39}
            effects = {
                "attack": {
                    "on_favorable": {"world_facts": {"enemy_line_broken": True}},
                    "on_neutral": {"tension_delta": 0.05},
                    "on_negative": {"player": {"health_delta": -9}, "tension_delta": 0.12},
                },
                "defend": {
                    "on_favorable": {"world_facts": {"line_stabilized": True}, "tension_delta": -0.03},
                    "on_neutral": {"tension_delta": 0.02},
                    "on_negative": {"player": {"health_delta": -6}, "tension_delta": 0.08},
                },
                "retreat": {
                    "on_favorable": {"world_facts": {"fallback_position_secured": True}, "tension_delta": -0.05},
                    "on_neutral": {"player": {"health_delta": -2}},
                    "on_negative": {"player": {"health_delta": -5}, "tension_delta": 0.06},
                },
            }
            tags = ["combat", "consequence"]
            return title, hook, choices, choice_text, choice_tags, base_risk, effects, tags

        if beat_type in {"recovery"}:
            title = "Breathing Room, Briefly"
            hook = f"{tier_lead} you carve out a fragile pause around {focus_phrase}{source_suffix}, but it may close quickly."
            choices = ["wait", "use_item", "talk"]
            choice_text = {
                "wait": "Steady everyone and conserve strength.",
                "use_item": "Spend supplies to recover before pressure returns.",
                "talk": "Coordinate the next move while people can still listen.",
            }
            choice_tags = {
                "wait": ["recovery", "caution"],
                "use_item": ["recovery", "resourceful"],
                "talk": ["social", "recovery"],
            }
            base_risk = {"wait": 0.12, "use_item": 0.22, "talk": 0.25}
            effects = {
                "wait": {
                    "on_favorable": {"player": {"health_delta": 7}, "tension_delta": -0.1},
                    "on_neutral": {"player": {"health_delta": 2}, "tension_delta": -0.03},
                    "on_negative": {"tension_delta": 0.02},
                },
                "use_item": {
                    "on_favorable": {"player": {"health_delta": 10}, "world_facts": {"supplies_spent_for_recovery": True}},
                    "on_neutral": {"player": {"health_delta": 4}},
                    "on_negative": {"player": {"health_delta": 1}, "tension_delta": 0.03},
                },
                "talk": {
                    "on_favorable": {"world_facts": {"next_plan_aligned": True}, "tension_delta": -0.04},
                    "on_neutral": {"tension_delta": 0.0},
                    "on_negative": {"tension_delta": 0.04},
                },
            }
            tags = ["recovery", "social", "consequence"]
            return title, hook, choices, choice_text, choice_tags, base_risk, effects, tags

        title = "Unfinished Signals"
        hook = f"{tier_lead} clues surrounding {focus_phrase}{source_suffix} refuse to settle into one clean answer."
        choices = ["investigate", "talk", "use_item"]
        choice_text = {
            "investigate": "Follow the strongest clue before it goes cold.",
            "talk": "Question witnesses while details are still fresh.",
            "use_item": "Use your tools to force hidden evidence into view.",
        }
        choice_tags = {
            "investigate": ["mystery", "exploration"],
            "talk": ["social", "mystery"],
            "use_item": ["revelation", "resourceful"],
        }
        base_risk = {"investigate": 0.52, "talk": 0.34, "use_item": 0.4}
        effects = {
            "investigate": {
                "on_favorable": {"world_facts": {"core_clue_recovered": True}},
                "on_neutral": {"world_facts": {"partial_clue_recovered": True}},
                "on_negative": {"player": {"health_delta": -5}, "tension_delta": 0.06},
            },
            "talk": {
                "on_favorable": {"world_facts": {"witness_turns_cooperative": True}, "tension_delta": -0.02},
                "on_neutral": {"tension_delta": 0.01},
                "on_negative": {"tension_delta": 0.05},
            },
            "use_item": {
                "on_favorable": {"world_facts": {"forced_reveal_success": True}},
                "on_neutral": {"world_facts": {"forced_reveal_partial": True}},
                "on_negative": {"player": {"health_delta": -3}, "tension_delta": 0.04},
            },
        }
        tags = ["mystery", "revelation", "consequence"]
        return title, hook, choices, choice_text, choice_tags, base_risk, effects, tags

    def _dynamic_followup_scene(
        self,
        state: Any,
        followup: FollowupContext,
        requested_beat: BeatType,
    ) -> SceneSpec:
        special = self._special_followup_scene(state, followup, requested_beat)
        if special is not None:
            return special

        current_turn = int(getattr(getattr(state, "narrative", object()), "turn_index", 0))
        location_id = str(getattr(getattr(state, "player", object()), "location_id", "crossroads"))
        beat_type = self._followup_beat(followup, requested_beat)

        source_tier = str(followup.get("source_tier", "neutral"))
        source_scene = str(followup.get("source_scene", ""))
        focus = str(followup.get("focus", "")).strip().lower()
        required_tags = [tag for tag in followup.get("required_tags", []) if isinstance(tag, str)]
        if not focus:
            focus = required_tags[0] if required_tags else "aftermath"

        (
            title,
            hook,
            choices,
            choice_text,
            choice_tags,
            base_risk,
            effects,
            tags,
        ) = self._generic_followup_pack(
            beat_type=beat_type,
            focus=focus,
            source_tier=source_tier,
            source_scene=source_scene,
        )

        thread_ids = [
            thread_id
            for thread_id in followup.get("required_thread_ids", [])
            if isinstance(thread_id, str) and thread_id
        ]
        if not thread_ids:
            thread_ids = list(getattr(getattr(state, "narrative", object()), "active_thread_ids", []))[:2]

        source_choice = str(followup.get("source_choice", "choice"))
        continuity_line = followup.get("narrative")
        if not isinstance(continuity_line, str):
            continuity_line = ""

        difficulty = {
            "favorable": 0.44,
            "neutral": 0.54,
            "negative": 0.66,
        }.get(source_tier, 0.54)

        scene_spec: SceneSpec = {
            "scene_id": f"followup_{source_scene or 'consequence'}_{source_choice}_{source_tier}_{current_turn}",
            "title": title,
            "beat_type": beat_type,
            "template_id": "dynamic_followup",
            "text_vars": {
                "continuity_line": continuity_line,
                "hook": hook,
            },
            "choices": choices,
            "choice_text": choice_text,
            "choice_tags": choice_tags,
            "base_risk": base_risk,
            "effects": effects,
            "tags": tags + [focus, "progression"],
            "location_id": location_id,
            "difficulty": _clamp(difficulty),
            "thread_ids": thread_ids,
            "metadata": {
                "generated_followup": True,
                "followup": followup,
                "progression_mode": "direct_consequence",
            },
        }
        return scene_spec

    def _encounter_matches_followup(
        self,
        encounter: dict[str, Any],
        followup: FollowupContext | None,
        *,
        strict: bool,
    ) -> bool:
        if followup is None:
            return True

        source_scene = followup.get("source_scene")
        encounter_id = encounter.get("id")
        if (
            strict
            and isinstance(source_scene, str)
            and source_scene
            and isinstance(encounter_id, str)
            and encounter_id == source_scene
        ):
            return False

        tags = encounter.get("tags", [])
        tag_set = set(tag for tag in tags if isinstance(tag, str))

        required_tags = followup.get("required_tags", [])
        if isinstance(required_tags, list) and required_tags:
            valid_required_tags = {tag for tag in required_tags if isinstance(tag, str) and tag}
            if valid_required_tags and not tag_set.intersection(valid_required_tags):
                return False

        primary_tag = followup.get("primary_tag")
        if strict and isinstance(primary_tag, str) and primary_tag and primary_tag not in tag_set:
            return False

        required_location = followup.get("required_location")
        location_ids = encounter.get("location_ids", [])
        if (
            isinstance(required_location, str)
            and required_location
            and isinstance(location_ids, list)
            and location_ids
            and "*" not in location_ids
            and required_location not in location_ids
        ):
            return False

        required_thread_ids = followup.get("required_thread_ids", [])
        encounter_thread_ids = set(
            thread_id
            for thread_id in encounter.get("thread_ids", [])
            if isinstance(thread_id, str) and thread_id
        )
        if isinstance(required_thread_ids, list) and required_thread_ids and encounter_thread_ids:
            required_thread_set = {
                thread_id for thread_id in required_thread_ids if isinstance(thread_id, str) and thread_id
            }
            if strict and required_thread_set and not encounter_thread_ids.intersection(required_thread_set):
                return False

        focus = followup.get("focus")
        if strict and isinstance(focus, str) and focus:
            searchable_parts: list[str] = []
            for key in ("id", "title", "template_id"):
                value = encounter.get(key)
                if isinstance(value, str):
                    searchable_parts.append(value.lower())
            searchable_parts.extend(
                token.lower()
                for token in encounter.get("tags", [])
                if isinstance(token, str)
            )
            searchable_parts.extend(
                token.lower()
                for token in encounter.get("thread_ids", [])
                if isinstance(token, str)
            )
            searchable_text = " ".join(searchable_parts)
            if focus.lower() not in searchable_text:
                return False

        return True

    def _encounter_matches_context(
        self,
        encounter: dict[str, Any],
        state: Any,
        beat_type: BeatType,
        *,
        enforce_cooldown: bool,
        followup: FollowupContext | None,
        followup_strict: bool,
        allow_beat_override: bool,
    ) -> bool:
        beat_types = encounter.get("beat_types", [])
        if not allow_beat_override and beat_type not in beat_types:
            return False

        location_ids = encounter.get("location_ids", [])
        current_location = getattr(getattr(state, "player", object()), "location_id", "")
        if location_ids and "*" not in location_ids and current_location not in location_ids:
            return False

        tension = float(getattr(getattr(state, "narrative", object()), "tension", 0.3))
        min_tension = float(encounter.get("min_tension", 0.0))
        max_tension = float(encounter.get("max_tension", 1.0))
        if tension < min_tension or tension > max_tension:
            return False

        required_flags = encounter.get("required_flags", {})
        player_flags = getattr(getattr(state, "player", object()), "flags", {})
        if isinstance(required_flags, dict):
            for flag, expected in required_flags.items():
                if player_flags.get(flag) is not expected:
                    return False

        banned_flags = encounter.get("banned_flags", [])
        if isinstance(banned_flags, list):
            for flag in banned_flags:
                if player_flags.get(flag) is True:
                    return False

        if not self._world_fact_filters_ok(encounter, state):
            return False
        if not self._inventory_filters_ok(encounter, state):
            return False
        if not self._relationship_filters_ok(encounter, state):
            return False
        if not self._thread_progress_filters_ok(encounter, state):
            return False
        if not self._scene_repeat_constraints_ok(encounter, state, enforce_cooldown=enforce_cooldown):
            return False
        if not self._scene_blocklist_ok(encounter, state):
            return False
        if not self._encounter_matches_followup(encounter, followup, strict=followup_strict):
            return False

        return True

    def _continuity_score(
        self,
        encounter: dict[str, Any],
        state: Any,
        followup: FollowupContext | None,
    ) -> float:
        world_facts = getattr(state, "world_facts", {})
        if not isinstance(world_facts, dict):
            world_facts = {}

        tags = encounter.get("tags", [])
        tag_set = set(tag for tag in tags if isinstance(tag, str))

        score = 0.0
        last_choice = world_facts.get("last_choice")
        last_success = world_facts.get("last_success")
        last_resolution_tier = world_facts.get("last_resolution_tier")
        last_choice_style = world_facts.get("last_choice_style")
        need_recovery = bool(world_facts.get("need_recovery", False))

        if last_choice == "attack":
            if "combat" in tag_set:
                score += 0.28
            if "revelation" in tag_set:
                score += 0.08
        elif last_choice == "talk":
            if "social" in tag_set:
                score += 0.28
            if "mystery" in tag_set:
                score += 0.1
        elif last_choice == "investigate":
            if "mystery" in tag_set:
                score += 0.26
            if "exploration" in tag_set:
                score += 0.12
        elif last_choice == "explore":
            if "travel" in tag_set or "exploration" in tag_set:
                score += 0.24
        elif last_choice in {"defend", "retreat", "wait", "use_item"}:
            if "recovery" in tag_set:
                score += 0.22
            if "social" in tag_set:
                score += 0.08

        if last_success is False:
            if "recovery" in tag_set:
                score += 0.16
            if "combat" in tag_set:
                score -= 0.08

        if last_resolution_tier == "favorable":
            if "revelation" in tag_set or "mystery" in tag_set:
                score += 0.12
        elif last_resolution_tier == "neutral":
            if "mystery" in tag_set:
                score += 0.1
            if "social" in tag_set:
                score += 0.06
        elif last_resolution_tier == "negative":
            if "recovery" in tag_set:
                score += 0.14
            if "combat" in tag_set:
                score -= 0.08

        if need_recovery and "recovery" in tag_set:
            score += 0.14

        if last_choice_style == "diplomatic" and "social" in tag_set:
            score += 0.1

        preferred_world_keys = encounter.get("preferred_world_keys", [])
        if isinstance(preferred_world_keys, list):
            for key in preferred_world_keys:
                if isinstance(key, str) and world_facts.get(key):
                    score += 0.06

        if followup is not None:
            required_tags = followup.get("required_tags", [])
            if isinstance(required_tags, list):
                required_tag_set = {tag for tag in required_tags if isinstance(tag, str) and tag}
                if required_tag_set and tag_set.intersection(required_tag_set):
                    score += 0.22

            primary_tag = followup.get("primary_tag")
            if isinstance(primary_tag, str) and primary_tag and primary_tag in tag_set:
                score += 0.18

            required_thread_ids = followup.get("required_thread_ids", [])
            if isinstance(required_thread_ids, list):
                required_thread_set = {
                    thread_id
                    for thread_id in required_thread_ids
                    if isinstance(thread_id, str) and thread_id
                }
                encounter_thread_set = {
                    thread_id
                    for thread_id in encounter.get("thread_ids", [])
                    if isinstance(thread_id, str) and thread_id
                }
                if required_thread_set and encounter_thread_set and encounter_thread_set.intersection(required_thread_set):
                    score += 0.1

            focus = followup.get("focus")
            if isinstance(focus, str) and focus:
                searchable_text = " ".join(
                    [
                        str(encounter.get("id", "")).lower(),
                        str(encounter.get("title", "")).lower(),
                        str(encounter.get("template_id", "")).lower(),
                    ]
                    + [tag.lower() for tag in encounter.get("tags", []) if isinstance(tag, str)]
                )
                if focus.lower() in searchable_text:
                    score += 0.12

        return _clamp(score, -0.35, 0.55)

    def _relationship_fit_score(self, encounter: dict[str, Any], state: Any) -> float:
        relationships = getattr(getattr(state, "player", object()), "relationships", {})
        if not isinstance(relationships, dict):
            relationships = {}

        social_weight = 0.0
        tags = encounter.get("tags", [])
        if isinstance(tags, list) and any(tag == "social" for tag in tags):
            social_weight = 0.12

        broker = float(relationships.get("broker_nahl", 0.0))
        lyra = float(relationships.get("captain_lyra", 0.0))
        oracle = float(relationships.get("oracle_sable", 0.0))
        return _clamp((broker + lyra + oracle) * social_weight, -0.2, 0.2)

    def _score_candidate(
        self,
        encounter: dict[str, Any],
        state: Any,
        player_model: Any,
        dda: Any,
        beat_type: BeatType,
        followup: FollowupContext | None,
    ) -> tuple[float, dict[str, float]]:
        traits = player_model.trait_vector()
        aggression = _clamp(float(traits.get("aggression", 0.5)))
        caution = _clamp(float(traits.get("caution", 0.5)))
        exploration = _clamp(float(traits.get("exploration", 0.5)))
        social = _clamp(float(traits.get("social", 0.5)))

        encounter_tags = encounter.get("tags", [])
        tag_set = set(tag for tag in encounter_tags if isinstance(tag, str))

        trait_match = 0.35
        if "combat" in tag_set:
            trait_match += aggression * 0.45 + (1.0 - caution) * 0.15
        if "social" in tag_set:
            trait_match += social * 0.5
        if "exploration" in tag_set:
            trait_match += exploration * 0.45
        if "mystery" in tag_set:
            trait_match += exploration * 0.2 + caution * 0.1
        trait_match = _clamp(trait_match)

        target_difficulty = _clamp(float(dda.difficulty_target()))
        candidate_difficulty = _clamp(float(encounter.get("difficulty", 0.5)))
        difficulty_match = _clamp(1.0 - abs(target_difficulty - candidate_difficulty))

        active_threads = set(getattr(getattr(state, "narrative", object()), "active_thread_ids", []))
        candidate_threads = set(encounter.get("thread_ids", []))
        if active_threads and candidate_threads:
            thread_relevance = len(active_threads.intersection(candidate_threads)) / len(active_threads)
        else:
            thread_relevance = 0.2

        recent_tags = getattr(getattr(state, "narrative", object()), "recent_scene_tags", [])
        if recent_tags and tag_set:
            overlap = len(tag_set.intersection(set(recent_tags[-10:])))
            novelty_penalty = _clamp(overlap / max(1.0, float(len(tag_set))), 0.0, 1.0)
        else:
            novelty_penalty = 0.0

        scene_id = encounter.get("id")
        scene_repeat_penalty = 0.0
        if isinstance(scene_id, str) and scene_id:
            repeat_count = self._scene_repeat_count(state, scene_id)
            scene_repeat_penalty = _clamp(repeat_count * 0.14, 0.0, 0.8)

        pacing_bonus = 0.2
        if beat_type == "recovery" and getattr(getattr(state, "player", object()), "health", 100) < 45:
            pacing_bonus += 0.25
        if beat_type == "revelation" and active_threads:
            pacing_bonus += 0.15
        if beat_type == "travel" and len(getattr(state, "visited_locations", [])) < 3:
            pacing_bonus += 0.12

        continuity_score = self._continuity_score(encounter, state, followup)
        relationship_score = self._relationship_fit_score(encounter, state)

        utility = (
            0.28 * trait_match
            + 0.22 * difficulty_match
            + 0.18 * thread_relevance
            + 0.12 * pacing_bonus
            + 0.16 * continuity_score
            + 0.04 * relationship_score
            - 0.28 * novelty_penalty
            - 0.45 * scene_repeat_penalty
            + random.uniform(-0.03, 0.03)
        )

        breakdown = {
            "trait_match": round(trait_match, 4),
            "difficulty_match": round(difficulty_match, 4),
            "thread_relevance": round(thread_relevance, 4),
            "novelty_penalty": round(novelty_penalty, 4),
            "scene_repeat_penalty": round(scene_repeat_penalty, 4),
            "pacing_bonus": round(pacing_bonus, 4),
            "continuity_score": round(continuity_score, 4),
            "relationship_score": round(relationship_score, 4),
            "utility": round(utility, 4),
        }
        return utility, breakdown

    def _fallback_encounter(self, beat_type: BeatType) -> dict[str, Any]:
        return {
            "id": f"fallback_{beat_type}",
            "title": "Quiet Between Storms",
            "beat_types": [beat_type],
            "difficulty": 0.4,
            "tags": [beat_type, "fallback"],
            "template_id": "fallback_scene",
            "location_ids": ["*"],
            "thread_ids": [],
            "choices": ["investigate", "talk", "wait"],
            "choice_text": {
                "investigate": "Search for clues in the quiet.",
                "talk": "Speak with a nearby traveler.",
                "wait": "Hold your position and observe.",
            },
            "choice_tags": {
                "investigate": ["exploration", "mystery"],
                "talk": ["social"],
                "wait": ["caution", "recovery"],
            },
            "base_risk": {"investigate": 0.45, "talk": 0.25, "wait": 0.1},
            "effects": {},
            "text_vars": {"hook": "A pause in the chaos leaves room for a decision."},
        }

    def _collect_candidates(
        self,
        state: Any,
        beat_type: BeatType,
        *,
        enforce_cooldown: bool,
        strict_context: bool,
        followup: FollowupContext | None,
        followup_strict: bool,
        allow_beat_override: bool,
    ) -> list[dict[str, Any]]:
        current_location = getattr(getattr(state, "player", object()), "location_id", "crossroads")
        candidates: list[dict[str, Any]] = []

        for encounter in self._content_db.list_encounters():
            if strict_context:
                if not self._encounter_matches_context(
                    encounter,
                    state,
                    beat_type,
                    enforce_cooldown=enforce_cooldown,
                    followup=followup,
                    followup_strict=followup_strict,
                    allow_beat_override=allow_beat_override,
                ):
                    continue
            else:
                if not allow_beat_override and beat_type not in encounter.get("beat_types", []):
                    continue
                location_ids = encounter.get("location_ids", [])
                if isinstance(location_ids, list) and location_ids and "*" not in location_ids and current_location not in location_ids:
                    continue
                if not self._world_fact_filters_ok(encounter, state):
                    continue
                if not self._inventory_filters_ok(encounter, state):
                    continue
                if not self._relationship_filters_ok(encounter, state):
                    continue
                if not self._thread_progress_filters_ok(encounter, state):
                    continue
                if not self._scene_repeat_constraints_ok(encounter, state, enforce_cooldown=enforce_cooldown):
                    continue
                if not self._scene_blocklist_ok(encounter, state):
                    continue
                if not self._encounter_matches_followup(encounter, followup, strict=followup_strict):
                    continue
            candidates.append(encounter)

        return candidates

    def generate_scene_spec(
        self,
        state: Any,
        player_model: Any,
        dda: Any,
        beat_type: BeatType,
    ) -> SceneSpec:
        """Return best-scoring scene specification for the requested beat."""
        followup = self._active_followup(state)
        npc_context = self._npc_agent.decide(state, player_model)
        if followup is not None and self._use_dynamic_followup(state, followup):
            special_followup = self._special_followup_scene(state, followup, beat_type)
            if special_followup is not None:
                special_followup = self._apply_immersive_choice_text(special_followup, followup)
                validate_scene_spec(special_followup)
                return special_followup

            dynamic_scene_spec = self._story_generator.generate_followup_scene(
                state=state,
                followup=followup,
                requested_beat=beat_type,
                player_model=player_model,
                dda=dda,
                npc_context=npc_context,
            )
            dynamic_scene_spec = self._apply_immersive_choice_text(dynamic_scene_spec, followup)
            validate_scene_spec(dynamic_scene_spec)
            return dynamic_scene_spec

        candidates: list[dict[str, Any]] = []

        if followup is not None:
            candidates = self._collect_candidates(
                state,
                beat_type,
                enforce_cooldown=True,
                strict_context=True,
                followup=followup,
                followup_strict=True,
                allow_beat_override=False,
            )

            if not candidates:
                candidates = self._collect_candidates(
                    state,
                    beat_type,
                    enforce_cooldown=False,
                    strict_context=True,
                    followup=followup,
                    followup_strict=True,
                    allow_beat_override=False,
                )

            if not candidates:
                candidates = self._collect_candidates(
                    state,
                    beat_type,
                    enforce_cooldown=False,
                    strict_context=False,
                    followup=followup,
                    followup_strict=True,
                    allow_beat_override=False,
                )

            if not candidates:
                candidates = self._collect_candidates(
                    state,
                    beat_type,
                    enforce_cooldown=False,
                    strict_context=False,
                    followup=followup,
                    followup_strict=True,
                    allow_beat_override=True,
                )

            if not candidates:
                candidates = self._collect_candidates(
                    state,
                    beat_type,
                    enforce_cooldown=False,
                    strict_context=False,
                    followup=followup,
                    followup_strict=False,
                    allow_beat_override=True,
                )

        if not candidates:
            candidates = self._collect_candidates(
                state,
                beat_type,
                enforce_cooldown=True,
                strict_context=True,
                followup=None,
                followup_strict=False,
                allow_beat_override=False,
            )

        if not candidates:
            candidates = self._collect_candidates(
                state,
                beat_type,
                enforce_cooldown=False,
                strict_context=True,
                followup=None,
                followup_strict=False,
                allow_beat_override=False,
            )

        if not candidates:
            candidates = self._collect_candidates(
                state,
                beat_type,
                enforce_cooldown=False,
                strict_context=False,
                followup=None,
                followup_strict=False,
                allow_beat_override=False,
            )

        if not candidates:
            candidates = [self._fallback_encounter(beat_type)]

        scored: list[tuple[float, dict[str, float], dict[str, Any]]] = []
        for encounter in candidates:
            score, breakdown = self._score_candidate(encounter, state, player_model, dda, beat_type, followup)
            scored.append((score, breakdown, encounter))

        best_score, best_breakdown, selected = max(scored, key=lambda row: row[0])

        text_vars: dict[str, Any] = {}
        source_text_vars = selected.get("text_vars", {})
        if isinstance(source_text_vars, dict):
            text_vars.update(source_text_vars)

        if followup is not None:
            followup_narrative = followup.get("narrative")
            if isinstance(followup_narrative, str) and followup_narrative.strip():
                text_vars["continuity_line"] = followup_narrative.strip()

        text_vars.setdefault("hook", selected.get("title", "Something shifts in the dark."))
        text_vars.setdefault("npc_goal", npc_context.get("goal", "observe"))
        text_vars.setdefault("npc_tone", npc_context.get("tone", "measured"))
        text_vars.setdefault("difficulty", f"{float(selected.get('difficulty', 0.5)):.2f}")

        selected_beat_type: BeatType = beat_type
        selected_beats = selected.get("beat_types", [])
        if isinstance(selected_beats, list):
            for candidate_beat in selected_beats:
                if candidate_beat == beat_type:
                    selected_beat_type = beat_type
                    break
            else:
                first_beat = selected_beats[0] if selected_beats else beat_type
                if isinstance(first_beat, str) and first_beat in _VALID_BEAT_TYPES:
                    selected_beat_type = first_beat

        current_location = getattr(getattr(state, "player", object()), "location_id", "crossroads")
        scene_spec: SceneSpec = {
            "scene_id": str(selected.get("id", f"generated_{beat_type}")),
            "title": str(selected.get("title", "Untitled Encounter")),
            "beat_type": selected_beat_type,
            "template_id": str(selected.get("template_id", "fallback_scene")),
            "text_vars": text_vars,
            "choices": list(selected.get("choices", ["wait"])),
            "choice_text": dict(selected.get("choice_text", {"wait": "Wait."})),
            "choice_tags": dict(selected.get("choice_tags", {})),
            "base_risk": dict(selected.get("base_risk", {})),
            "effects": dict(selected.get("effects", {})),
            "tags": list(selected.get("tags", [beat_type])),
            "location_id": current_location,
            "difficulty": _clamp(float(selected.get("difficulty", 0.5))),
            "thread_ids": list(selected.get("thread_ids", [])),
            "metadata": {
                "utility": best_breakdown,
                "raw_score": round(best_score, 4),
                "npc_context": npc_context,
                "followup": followup,
            },
        }

        scene_spec = self._apply_immersive_choice_text(scene_spec, followup)
        validate_scene_spec(scene_spec)
        return scene_spec
