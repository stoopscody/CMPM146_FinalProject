"""Entry point and orchestration loop for Adaptive AI Dungeon Master."""

from __future__ import annotations

import argparse
import random
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ai.dda import DDAController
from ai.dm_bt import DMBT
from ai.dm_policy import DMPolicy
from ai.goap import GOAPPlanner
from ai.player_model import PlayerModel
from contracts import ActionType, ResolutionTier, TurnRecord
from game.content import ContentDB
from game.logger import RunLogger
from game.resolver import resolve_choice
from game.scene import list_choices, render_scene
from game.state import GameState, PlotThread


def _build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Adaptive AI Dungeon Master")
    parser.add_argument("--turns", type=int, default=20, help="Max turns to run")
    parser.add_argument("--seed", type=int, default=146, help="RNG seed for reproducibility")
    parser.add_argument(
        "--autoplay",
        action="store_true",
        help="Automatically choose actions instead of prompting for input",
    )
    parser.add_argument(
        "--log",
        type=str,
        default="",
        help="Optional explicit path for JSONL log output",
    )
    return parser


def _humanize_id(value: str) -> str:
    return value.replace("_", " ").strip().title()


def _stable_pick(options: list[str], key: str) -> str:
    if not options:
        return ""
    index = sum(ord(ch) for ch in key) % len(options)
    return options[index]


def _location_name(content_db: ContentDB, location_id: str) -> str:
    try:
        location = content_db.get_location(location_id)
        name = location.get("name")
        if isinstance(name, str) and name:
            return name
    except Exception:
        pass
    return _humanize_id(location_id)


def _choose_action(choices: list[ActionType], choice_text: dict[str, str], autoplay: bool) -> ActionType:
    if autoplay:
        return random.choice(choices)

    print("\nChoose an action:")
    for index, action in enumerate(choices, start=1):
        label = choice_text.get(action, action.replace("_", " ").title())
        print(f"  {index}. {label}")

    while True:
        raw = input("> ").strip().lower()
        if raw in {"q", "quit", "exit"}:
            raise KeyboardInterrupt
        if raw.isdigit():
            selected_index = int(raw)
            if 1 <= selected_index <= len(choices):
                return choices[selected_index - 1]
        if raw in choices:
            return raw  # type: ignore[return-value]
        print("Enter a choice number, action keyword, or 'q' to quit.")


def _clear_console() -> None:
    """Clear the terminal screen during interactive play."""
    if not sys.stdout.isatty():
        return
    print("\033[2J\033[H", end="", flush=True)


def _initialize_threads(state: GameState, content_db: ContentDB) -> None:
    for thread_data in content_db.list_threads():
        thread_id = str(thread_data.get("id", "")).strip()
        if not thread_id:
            continue
        title = str(thread_data.get("title", thread_id.replace("_", " ").title()))
        priority = float(thread_data.get("priority", 0.5))
        state.plot_threads[thread_id] = PlotThread(
            thread_id=thread_id,
            title=title,
            status="active",
            progress=0.0,
            priority=max(0.0, min(1.0, priority)),
            metadata={"description": thread_data.get("description", "")},
        )
    state.narrative.active_thread_ids = sorted(state.plot_threads.keys())


def _initialize_world_map(state: GameState, content_db: ContentDB) -> None:
    location_neighbors: dict[str, list[str]] = {}
    for location in content_db.list_locations():
        if not isinstance(location, dict):
            continue
        location_id = location.get("id")
        if not isinstance(location_id, str) or not location_id:
            continue
        neighbors_raw = location.get("neighbors", [])
        neighbors = [
            neighbor
            for neighbor in neighbors_raw
            if isinstance(neighbor, str) and neighbor
        ]
        if neighbors:
            location_neighbors[location_id] = neighbors

    state.world_facts["location_neighbors"] = location_neighbors


def _print_turn_header(state: GameState, content_db: ContentDB) -> None:
    location_id = state.player.location_id
    location_name = _location_name(content_db, location_id)

    print("\n" + "=" * 72)
    print(
        f"Turn {state.narrative.turn_index} | "
        f"Location: {location_name} | "
        f"Health: {state.player.health} | "
        f"Tension: {state.narrative.tension:.2f}"
    )
    print("=" * 72)


def _thread_completion_count(state: GameState) -> int:
    return sum(1 for thread in state.plot_threads.values() if thread.status == "resolved")


def _intro_paragraph(state: GameState, content_db: ContentDB) -> str:
    location_id = state.player.location_id
    location_name = _location_name(content_db, location_id)

    try:
        location = content_db.get_location(location_id)
        location_description = str(location.get("description", "A fragile calm hangs over the city."))
        neighbors = [
            neighbor
            for neighbor in location.get("neighbors", [])
            if isinstance(neighbor, str) and neighbor
        ]
    except Exception:
        location_description = "A fragile calm hangs over the city."
        neighbors = []

    thread_titles = [thread.title for thread in state.plot_threads.values()][:3]
    if thread_titles:
        if len(thread_titles) == 1:
            thread_text = thread_titles[0]
        elif len(thread_titles) == 2:
            thread_text = f"{thread_titles[0]} and {thread_titles[1]}"
        else:
            thread_text = f"{thread_titles[0]}, {thread_titles[1]}, and {thread_titles[2]}"
    else:
        thread_text = "unresolved regional tensions"

    neighbor_names = [_location_name(content_db, neighbor_id) for neighbor_id in neighbors[:2]]
    if len(neighbor_names) == 2:
        route_text = f"Roads from here split toward {neighbor_names[0]} and {neighbor_names[1]}"
    elif len(neighbor_names) == 1:
        route_text = f"The main road from here bends toward {neighbor_names[0]}"
    else:
        route_text = "Every road from here disappears into contested ground"

    return (
        f"Night settles over {location_name}. {location_description} "
        "Lanterns sway in the wind, sentries trade rumors in low voices, and everyone watches the horizon "
        "for the next sign that peace is about to break. "
        f"{route_text}, and none of them are safe for long. "
        f"Across the region, {thread_text} are all moving at once, and the people around you know it. "
        "From this point forward, each decision you make changes who holds power, who gets hurt, and what this world becomes."
    )


def _capture_state_snapshot(state: GameState) -> dict[str, Any]:
    return {
        "health": state.player.health,
        "tension": state.narrative.tension,
        "location_id": state.player.location_id,
        "inventory": set(state.player.inventory),
        "resolved_threads": {
            thread_id
            for thread_id, thread in state.plot_threads.items()
            if thread.status == "resolved"
        },
    }


def _health_reason(health_delta: int, beat_type: str, choice: ActionType, tier: ResolutionTier | None) -> str:
    if health_delta > 0:
        if choice in {"defend", "wait", "use_item"}:
            return "you find space to recover and stabilize"
        return "your momentum gives you a brief opening to recover"
    if health_delta < 0:
        if tier == "favorable":
            return f"the {beat_type} pressure still drains you despite partial success"
        if tier == "neutral":
            return f"the {beat_type} challenge costs you effort even without a full setback"
        return {
            "combat": "enemy pressure breaks through your guard",
            "mystery": "uncertainty and hidden threats catch up with you",
            "revelation": "the fallout from new truths turns violent",
            "social": "negotiations break down into direct danger",
            "exploration": "terrain hazards punish the push forward",
            "travel": "the route itself grinds you down",
            "recovery": "you fail to fully stabilize in time",
        }.get(beat_type, "the situation turns against you")
    if tier == "neutral":
        return "you hold position without clear gain"
    return "your condition remains steady"


def _tension_reason(tension_delta: float, beat_type: str, tier: ResolutionTier | None) -> str:
    if tension_delta > 0:
        if tier == "favorable":
            return {
                "combat": "victory escalates the conflict anyway",
                "mystery": "answers expose bigger risks",
                "revelation": "new truths destabilize old alliances",
                "social": "new deals create fresh rivals",
                "exploration": "progress takes you deeper into danger",
                "travel": "movement exposes more fronts",
                "recovery": "you recover, but pressure remains",
            }.get(beat_type, "the situation keeps escalating")
        if tier == "neutral":
            return {
                "combat": "the clash remains unresolved and dangerous",
                "mystery": "partial clues increase uncertainty",
                "revelation": "new leads create as many problems as answers",
                "social": "talks stall and strain tempers",
                "exploration": "the route remains unstable",
                "travel": "movement reveals new risks",
                "recovery": "recovery buys only limited time",
            }.get(beat_type, "pressure climbs without a clear breakthrough")
        return {
            "combat": "the fight spills wider",
            "mystery": "confusion compounds the danger",
            "revelation": "the truth triggers backlash",
            "social": "political friction intensifies",
            "exploration": "the unknown pushes back",
            "travel": "the route remains unstable",
            "recovery": "recovery is incomplete",
        }.get(beat_type, "pressure rises")
    if tension_delta < 0:
        return {
            "recovery": "the pause lets people regroup",
            "social": "dialogue cools the situation",
            "combat": "the immediate threat is contained",
            "mystery": "clearer information reduces panic",
            "revelation": "clarity gives your side direction",
            "exploration": "you secure a safer position",
            "travel": "you establish a safer route",
        }.get(beat_type, "the pressure eases for now")
    return "the strategic pressure holds steady"


def _print_between_turn_summary(
    *,
    state: GameState,
    before: dict[str, Any],
    scene_spec: dict[str, Any],
    choice: ActionType,
    outcome: dict[str, Any],
    content_db: ContentDB,
) -> None:
    beat_type = str(scene_spec.get("beat_type", "unknown"))
    resolution_tier: ResolutionTier | None = None
    raw_tier = outcome.get("resolution_tier")
    if raw_tier in {"favorable", "neutral", "negative"}:
        resolution_tier = raw_tier
    success = outcome.get("success")
    world_facts = outcome.get("world_facts", {})
    if not isinstance(world_facts, dict):
        world_facts = {}

    parts: list[str] = []
    choice_text_map = scene_spec.get("choice_text", {})
    choice_label = (
        str(choice_text_map.get(choice))
        if isinstance(choice_text_map, dict) and isinstance(choice_text_map.get(choice), str)
        else choice.replace("_", " ").title()
    )
    scene_title = str(scene_spec.get("title", scene_spec.get("scene_id", "this moment")))
    choice_phrase = choice_label.lower().rstrip(".")
    seed_base = f"{state.narrative.turn_index}:{scene_title}:{choice}:{resolution_tier}"

    story_opening = world_facts.get("followup_story_opening")
    story_consequence = world_facts.get("followup_story_consequence")
    story_aftermath = world_facts.get("followup_story_aftermath")
    has_story_bundle = all(
        isinstance(value, str) and value.strip()
        for value in (story_opening, story_consequence, story_aftermath)
    )

    if has_story_bundle:
        parts.append(str(story_opening).strip().rstrip(".") + ".")
        parts.append(str(story_consequence).strip().rstrip(".") + ".")
        parts.append(str(story_aftermath).strip().rstrip(".") + ".")
    else:
        if resolution_tier == "favorable":
            openers = [
                f"You commit to {choice_phrase} at {scene_title}, and this time it lands cleanly.",
                f"At {scene_title}, your call to {choice_phrase} pays off and gives you momentum.",
                f"The move to {choice_phrase} at {scene_title} works, and your side takes the initiative.",
            ]
        elif resolution_tier == "neutral":
            openers = [
                f"You {choice_phrase} at {scene_title}, but only part of the plan holds.",
                f"At {scene_title}, {choice_phrase} gets you progress, not control.",
                f"The choice to {choice_phrase} at {scene_title} keeps things moving, but leaves loose ends.",
            ]
        elif resolution_tier == "negative":
            openers = [
                f"You {choice_phrase} at {scene_title}, and the world answers with immediate resistance.",
                f"At {scene_title}, your attempt to {choice_phrase} goes sideways fast.",
                f"The moment you {choice_phrase} at {scene_title}, pressure turns against you.",
            ]
        elif success is True:
            openers = [
                f"You {choice_phrase} at {scene_title} and come out ahead, though the cost is still unfolding.",
                f"The call to {choice_phrase} at {scene_title} works, even if the fallout is not over yet.",
            ]
        elif success is False:
            openers = [
                f"You try to {choice_phrase} at {scene_title}, and it backfires immediately.",
                f"At {scene_title}, {choice_phrase} does not hold, and complications hit at once.",
            ]
        else:
            openers = [
                f"You {choice_phrase} at {scene_title}, and the consequences come in mixed waves.",
                f"The choice to {choice_phrase} at {scene_title} leaves the field unsettled.",
            ]
        parts.append(_stable_pick(openers, f"{seed_base}:opener"))

    roll_sentence = ""
    metadata = outcome.get("metadata", {})
    if isinstance(metadata, dict):
        roll_kind = metadata.get("roll_kind")
        roll_value = metadata.get("roll_value")
        if roll_kind == "three_way" and isinstance(roll_value, int):
            tier_name = {1: "negative", 2: "neutral", 3: "positive"}.get(roll_value, "unknown")
            roll_options = [
                f"the three-way roll comes up {roll_value}, a {tier_name} swing",
                f"luck shows {roll_value} on the three-way roll, which reads as a {tier_name} turn",
                f"the roll lands on {roll_value}, which means a {tier_name} outcome",
            ]
            roll_sentence = _stable_pick(roll_options, f"{seed_base}:roll").rstrip(".")

    health_delta = int(state.player.health - int(before["health"]))
    tension_delta = float(state.narrative.tension - float(before["tension"]))
    mechanics_bits: list[str] = []

    if roll_sentence:
        mechanics_bits.append(roll_sentence)

    if health_delta != 0:
        reason = _health_reason(health_delta, beat_type, choice, resolution_tier)
        if health_delta > 0:
            mechanics_bits.append(f"you recover {health_delta} health as {reason}")
        else:
            mechanics_bits.append(f"you lose {abs(health_delta)} health as {reason}")
    else:
        mechanics_bits.append("your health holds steady")

    if abs(tension_delta) > 1e-9:
        reason = _tension_reason(tension_delta, beat_type, resolution_tier)
        mechanics_bits.append(f"regional tension shifts {tension_delta:+.2f} because {reason}")

    if mechanics_bits:
        mechanics_prefix = _stable_pick(
            [
                "As the dust settles,",
                "In the fallout,",
                "As fate resolves the moment,",
            ],
            f"{seed_base}:mechanics",
        )
        parts.append(f"{mechanics_prefix} " + "; ".join(mechanics_bits) + ".")

    if world_facts:
        consequence_line = world_facts.get("followup_narrative")
        if (not has_story_bundle) and isinstance(consequence_line, str) and consequence_line.strip():
            parts.append(consequence_line.strip().rstrip(".") + ".")

        hidden_exact_keys = {
            "last_choice",
            "last_choice_style",
            "last_scene_id",
            "last_beat_type",
            "last_resolution_tier",
            "last_roll_kind",
            "last_roll_value",
            "last_success",
            "recent_momentum",
            "need_recovery",
            "followup_turn",
            "followup_primary_tag",
            "followup_required_location",
            "followup_required_tags",
            "followup_required_thread_ids",
            "followup_focus",
            "followup_mode",
            "followup_depth",
            "followup_chain_id",
            "followup_branch_signature",
            "followup_root_scene",
            "followup_narrative",
            "followup_story_opening",
            "followup_story_consequence",
            "followup_story_aftermath",
            "followup_branch_hook",
            "followup_branch_goal",
            "followup_source_scene",
            "followup_source_choice",
            "followup_source_tier",
            "scene_blocklist",
            "questline_location",
            "questline_name",
            "questline_chapter",
            "questline_total_chapters",
        }
        hidden_prefixes = ("choice_count_",)

        impact_notes: list[str] = []
        for key, value in world_facts.items():
            if key in hidden_exact_keys or any(key.startswith(prefix) for prefix in hidden_prefixes):
                continue
            label = _humanize_id(key)
            if isinstance(value, bool):
                if value:
                    impact_notes.append(label)
            elif isinstance(value, str) and value:
                impact_notes.append(f"{label}: {value.replace('_', ' ')}")
            elif isinstance(value, (int, float)):
                impact_notes.append(f"{label}: {value}")
            if len(impact_notes) >= 4:
                break

        if impact_notes:
            parts.append(
                _stable_pick(
                    [
                        f"In the wider world, that move leaves marks: {'; '.join(impact_notes)}.",
                        f"The board shifts with it: {'; '.join(impact_notes)}.",
                        f"Beyond your immediate position, the ripple is clear: {'; '.join(impact_notes)}.",
                    ],
                    f"{seed_base}:impact",
                )
            )

        branch_goal_line = world_facts.get("followup_branch_goal")
        if isinstance(branch_goal_line, str) and branch_goal_line.strip():
            parts.append(branch_goal_line.strip().rstrip(".") + ".")

        next_focus_raw = world_facts.get("followup_focus")
        next_location_raw = world_facts.get("route_transition_target")
        if isinstance(next_focus_raw, str) and next_focus_raw:
            next_focus = next_focus_raw.replace("_", " ").strip().lower()
            if not next_focus.startswith(("the ", "a ", "an ")):
                next_focus = f"the {next_focus}"
            if isinstance(next_location_raw, str) and next_location_raw:
                next_location_name = _location_name(content_db, next_location_raw)
                parts.append(
                    _stable_pick(
                        [
                            f"Attention now swings to {next_focus}, and that thread pulls you toward {next_location_name}.",
                            f"The next lead points at {next_focus}, with your path bending toward {next_location_name}.",
                            f"All signs now point to {next_focus}; following it means heading for {next_location_name}.",
                        ],
                        f"{seed_base}:nextloc",
                    )
                )
            else:
                parts.append(
                    _stable_pick(
                        [
                            f"The next lead sits with {next_focus}, and your next decision decides whether it opens or collapses.",
                            f"Your attention is pulled toward {next_focus}; what you do next decides whether it becomes a path or a trap.",
                            f"The pressure now centers on {next_focus}, waiting on your next move.",
                        ],
                        f"{seed_base}:nextfocus",
                    )
                )

        questline_name = world_facts.get("questline_name")
        questline_chapter = world_facts.get("questline_chapter")
        questline_total = world_facts.get("questline_total_chapters")
        if (
            isinstance(questline_name, str)
            and questline_name.strip()
            and isinstance(questline_chapter, int)
            and isinstance(questline_total, int)
            and questline_chapter > 0
            and questline_total > 0
        ):
            parts.append(
                f"You are in {questline_name}, chapter {questline_chapter} of {questline_total}."
            )

    events = outcome.get("events", [])
    if isinstance(events, list):
        notable_events: list[str] = []
        for event in events:
            if not isinstance(event, dict):
                continue
            event_type = event.get("type")
            if not isinstance(event_type, str) or event_type == "choice_roll_resolved":
                continue
            detail = event.get("detail")
            if isinstance(detail, str) and detail:
                notable_events.append(f"{_humanize_id(event_type)}: {detail}")
            else:
                notable_events.append(_humanize_id(event_type))
            if len(notable_events) >= 3:
                break
        if notable_events:
            parts.append(
                _stable_pick(
                    [
                        f"Before anyone can reset, {'; '.join(notable_events)}.",
                        f"Side effects spread quickly: {'; '.join(notable_events)}.",
                        f"At the edges of the action, {'; '.join(notable_events)}.",
                    ],
                    f"{seed_base}:events",
                )
            )

    previous_location_id = str(before["location_id"])
    if state.player.location_id != previous_location_id:
        from_name = _location_name(content_db, previous_location_id)
        to_name = _location_name(content_db, state.player.location_id)
        parts.append(
            _stable_pick(
                [
                    f"By the end of it, you are forced from {from_name} to {to_name}.",
                    f"The fallout pushes you out of {from_name} and into {to_name}.",
                    f"When the moment clears, you are no longer in {from_name}; you are in {to_name}.",
                ],
                f"{seed_base}:movement",
            )
        )

    before_inventory = before["inventory"]
    after_inventory = set(state.player.inventory)
    gained_items = sorted(after_inventory - before_inventory)
    lost_items = sorted(before_inventory - after_inventory)
    if gained_items:
        parts.append("You pick up " + ", ".join(_humanize_id(item) for item in gained_items) + ".")
    if lost_items:
        parts.append("You burn through " + ", ".join(_humanize_id(item) for item in lost_items) + ".")

    thread_updates = outcome.get("plot_threads", [])
    if isinstance(thread_updates, list) and thread_updates:
        progress_by_thread: dict[str, float | None] = {}
        for update in thread_updates:
            if not isinstance(update, dict):
                continue
            thread_id = update.get("thread_id")
            if not isinstance(thread_id, str) or thread_id not in state.plot_threads:
                continue
            progress_delta = update.get("progress_delta")
            if isinstance(progress_delta, (int, float)):
                total = progress_by_thread.get(thread_id)
                if total is None:
                    progress_by_thread[thread_id] = float(progress_delta)
                else:
                    progress_by_thread[thread_id] = total + float(progress_delta)
            else:
                progress_by_thread.setdefault(thread_id, None)
        progress_notes: list[str] = []
        for thread_id, progress_delta in progress_by_thread.items():
            title = state.plot_threads[thread_id].title
            if isinstance(progress_delta, float):
                progress_notes.append(f"{title} ({progress_delta:+.2f})")
            else:
                progress_notes.append(title)
        if progress_notes:
            parts.append("That pushes the larger story forward: " + ", ".join(progress_notes) + ".")

    newly_resolved = sorted(
        thread_id
        for thread_id in (
            {
                thread_id
                for thread_id, thread in state.plot_threads.items()
                if thread.status == "resolved"
            }
            - before["resolved_threads"]
        )
    )
    if newly_resolved:
        parts.append(
            "One thread finally closes: "
            + ", ".join(state.plot_threads[thread_id].title for thread_id in newly_resolved)
            + "."
        )

    print("\nWhat follows:")
    print(" ".join(part.strip() for part in parts if part).strip())


def main() -> None:
    """Run the full Adaptive AI Dungeon Master gameplay loop."""
    parser = _build_argument_parser()
    args = parser.parse_args()

    random.seed(args.seed)

    project_root = Path(__file__).resolve().parent
    content_db = ContentDB(content_dir=str(project_root / "content"))

    state = GameState()
    _initialize_threads(state, content_db)
    _initialize_world_map(state, content_db)

    player_model = PlayerModel()
    dda = DDAController()
    dm_bt = DMBT()
    dm_policy = DMPolicy(content_db=content_db)
    goap_planner = GOAPPlanner()

    log_path = args.log.strip()
    if not log_path:
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        log_path = str(project_root / "logs" / f"run_{timestamp}.jsonl")
    logger = RunLogger(path=log_path)

    templates = content_db.list_templates()

    print("Adaptive AI Dungeon Master")
    print("Type a number to choose an action. Type 'q' to quit.")
    print("\n" + _intro_paragraph(state, content_db))

    try:
        for turn in range(1, max(1, args.turns) + 1):
            state.narrative.turn_index = turn
            _print_turn_header(state, content_db)

            beat_type = dm_bt.choose_beat(state, player_model, dda)
            state.narrative.beat_history.append(beat_type)
            if len(state.narrative.beat_history) > 20:
                state.narrative.beat_history = state.narrative.beat_history[-20:]

            scene_spec = dm_policy.generate_scene_spec(state, player_model, dda, beat_type)
            scene_meta = scene_spec.get("metadata", {})
            if "active_entity" in scene_meta and scene_meta["active_entity"]:
                state.world_facts["active_entity"] = scene_meta["active_entity"]
                state.narrative.active_entity = scene_meta["active_entity"]
            if "questline_chapter" in scene_meta and scene_meta["questline_chapter"]:
                state.world_facts["current_chapter"] = scene_meta["questline_chapter"]
                state.narrative.current_chapter = scene_meta["questline_chapter"]
            scene_beat = scene_spec.get("beat_type", beat_type)
            if scene_beat != beat_type and state.narrative.beat_history:
                state.narrative.beat_history[-1] = scene_beat
            rendered_scene = render_scene(scene_spec, templates, content_db)
            choices = list_choices(scene_spec)

            print(f"\n[{scene_spec.get('title', scene_spec['scene_id'])}] ({scene_beat})")
            print(rendered_scene)

            choice = _choose_action(choices, scene_spec.get("choice_text", {}), autoplay=args.autoplay)
            if not args.autoplay:
                _clear_console()

            before_snapshot = _capture_state_snapshot(state)
            outcome, observation = resolve_choice(state, scene_spec, choice)
            player_model.observe(observation)
            dda.push_outcome(outcome)
            state.apply_outcome(outcome)
            state.push_scene_tags(scene_spec.get("tags", []))

            turn_record: TurnRecord = {
                "turn_index": turn,
                "beat_type": scene_beat,
                "scene_spec": scene_spec,
                "rendered_scene": rendered_scene,
                "choice": choice,
                "outcome": outcome,
                "observation": observation,
                "player_traits": player_model.trait_vector(),
                "archetype": player_model.archetype(),
                "performance_score": round(dda.performance_score(), 4),
                "difficulty_target": dda.difficulty_target(),
                "state_summary": state.summary(),
            }
            logger.log_turn(turn_record)

            if args.autoplay:
                print(f"Auto-choice: {choice}")

            if state.player.health <= 0:
                print("\nYou collapse before the story can finish. Game over.")
                break

            resolved_threads = _thread_completion_count(state)
            goal_reached = goap_planner.evaluate_goals(
                facts={
                    "threads_resolved": resolved_threads,
                    "is_in_narrative_chain": bool(state.narrative.is_in_narrative_chain),
                    "current_chapter": int(state.narrative.current_chapter),
                    "max_chapters": int(state.narrative.max_chapters),
                    "node_type": str(state.narrative.node_type or "hub"),
                },
                goals={"threads_resolved": 2},
            )
            if goal_reached:
                print("\nTwo major plot threads are resolved. The region enters a fragile peace.")
                break

        print("\nRun summary")
        print(f"- Final health: {state.player.health}")
        print(f"- Final location: {state.player.location_id}")
        print(f"- Tension: {state.narrative.tension:.2f}")
        print(f"- Archetype: {player_model.archetype()}")
        print(f"- Difficulty target: {dda.difficulty_target():.2f}")
        print(f"- Threads resolved: {_thread_completion_count(state)}")
        print(f"- Log written to: {log_path}")
    except KeyboardInterrupt:
        print("\nRun interrupted by user.")
    finally:
        logger.close()


if __name__ == "__main__":
    main()
