"""Authoritative game state models and mutation boundary contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from contracts import Outcome, validate_outcome


@dataclass(slots=True)
class PlayerState:
    """Mutable player state owned by `GameState`.

    This stores player location/resources/inventory plus relationship and
    progression flags. Resolver outputs should only produce deltas; GameState
    applies those deltas here.
    """

    name: str = "Adventurer"
    location_id: str = "crossroads"
    health: int = 100
    inventory: list[str] = field(default_factory=list)
    relationships: dict[str, float] = field(default_factory=dict)
    flags: dict[str, bool] = field(default_factory=dict)


@dataclass(slots=True)
class NarrativeState:
    """Narrative pacing memory used by BT/DM policy and logging."""

    turn_index: int = 0
    tension: float = 0.2
    recent_scene_tags: list[str] = field(default_factory=list)
    beat_history: list[str] = field(default_factory=list)
    active_thread_ids: list[str] = field(default_factory=list)
    active_entity: str = ""
    active_entity_location_id: str = ""
    current_chapter: int = 0
    max_chapters: int = 0
    is_in_narrative_chain: bool = False
    node_type: str = "hub"


@dataclass(slots=True)
class PlotThread:
    """Runtime plot thread instance tracking progression and status."""

    thread_id: str = ""
    title: str = ""
    status: str = "inactive"
    progress: float = 0.0
    priority: float = 0.5
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class GameState:
    """Authoritative mutable world state.

    Module boundary rules:
    - DMPolicy and PlayerModel read but do not mutate this state.
    - Resolver returns deltas only.
    - `apply_outcome` is the single mutation point for world changes.
    """

    player: PlayerState = field(default_factory=PlayerState)
    narrative: NarrativeState = field(default_factory=NarrativeState)
    plot_threads: dict[str, PlotThread] = field(default_factory=dict)
    world_facts: dict[str, Any] = field(default_factory=dict)
    event_history: list[dict[str, Any]] = field(default_factory=list)
    visited_locations: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        """Ensure world-travel memory starts with the current player location."""
        start_location = self.player.location_id
        if isinstance(start_location, str) and start_location and start_location not in self.visited_locations:
            self.visited_locations.append(start_location)
        if not self.narrative.active_entity_location_id and isinstance(start_location, str):
            self.narrative.active_entity_location_id = start_location

    def push_scene_tags(self, tags: list[str]) -> None:
        """Append scene tags to short-term narrative memory.

        Keeps a rolling window to support novelty penalties and pacing logic.
        """
        clean_tags = [tag for tag in tags if isinstance(tag, str) and tag]
        if not clean_tags:
            return

        self.narrative.recent_scene_tags.extend(clean_tags)
        max_tags = 24
        if len(self.narrative.recent_scene_tags) > max_tags:
            self.narrative.recent_scene_tags = self.narrative.recent_scene_tags[-max_tags:]

    def push_event(self, event: dict[str, Any]) -> None:
        """Append a world-memory event record with rolling retention."""
        if not isinstance(event, dict):
            raise TypeError("event must be a dict")
        self.event_history.append(dict(event))
        max_events = 500
        if len(self.event_history) > max_events:
            self.event_history = self.event_history[-max_events:]

    def apply_outcome(self, outcome: Outcome) -> None:
        """Apply resolver-produced deltas to the authoritative world state.

        This method updates player stats, inventory, flags, relationships,
        tension, plot thread progression, world facts, and event history.
        """
        validate_outcome(outcome)

        player_delta = outcome.get("player", {})
        if isinstance(player_delta, dict):
            for key, value in player_delta.items():
                if key == "health_delta":
                    self.player.health = max(0, min(100, self.player.health + int(value)))
                elif key == "location_id" and isinstance(value, str) and value:
                    self.player.location_id = value
                    if value not in self.visited_locations:
                        self.visited_locations.append(value)
                elif key == "name" and isinstance(value, str) and value:
                    self.player.name = value
                elif key == "health" and isinstance(value, (int, float)):
                    self.player.health = max(0, min(100, int(value)))

        for item in outcome.get("inventory_add", []):
            if item not in self.player.inventory:
                self.player.inventory.append(item)

        for item in outcome.get("inventory_remove", []):
            if item in self.player.inventory:
                self.player.inventory.remove(item)

        flags = outcome.get("flags", {})
        for flag, value in flags.items():
            self.player.flags[flag] = value

        relationships = outcome.get("relationships", {})
        for entity_id, delta in relationships.items():
            current = self.player.relationships.get(entity_id, 0.0)
            updated = current + float(delta)
            self.player.relationships[entity_id] = max(-1.0, min(1.0, updated))

        tension_delta = float(outcome.get("tension_delta", 0.0))
        self.narrative.tension = max(0.0, min(1.0, self.narrative.tension + tension_delta))

        for thread_update in outcome.get("plot_threads", []):
            self._apply_thread_update(thread_update)

        world_facts = outcome.get("world_facts", {})
        for key, value in world_facts.items():
            self.world_facts[key] = value
        self._sync_narrative_lock_fields()

        for event in outcome.get("events", []):
            self.push_event(event)

    def _apply_thread_update(self, thread_update: dict[str, Any]) -> None:
        thread_id = thread_update.get("thread_id")
        if not isinstance(thread_id, str) or not thread_id:
            return

        if thread_id not in self.plot_threads:
            self.plot_threads[thread_id] = PlotThread(
                thread_id=thread_id,
                title=str(thread_update.get("title", thread_id.replace("_", " ").title())),
                status=str(thread_update.get("status", "active")),
                progress=0.0,
                priority=float(thread_update.get("priority", 0.5)),
                metadata=dict(thread_update.get("metadata", {})),
            )

        thread = self.plot_threads[thread_id]

        if "title" in thread_update and isinstance(thread_update["title"], str):
            thread.title = thread_update["title"]
        if "status" in thread_update and isinstance(thread_update["status"], str):
            thread.status = thread_update["status"]
        if "progress_delta" in thread_update and isinstance(thread_update["progress_delta"], (int, float)):
            thread.progress = max(0.0, min(1.0, thread.progress + float(thread_update["progress_delta"])))
        if "progress" in thread_update and isinstance(thread_update["progress"], (int, float)):
            thread.progress = max(0.0, min(1.0, float(thread_update["progress"])))
        if "priority_delta" in thread_update and isinstance(thread_update["priority_delta"], (int, float)):
            thread.priority = max(0.0, min(1.0, thread.priority + float(thread_update["priority_delta"])))
        if "priority" in thread_update and isinstance(thread_update["priority"], (int, float)):
            thread.priority = max(0.0, min(1.0, float(thread_update["priority"])))

        metadata_patch = thread_update.get("metadata")
        if isinstance(metadata_patch, dict):
            thread.metadata.update(metadata_patch)

        if thread.progress >= 1.0 and thread.status == "active":
            thread.status = "resolved"

        self._sync_active_threads()

    def _sync_active_threads(self) -> None:
        active = [tid for tid, thread in self.plot_threads.items() if thread.status in {"active", "critical"}]
        self.narrative.active_thread_ids = sorted(active)

    def _sync_narrative_lock_fields(self) -> None:
        """Sync narrative-lock facts into fast access narrative state fields."""
        world_facts = self.world_facts

        active_entity = world_facts.get("active_entity")
        if isinstance(active_entity, str):
            self.narrative.active_entity = active_entity.strip().lower()

        active_entity_location = world_facts.get("active_entity_location")
        if isinstance(active_entity_location, str) and active_entity_location:
            self.narrative.active_entity_location_id = active_entity_location

        current_chapter = world_facts.get("current_chapter")
        if isinstance(current_chapter, (int, float)) and not isinstance(current_chapter, bool):
            self.narrative.current_chapter = max(0, int(current_chapter))

        max_chapters = world_facts.get("max_chapters")
        if isinstance(max_chapters, (int, float)) and not isinstance(max_chapters, bool):
            self.narrative.max_chapters = max(0, int(max_chapters))

        chain_flag = world_facts.get("is_in_narrative_chain")
        if isinstance(chain_flag, bool):
            self.narrative.is_in_narrative_chain = chain_flag

        node_type = world_facts.get("node_type")
        if isinstance(node_type, str) and node_type:
            self.narrative.node_type = node_type

    def summary(self) -> dict[str, Any]:
        """Return compact state summary for logging/telemetry."""
        return {
            "turn": self.narrative.turn_index,
            "location_id": self.player.location_id,
            "health": self.player.health,
            "inventory_count": len(self.player.inventory),
            "tension": round(self.narrative.tension, 3),
            "active_entity": self.narrative.active_entity,
            "current_chapter": self.narrative.current_chapter,
            "max_chapters": self.narrative.max_chapters,
            "is_in_narrative_chain": self.narrative.is_in_narrative_chain,
            "node_type": self.narrative.node_type,
            "active_threads": list(self.narrative.active_thread_ids),
            "resolved_threads": [
                thread.thread_id
                for thread in self.plot_threads.values()
                if thread.status == "resolved"
            ],
            "recent_tags": list(self.narrative.recent_scene_tags[-6:]),
        }
