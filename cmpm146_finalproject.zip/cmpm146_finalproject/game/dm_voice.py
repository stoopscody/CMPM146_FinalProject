"""Narrative translation layer that turns state deltas into DM-style prose."""

from __future__ import annotations

from typing import Any


def _sentence(text: str) -> str:
    clean = " ".join(text.split()).strip()
    if not clean:
        return ""
    if clean[-1] not in {".", "!", "?"}:
        clean += "."
    return clean


def _safe_text(value: Any, fallback: str = "") -> str:
    if isinstance(value, str):
        clean = value.strip()
        if clean:
            return clean
    return fallback


def _action_phrase(player_action: str) -> str:
    action = player_action.strip().lower()
    phrases = {
        "attack": "press the attack",
        "defend": "brace and hold your ground",
        "talk": "push the conversation into the open",
        "investigate": "trace the clue trail",
        "explore": "push deeper into the unknown",
        "use_item": "commit your supplies",
        "retreat": "fall back to safer ground",
        "wait": "hold for one decisive beat",
    }
    return phrases.get(action, action.replace("_", " "))


def _normalize_action_label(action_label: str) -> str:
    clean = " ".join(action_label.split()).strip().rstrip(".!?")
    if not clean:
        return clean
    if clean.startswith(("to ", "the ")):
        return clean
    return clean[0].lower() + clean[1:]


def _entity_anchor(entity: str) -> str:
    clean = " ".join(entity.split()).strip()
    if not clean:
        return "the situation"
    if clean.lower().startswith(("the ", "a ", "an ")):
        return clean
    return f"the {clean}"


def _tier_from_roll(dda_roll: Any) -> str:
    if isinstance(dda_roll, dict):
        for key in ("resolution_tier", "action_success_level", "tier"):
            value = dda_roll.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip().lower()
        roll_value = dda_roll.get("roll_value")
        if roll_value == 1:
            return "negative"
        if roll_value == 2:
            return "neutral"
        if roll_value == 3:
            return "favorable"
    if isinstance(dda_roll, str):
        return dda_roll.strip().lower()
    if dda_roll == 1:
        return "negative"
    if dda_roll == 2:
        return "neutral"
    if dda_roll == 3:
        return "favorable"
    return "neutral"


def _default_consequence(tier: str, entity: str) -> str:
    anchor = _entity_anchor(entity)
    if tier == "favorable":
        return f"The pressure around {anchor} shifts in your favor, but it moves fast enough to demand immediate follow-through"
    if tier == "negative":
        return f"The moment turns hard around {anchor}, and the cost lands before you can reset"
    return f"The exchange around {anchor} stays unstable, giving you progress without full control"


def format_dm_response(
    previous_context: dict[str, Any],
    player_action: str,
    dda_roll: dict[str, Any] | str | int,
    new_scene: dict[str, Any],
) -> str:
    """Synthesize one cohesive three-sentence DM paragraph.

    Structure:
    1. Bridge: tie prior action to the active entity.
    2. Consequence: apply DDA/context fallout.
    3. New State: set immediate location threat/opportunity for the next turn.
    """

    active_entity = _safe_text(previous_context.get("active_entity"), "the situation")
    previous_location = _safe_text(previous_context.get("previous_location"), "the last position")
    raw_action_label = _safe_text(previous_context.get("action_label"), _action_phrase(player_action))
    action_label = _normalize_action_label(raw_action_label) or _action_phrase(player_action)
    tier = _tier_from_roll(dda_roll)
    tier_phrase = {
        "favorable": "a favorable result",
        "neutral": "a neutral result",
        "negative": "a negative result",
    }.get(tier, "an uncertain result")

    entity_anchor = _entity_anchor(active_entity)
    action_mentions_entity = active_entity.strip().lower() in action_label.lower()
    if action_mentions_entity:
        bridge = _sentence(f"You {action_label} in {previous_location}, and it resolves as {tier_phrase}")
    else:
        bridge = _sentence(
            f"You {action_label} at {entity_anchor} in {previous_location}, and it resolves as {tier_phrase}"
        )

    consequence_hint = _safe_text(
        previous_context.get("dda_event_triggered"),
        _safe_text(
            previous_context.get("consequence"),
            _default_consequence(tier, active_entity),
        ),
    )
    consequence = _sentence(consequence_hint)

    current_location = _safe_text(new_scene.get("current_location"), "the next stretch of the road")
    setup = _safe_text(new_scene.get("hook"), "The field shifts before anyone fully resets")
    stakes = _safe_text(
        new_scene.get("threat_or_opportunity"),
        _safe_text(new_scene.get("goal_line"), "Your next decision decides whether this opens into leverage or collapse"),
    )
    new_state = _sentence(f"Now in {current_location}, {setup}; {stakes}")

    return " ".join(part for part in (bridge, consequence, new_state) if part).strip()
