"""Structured JSONL run logger."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, TextIO, cast

from contracts import (
    Observation,
    Outcome,
    SceneSpec,
    TurnRecord,
    validate_observation,
    validate_outcome,
    validate_scene_spec,
)


class RunLogger:
    """Write per-turn telemetry as JSON Lines for analysis and debugging."""

    def __init__(self, path: str) -> None:
        self.path = path
        log_path = Path(path)
        if not log_path.is_absolute():
            log_path = Path.cwd() / log_path
        log_path.parent.mkdir(parents=True, exist_ok=True)
        self._handle: TextIO = log_path.open("a", encoding="utf-8")

    def _default_encoder(self, value: Any) -> Any:
        if isinstance(value, set):
            return sorted(value)
        return repr(value)

    def log_turn(self, record: dict[str, Any]) -> None:
        """Validate known payload fields and append one JSON object line."""
        if "scene_spec" in record:
            validate_scene_spec(cast(SceneSpec, record["scene_spec"]))
        if "observation" in record:
            validate_observation(cast(Observation, record["observation"]))
        if "outcome" in record:
            validate_outcome(cast(Outcome, record["outcome"]))

        typed_record: TurnRecord = cast(TurnRecord, dict(record))
        if "timestamp" not in typed_record:
            typed_record["timestamp"] = datetime.now(UTC).isoformat()

        line = json.dumps(typed_record, ensure_ascii=True, default=self._default_encoder)
        self._handle.write(line + "\n")
        self._handle.flush()

    def close(self) -> None:
        """Close the underlying file handle."""
        if not self._handle.closed:
            self._handle.close()
