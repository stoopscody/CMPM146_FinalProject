"""Scene rendering and choice list helpers (read-only behavior)."""

from __future__ import annotations

from typing import Any

from contracts import ActionType, SceneSpec, validate_scene_spec
from game.dm_voice import format_dm_response


class _SafeFormatDict(dict[str, Any]):
    """Mapping that leaves missing format placeholders intact."""

    def __missing__(self, key: str) -> str:
        return "{" + key + "}"


def _stable_pick(options: list[str], key: str) -> str:
    if not options:
        return ""
    index = sum(ord(ch) for ch in key) % len(options)
    return options[index]


def _humanize(value: str) -> str:
    return value.replace("_", " ").strip().title()


def _sentence(text: str) -> str:
    clean = " ".join(text.split()).strip()
    if not clean:
        return ""
    if clean[-1] not in {".", "!", "?"}:
        clean += "."
    return clean


def _select_template(scene_spec: SceneSpec, templates: dict[str, Any]) -> str:
    template_id = scene_spec["template_id"]
    template_value = templates.get(template_id)
    if template_value is None:
        raise KeyError(f"Missing template_id in templates: {template_id!r}")

    if isinstance(template_value, str):
        return template_value

    if isinstance(template_value, dict):
        beat_type = scene_spec["beat_type"]
        if beat_type in template_value and isinstance(template_value[beat_type], str):
            return template_value[beat_type]
        if "default" in template_value and isinstance(template_value["default"], str):
            return template_value["default"]

    if isinstance(template_value, list) and template_value:
        first = template_value[0]
        if isinstance(first, str):
            return first

    raise ValueError(f"Template value for {template_id!r} is not renderable")


def _location_name(scene_spec: SceneSpec, text_vars: dict[str, Any], content_db: Any) -> str:
    explicit_name = text_vars.get("location_name")
    if isinstance(explicit_name, str) and explicit_name.strip():
        return explicit_name.strip()

    location_id = scene_spec["location_id"]
    try:
        location = content_db.get_location(location_id)
        name = location.get("name")
        if isinstance(name, str) and name:
            return name
    except Exception:
        pass
    return _humanize(location_id)


def _continuity_line(scene_spec: SceneSpec, text_vars: dict[str, Any]) -> str:
    explicit = text_vars.get("continuity_line")
    if isinstance(explicit, str) and explicit.strip():
        return _sentence(explicit)

    metadata = scene_spec.get("metadata", {})
    followup = metadata.get("followup", {}) if isinstance(metadata, dict) else {}
    if not isinstance(followup, dict):
        return ""

    source_choice = followup.get("source_choice")
    source_tier = followup.get("source_tier")
    if not isinstance(source_choice, str) or not isinstance(source_tier, str):
        return ""

    source_scene = followup.get("source_scene")
    source_scene_name = _humanize(source_scene) if isinstance(source_scene, str) and source_scene else "that moment"
    focus = followup.get("focus")
    focus_text = _humanize(focus) if isinstance(focus, str) and focus else ""

    choice_phrase = {
        "attack": "pressed the attack",
        "defend": "held the line",
        "talk": "opened negotiations",
        "investigate": "pursued the clue",
        "explore": "pushed into the unknown",
        "use_item": "spent resources to tip the odds",
        "retreat": "fell back to safer ground",
        "wait": "paused and watched for an opening",
    }.get(source_choice, "made your call")

    tier_prefix = {
        "favorable": [
            "Your last move pays forward.",
            "You carry hard-earned momentum into this moment.",
            "The edge from your previous decision is still with you.",
        ],
        "neutral": [
            "Nothing resolved cleanly a moment ago.",
            "You bought time, not certainty.",
            "The last exchange ended with loose ends.",
        ],
        "negative": [
            "The setback from moments ago catches up immediately.",
            "You are still paying the cost of your previous move.",
            "Fallout arrives before you can reset.",
        ],
    }.get(source_tier, ["What just happened still shapes this moment."])

    lead = _stable_pick(tier_prefix, f"{scene_spec['scene_id']}:{source_choice}:{source_tier}:lead")
    detail = f"You {choice_phrase} at {source_scene_name}"
    if focus_text:
        detail += f", and now everything narrows around the {focus_text.lower()}"
    else:
        detail += ", and the consequences land right here"
    return _sentence(f"{lead} {detail}")


def _sensory_line(scene_spec: SceneSpec, location_name: str) -> str:
    tags = [tag for tag in scene_spec.get("tags", []) if isinstance(tag, str)]
    beat_type = scene_spec["beat_type"]
    key = tags[0] if tags else beat_type

    sensory_map: dict[str, list[str]] = {
        "combat": [
            f"In {location_name}, every sound is either a warning or a weapon.",
            f"The air at {location_name} is sharp with movement and bad timing.",
        ],
        "mystery": [
            f"At {location_name}, details feel deliberate, as if someone arranged them for you to find.",
            f"The quiet at {location_name} is too clean; something is being hidden.",
        ],
        "social": [
            f"Faces in {location_name} are watching for weakness as much as words.",
            f"Every pause in {location_name} feels like part of a negotiation.",
        ],
        "recovery": [
            f"For a moment, {location_name} offers enough calm to think clearly.",
            f"The rhythm of {location_name} slows just enough for breath to matter.",
        ],
        "travel": [
            f"The route through {location_name} feels unstable, like it could change again without warning.",
            f"Each step in {location_name} redraws what is safe and what is not.",
        ],
        "exploration": [
            f"The edges of {location_name} keep suggesting there is more just beyond sight.",
            f"{location_name} opens one path while quietly closing another.",
        ],
        "revelation": [
            f"At {location_name}, new truth arrives with consequences already attached.",
            f"The facts surfacing in {location_name} are useful, but never neutral.",
        ],
    }
    options = sensory_map.get(key) or sensory_map.get(beat_type, [])
    return _sentence(_stable_pick(options, f"{scene_spec['scene_id']}:{key}:sensory"))


def _goal_line(text_vars: dict[str, Any]) -> str:
    explicit = text_vars.get("goal_line")
    if isinstance(explicit, str) and explicit.strip():
        return _sentence(explicit)
    return ""


def _chapter_line(text_vars: dict[str, Any]) -> str:
    explicit = text_vars.get("chapter_line")
    if isinstance(explicit, str) and explicit.strip():
        return _sentence(explicit)
    return ""


def _pressure_line(scene_spec: SceneSpec) -> str:
    difficulty = float(scene_spec.get("difficulty", 0.5))
    beat_type = scene_spec["beat_type"]

    if difficulty >= 0.75:
        pressure = "The pressure is immediate and unforgiving"
    elif difficulty >= 0.55:
        pressure = "The risk is high and getting sharper"
    elif difficulty >= 0.35:
        pressure = "The situation is manageable, but mistakes will snowball"
    else:
        pressure = "You have a narrow window to act before this hardens"

    beat_tail = {
        "combat": "if you hesitate, the enemy sets the pace.",
        "social": "if you overplay your hand, trust collapses fast.",
        "mystery": "if you guess too early, the wrong pattern locks in.",
        "exploration": "if you rush, the environment answers first.",
        "travel": "if you choose poorly, the route itself becomes the threat.",
        "recovery": "if you waste this pause, you lose the chance to reset.",
        "revelation": "if you act on half-truths, the fallout compounds.",
    }.get(beat_type, "if you drift, someone else takes control.")

    return _sentence(f"{pressure}; {beat_tail}")


def _stakes_line(scene_spec: SceneSpec, content_db: Any) -> str:
    thread_ids = [thread_id for thread_id in scene_spec.get("thread_ids", []) if isinstance(thread_id, str)]
    if not thread_ids:
        return ""

    title_map: dict[str, str] = {}
    try:
        for thread in content_db.list_threads():
            if not isinstance(thread, dict):
                continue
            thread_id = thread.get("id")
            title = thread.get("title")
            if isinstance(thread_id, str) and isinstance(title, str):
                title_map[thread_id] = title
    except Exception:
        title_map = {}

    thread_titles = [title_map.get(thread_id, _humanize(thread_id)) for thread_id in thread_ids]
    if len(thread_titles) == 1:
        options = [
            f"If you lose control here, {thread_titles[0]} gains ground by nightfall.",
            f"A strong move here can force {thread_titles[0]} onto your terms.",
            f"Tonight may decide whether {thread_titles[0]} escalates or stalls.",
        ]
        return _sentence(_stable_pick(options, f"{scene_spec['scene_id']}:{thread_titles[0]}:stakes"))

    options = [
        f"This moment ties directly into both {thread_titles[0]} and {thread_titles[1]}.",
        f"Your decision here can shift the balance between {thread_titles[0]} and {thread_titles[1]}.",
        f"The fallout from what happens now will carry into {thread_titles[0]} and {thread_titles[1]}.",
    ]
    return _sentence(_stable_pick(options, f"{scene_spec['scene_id']}:{thread_titles[0]}:{thread_titles[1]}:stakes"))


def _dm_voice_scene_text(
    *,
    scene_spec: SceneSpec,
    text_vars: dict[str, Any],
    base_text: str,
    location_name: str,
    goal: str,
    pressure: str,
) -> str:
    metadata = scene_spec.get("metadata", {})
    followup = metadata.get("followup", {}) if isinstance(metadata, dict) else {}
    if not isinstance(followup, dict):
        followup = {}

    previous_location = (
        text_vars.get("previous_location")
        or followup.get("previous_location")
        or scene_spec.get("location_id", "")
    )
    if isinstance(previous_location, str) and previous_location:
        previous_location = _humanize(previous_location)
    else:
        previous_location = ""

    previous_context: dict[str, Any] = {
        "active_entity": (
            text_vars.get("source_entity")
            or followup.get("source_entity")
            or text_vars.get("active_entity")
            or followup.get("active_entity")
            or followup.get("focus")
            or "the situation"
        ),
        "previous_location": previous_location,
        "action_label": (
            text_vars.get("last_player_action_label")
            or followup.get("player_action_label")
            or str(followup.get("source_choice", "act"))
        ),
        "dda_event_triggered": (
            text_vars.get("dda_event_triggered")
            or followup.get("dda_event_triggered")
            or followup.get("story_consequence")
            or ""
        ),
        "consequence": followup.get("narrative", ""),
    }

    player_action = str(
        text_vars.get("last_player_action")
        or followup.get("player_action")
        or followup.get("source_choice")
        or "wait"
    )
    dda_roll: dict[str, Any] = {
        "resolution_tier": (
            text_vars.get("action_success_level")
            or followup.get("resolution_tier")
            or followup.get("source_tier")
            or "neutral"
        ),
        "roll_value": followup.get("roll_value"),
    }
    new_scene: dict[str, Any] = {
        "current_location": location_name,
        "hook": base_text,
        "goal_line": goal,
        "threat_or_opportunity": pressure,
    }
    return format_dm_response(previous_context, player_action, dda_roll, new_scene)


def render_scene(scene_spec: SceneSpec, templates: dict[str, Any], content_db: Any) -> str:
    """Render scene text by formatting the selected template with text vars.

    The renderer is read-only and must not mutate game state or content assets.
    """
    validate_scene_spec(scene_spec)

    template = _select_template(scene_spec, templates)

    text_vars: dict[str, Any] = {}
    source_text_vars = scene_spec.get("text_vars", {})
    if isinstance(source_text_vars, dict):
        text_vars.update(source_text_vars)

    location_name = _location_name(scene_spec, text_vars, content_db)
    text_vars["location_name"] = location_name

    text_vars.setdefault("title", scene_spec.get("title", "Untitled Scene"))
    text_vars.setdefault("tension", f"{scene_spec.get('difficulty', 0.5):.2f}")

    base_text = template.format_map(_SafeFormatDict(text_vars)).strip()

    continuity = _continuity_line(scene_spec, text_vars)
    sensory = _sensory_line(scene_spec, location_name)
    chapter = _chapter_line(text_vars)
    goal = _goal_line(text_vars)
    pressure = _pressure_line(scene_spec)
    stakes = _stakes_line(scene_spec, content_db)
    metadata = scene_spec.get("metadata", {})
    generated_followup = bool(metadata.get("generated_followup", False)) if isinstance(metadata, dict) else False
    followup_context = metadata.get("followup", {}) if isinstance(metadata, dict) else {}
    has_followup_context = isinstance(followup_context, dict) and bool(followup_context)

    if generated_followup or has_followup_context:
        dm_text = _dm_voice_scene_text(
            scene_spec=scene_spec,
            text_vars=text_vars,
            base_text=base_text,
            location_name=location_name,
            goal=goal,
            pressure=pressure,
        )
        if dm_text:
            return dm_text

    narrative_blocks: list[str] = []
    ordered_blocks: list[tuple[str, bool]]
    if generated_followup:
        scene_key = str(scene_spec.get("scene_id", ""))
        layout_index = sum(ord(ch) for ch in scene_key) % 3
        followup_layouts: list[list[tuple[str, bool]]] = [
            [
                (continuity, False),
                (base_text, True),
                (sensory, False),
                (goal, False),
                (chapter, False),
            ],
            [
                (base_text, True),
                (continuity, False),
                (goal, False),
                (sensory, False),
                (chapter, False),
            ],
            [
                (sensory, False),
                (continuity, False),
                (base_text, True),
                (goal, False),
                (chapter, False),
            ],
        ]
        ordered_blocks = followup_layouts[layout_index]
    else:
        ordered_blocks = [
            (continuity, False),
            (chapter, False),
            (base_text, True),
            (sensory, False),
        ]
        if goal:
            ordered_blocks.append((goal, False))
        if not continuity:
            ordered_blocks.append((pressure, False))
        if not goal:
            ordered_blocks.append((stakes, False))
    for block, is_base in ordered_blocks:
        clean_block = block if is_base else _sentence(block)
        if not clean_block:
            continue
        if any(clean_block == existing for existing in narrative_blocks):
            continue
        if clean_block in base_text and not is_base:
            continue
        narrative_blocks.append(clean_block)

    if not narrative_blocks:
        return _sentence(base_text)

    paragraph_parts: list[str] = []
    for block in narrative_blocks:
        normalized = " ".join(block.split()).strip()
        if not normalized:
            continue
        paragraph_parts.append(normalized)

    return " ".join(paragraph_parts).strip()


def list_choices(scene_spec: SceneSpec) -> list[ActionType]:
    """Return ordered canonical action choices from a validated SceneSpec."""
    validate_scene_spec(scene_spec)
    return list(scene_spec["choices"])
