"""Choice resolver producing outcome deltas and player-model observations."""

from __future__ import annotations

import random
from typing import Any

from contracts import (
    ActionType,
    Observation,
    Outcome,
    ResolutionTier,
    SceneSpec,
    validate_observation,
    validate_outcome,
    validate_scene_spec,
)

_FOLLOWUP_ALLOWED_TAGS: set[str] = {
    "exploration",
    "combat",
    "social",
    "mystery",
    "recovery",
    "revelation",
    "travel",
    "vault",
    "gate",
    "waystone",
    "route",
    "path",
    "trail",
    "convoy",
    "caravan",
    "shrine",
    "archive",
    "market",
    "catacombs",
    "tunnel",
    "oracle",
    "siege",
    "raid",
    "spy",
    "courier",
    "rebel",
    "beacon",
    "ledger",
}
_LOCATION_FOCUS_SEEDS: dict[str, tuple[str, ...]] = {
    "crossroads": ("waystone", "route", "beacon", "market", "courier"),
    "glass_marsh": ("tunnel", "trail", "oracle", "catacombs"),
    "moonmarket": ("market", "spy", "ledger", "courier"),
    "emberkeep": ("gate", "siege", "rebel", "vault"),
    "forgotten_archive": ("archive", "oracle", "vault", "beacon"),
}
_CHOICE_FOCUS_SEEDS: dict[ActionType, tuple[str, ...]] = {
    "attack": ("siege", "gate", "rebel"),
    "defend": ("gate", "shrine", "beacon"),
    "talk": ("courier", "spy", "market"),
    "investigate": ("archive", "ledger", "oracle", "tunnel"),
    "explore": ("trail", "path", "catacombs", "tunnel"),
    "use_item": ("beacon", "oracle", "vault"),
    "retreat": ("path", "shrine", "trail"),
    "wait": ("shrine", "beacon", "archive"),
}


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _sentence(text: str) -> str:
    clean = " ".join(text.split()).strip()
    if not clean:
        return ""
    if clean[-1] not in {".", "!", "?"}:
        clean += "."
    return clean


def _join_sentences(*parts: str) -> str:
    merged: list[str] = []
    for part in parts:
        sentence = _sentence(part)
        if sentence:
            merged.append(sentence)
    return " ".join(merged).strip()


def _definite(text: str) -> str:
    clean = " ".join(text.split()).strip()
    if not clean:
        return "the situation"
    if clean.lower().startswith(("the ", "a ", "an ")):
        return clean
    return f"the {clean}"


def _low_health_damage_scale(health: int) -> float:
    if health >= 70:
        return 1.0
    if health >= 55:
        return 0.82
    if health >= 40:
        return 0.68
    return 0.58


def _low_health_tension_scale(health: int) -> float:
    if health >= 70:
        return 1.0
    if health >= 55:
        return 0.9
    if health >= 40:
        return 0.8
    return 0.72


def _merge_outcomes(target: Outcome, patch: dict[str, Any]) -> None:
    player_patch = patch.get("player")
    if isinstance(player_patch, dict):
        target_player = target.setdefault("player", {})
        for key, value in player_patch.items():
            if isinstance(value, (int, float)) and isinstance(target_player.get(key), (int, float)):
                target_player[key] = float(target_player[key]) + float(value)
            else:
                target_player[key] = value

    for key in ("inventory_add", "inventory_remove"):
        values = patch.get(key)
        if isinstance(values, list):
            merged = target.setdefault(key, [])
            for item in values:
                if isinstance(item, str) and item not in merged:
                    merged.append(item)

    flags = patch.get("flags")
    if isinstance(flags, dict):
        target_flags = target.setdefault("flags", {})
        target_flags.update({k: bool(v) for k, v in flags.items() if isinstance(k, str)})

    relationships = patch.get("relationships")
    if isinstance(relationships, dict):
        target_rel = target.setdefault("relationships", {})
        for key, value in relationships.items():
            if not isinstance(key, str):
                continue
            if not isinstance(value, (int, float)):
                continue
            target_rel[key] = float(target_rel.get(key, 0.0)) + float(value)

    for key in ("tension_delta", "difficulty_signal"):
        value = patch.get(key)
        if isinstance(value, (int, float)):
            target[key] = float(target.get(key, 0.0)) + float(value)

    for key in ("plot_threads", "events"):
        values = patch.get(key)
        if isinstance(values, list):
            merged = target.setdefault(key, [])
            merged.extend([entry for entry in values if isinstance(entry, dict)])

    world_facts = patch.get("world_facts")
    if isinstance(world_facts, dict):
        merged = target.setdefault("world_facts", {})
        merged.update(world_facts)

    if "success" in patch and isinstance(patch["success"], bool):
        target["success"] = patch["success"]

    if "resolution_tier" in patch and isinstance(patch["resolution_tier"], str):
        target["resolution_tier"] = patch["resolution_tier"]

    metadata = patch.get("metadata")
    if isinstance(metadata, dict):
        merged = target.setdefault("metadata", {})
        merged.update(metadata)


def _default_risk(choice: ActionType) -> float:
    return {
        "attack": 0.85,
        "defend": 0.2,
        "talk": 0.3,
        "investigate": 0.45,
        "explore": 0.55,
        "use_item": 0.25,
        "retreat": 0.35,
        "wait": 0.1,
    }[choice]


def _resolve_three_way_tier(roll_value: int) -> ResolutionTier:
    if roll_value == 1:
        return "negative"
    if roll_value == 2:
        return "neutral"
    return "favorable"


def _weighted_three_way_roll() -> int:
    """Return weighted three-way roll bucket.

    Distribution:
    - 1 (negative): 1/5
    - 2 (neutral):  1/5
    - 3 (favorable): 3/5
    """
    raw = random.randint(1, 5)
    if raw == 1:
        return 1
    if raw == 2:
        return 2
    return 3


def _default_health_delta(tier: ResolutionTier, choice: ActionType, difficulty: float, risk: float) -> int:
    if tier == "favorable":
        return {
            "attack": -1,
            "defend": +4,
            "talk": 0,
            "investigate": -1,
            "explore": -1,
            "use_item": +4,
            "retreat": +1,
            "wait": +3,
        }[choice]

    if tier == "neutral":
        return {
            "attack": -3,
            "defend": +1,
            "talk": 0,
            "investigate": -1,
            "explore": -2,
            "use_item": +2,
            "retreat": 0,
            "wait": +1,
        }[choice]

    # Negative tier.
    baseline = max(3, int(round((difficulty * (0.25 + risk)) * 20)))
    if choice == "attack":
        baseline += 2
    if choice == "defend":
        baseline -= 1
    if choice in {"retreat", "wait", "use_item"}:
        baseline -= 2
    return -max(2, baseline)


def _default_tension_delta(tier: ResolutionTier, beat_type: str) -> float:
    favorable = {
        "combat": 0.05,
        "mystery": 0.04,
        "revelation": 0.05,
        "exploration": 0.02,
        "travel": 0.01,
        "social": 0.00,
        "recovery": -0.12,
    }
    neutral = {
        "combat": 0.08,
        "mystery": 0.06,
        "revelation": 0.07,
        "exploration": 0.04,
        "travel": 0.03,
        "social": 0.02,
        "recovery": -0.05,
    }
    negative = {
        "combat": 0.12,
        "mystery": 0.10,
        "revelation": 0.10,
        "exploration": 0.07,
        "travel": 0.06,
        "social": 0.07,
        "recovery": -0.01,
    }

    table = {"favorable": favorable, "neutral": neutral, "negative": negative}[tier]
    return table.get(beat_type, 0.05)


def _default_thread_progress_delta(tier: ResolutionTier) -> float:
    return {
        "favorable": 0.22,
        "neutral": 0.10,
        "negative": 0.03,
    }[tier]


def _tier_effect_patch(effect_for_choice: dict[str, Any], tier: ResolutionTier) -> dict[str, Any]:
    if tier == "favorable":
        patch = effect_for_choice.get("on_favorable")
        if isinstance(patch, dict):
            return patch
        patch = effect_for_choice.get("on_success")
        if isinstance(patch, dict):
            return patch
        return {}

    if tier == "neutral":
        patch = effect_for_choice.get("on_neutral")
        if isinstance(patch, dict):
            return patch
        patch = effect_for_choice.get("on_partial")
        if isinstance(patch, dict):
            return patch
        return {}

    patch = effect_for_choice.get("on_negative")
    if isinstance(patch, dict):
        return patch
    patch = effect_for_choice.get("on_failure")
    if isinstance(patch, dict):
        return patch
    return {}


def _followup_required_tags(
    *,
    choice: ActionType,
    tier: ResolutionTier,
    choice_tags: list[str],
) -> list[str]:
    default_tags: dict[ActionType, list[str]] = {
        "attack": ["combat", "revelation"],
        "defend": ["combat", "recovery"],
        "talk": ["social", "revelation"],
        "investigate": ["mystery", "exploration"],
        "explore": ["exploration", "travel"],
        "use_item": ["recovery", "social"],
        "retreat": ["recovery", "travel"],
        "wait": ["recovery", "mystery"],
    }

    ordered: list[str] = []
    for tag in choice_tags:
        if not isinstance(tag, str):
            continue
        if tag not in _FOLLOWUP_ALLOWED_TAGS:
            continue
        if tag not in ordered:
            ordered.append(tag)
    for tag in default_tags[choice]:
        if tag not in ordered:
            ordered.append(tag)

    if tier == "negative" and "recovery" not in ordered:
        ordered.append("recovery")
    if tier == "favorable" and "revelation" not in ordered:
        ordered.append("revelation")

    return ordered[:3]


def _humanize_token(token: str) -> str:
    return token.replace("_", " ").strip()


def _danger_detail(
    *,
    beat_type: str,
    focus: str,
    location_id: str,
    scene_id: str,
    choice: ActionType,
) -> str:
    focus_label = _humanize_token(focus) if focus else "the line ahead"
    location_label = _humanize_token(location_id) if location_id else "the district"
    focus_slug = focus.strip().lower()
    spatial_focuses = {
        "waystone",
        "route",
        "path",
        "trail",
        "gate",
        "vault",
        "shrine",
        "archive",
        "market",
        "catacombs",
        "tunnel",
        "siege",
        "raid",
    }
    if focus_slug in spatial_focuses:
        focus_area = f"the {focus_label}"
    else:
        focus_area = f"the {focus_label} line"

    seed = f"{scene_id}:{choice}:{beat_type}:{focus_area}:{location_label}"

    by_beat: dict[str, list[str]] = {
        "travel": [
            f"false markers around {focus_area} drag your group off the safe trail",
            f"a washed-out crossing near {focus_area} collapses under your lead step",
            f"fog closes in around {focus_area}, and the caravan drifts toward bad ground",
        ],
        "exploration": [
            f"unstable ground near {focus_area} gives way and throws everyone off balance",
            f"a hidden drop beside {focus_area} opens under your route",
            f"sharp debris around {focus_area} turns the advance into a blood-costly scramble",
        ],
        "mystery": [
            f"a planted clue tied to {focus_area} sends you straight into an ambush",
            f"the pattern around {focus_area} is a deliberate decoy, and you spring it",
            f"a watcher in {location_label} sees your line of inquiry and moves first",
        ],
        "social": [
            f"a witness around {focus_area} names you at the worst possible moment",
            f"the room around {focus_area} flips, and knives come out before terms can settle",
            f"someone at {focus_area} twists your words and turns the crowd hostile",
        ],
        "combat": [
            f"the enemy feints toward {focus_area} and cracks your formation open",
            f"a flank from {focus_area} hits before you can reset",
            f"crossfire around {focus_area} pins your front line in place",
        ],
        "revelation": [
            f"the truth about {focus_area} surfaces publicly and sparks immediate backlash",
            f"the reveal around {focus_area} exposes your position to hostile eyes",
            f"the new evidence tied to {focus_area} detonates old alliances",
        ],
        "recovery": [
            f"the lull around {focus_area} snaps, and pressure returns before you can recover",
            f"you lose your safe window near {focus_area}, and the strain hits all at once",
            f"the respite in {location_label} breaks early and leaves the group exposed",
        ],
    }
    fallback = [
        f"pressure around {focus_area} breaks the plan before it can settle",
        f"the ground truth in {location_label} turns against you mid-move",
        f"what looked stable around {focus_area} collapses without warning",
    ]
    options = by_beat.get(beat_type, fallback)
    return _stable_pick(options, seed)


def _normalize_action_phrase(choice_label: str, choice: ActionType) -> str:
    label = choice_label.strip().rstrip(".")
    if not label:
        label = choice.replace("_", " ")
    action_phrase = label.lower()
    for prefix in ("try to ", "attempt to ", "choose to "):
        if action_phrase.startswith(prefix):
            return action_phrase[len(prefix):]
    return action_phrase


def _choice_consequence_line(
    *,
    choice: ActionType,
    tier: ResolutionTier,
    focus_anchor: str,
    danger: str,
    seed_base: str,
) -> str:
    if tier == "favorable":
        options: dict[ActionType, list[str]] = {
            "attack": [
                f"Your strike breaks the enemy push around {focus_anchor}, and your side takes room to breathe",
                f"The pressure line at {focus_anchor} folds under your attack, forcing your opponents to give ground",
            ],
            "defend": [
                f"Your defense locks down {focus_anchor}, buying space for the injured and the scouts",
                f"You hold firm at {focus_anchor}, and what looked like collapse becomes a controlled stand",
            ],
            "talk": [
                f"Your words reset the room around {focus_anchor}, and rival voices align long enough to cooperate",
                f"Negotiation at {focus_anchor} lands cleanly, turning argument into a workable plan",
            ],
            "investigate": [
                f"Your read of {focus_anchor} clicks into place, exposing the pattern others kept missing",
                f"The clues around {focus_anchor} finally align under your analysis, giving you actionable truth",
            ],
            "explore": [
                f"You find a usable path past {focus_anchor}, replacing guesswork with direction",
                f"The advance through {focus_anchor} reveals a viable route, and momentum returns to your group",
            ],
            "use_item": [
                f"The resources you commit stabilize {focus_anchor}, turning a fragile moment into a clear advantage",
                f"Your equipment works exactly when needed at {focus_anchor}, and the field shifts in your favor",
            ],
            "retreat": [
                f"Your fallback through {focus_anchor} stays disciplined, preserving people and supplies",
                f"The retreat at {focus_anchor} is controlled, and you trade distance for a stronger position",
            ],
            "wait": [
                f"Your patience at {focus_anchor} reveals the real timing of the threat, letting you move first",
                f"By holding at {focus_anchor}, you catch the pattern others miss and gain initiative",
            ],
        }
    elif tier == "neutral":
        options = {
            "attack": [
                f"You trade hard blows near {focus_anchor}; neither side breaks, but both sides bleed",
                f"Your attack around {focus_anchor} creates pressure without delivering a clean breakthrough",
            ],
            "defend": [
                f"You blunt the surge at {focus_anchor}, but the line is still under strain",
                f"Your defense at {focus_anchor} holds for now, though the position remains contested",
            ],
            "talk": [
                f"You keep negotiations alive around {focus_anchor}, but trust stays fragile",
                f"Talks at {focus_anchor} buy time, not certainty, and every faction keeps a hidden angle",
            ],
            "investigate": [
                f"You uncover part of the truth around {focus_anchor}, but key details still conflict",
                f"Your investigation at {focus_anchor} narrows the field, yet critical gaps remain",
            ],
            "explore": [
                f"You make progress around {focus_anchor}, but hazards keep the route unstable",
                f"The push through {focus_anchor} gains distance, though your footing is still uncertain",
            ],
            "use_item": [
                f"Your tools steady {focus_anchor} briefly, but the fix will not hold forever",
                f"The resources help around {focus_anchor}, though only enough to delay the next problem",
            ],
            "retreat": [
                f"Your withdrawal to {focus_anchor} regroups most of the team, but leaves unfinished exposure",
                f"You pull back through {focus_anchor} and avoid disaster, yet the situation stays tense",
            ],
            "wait": [
                f"You hold at {focus_anchor} long enough to read the situation, but pressure keeps building",
                f"Waiting near {focus_anchor} prevents a mistake, though it does not solve the underlying threat",
            ],
        }
    else:
        options = {
            "attack": [
                f"You overcommit around {focus_anchor}, and {danger}",
                f"The attack at {focus_anchor} opens you to a bad counter, and {danger}",
            ],
            "defend": [
                f"Your defensive line around {focus_anchor} buckles at the wrong moment, and {danger}",
                f"The hold at {focus_anchor} fractures under pressure, and {danger}",
            ],
            "talk": [
                f"The conversation around {focus_anchor} turns hostile before you can steer it, and {danger}",
                f"Your negotiation at {focus_anchor} collapses into panic, and {danger}",
            ],
            "investigate": [
                f"Your read on {focus_anchor} is manipulated, and {danger}",
                f"While you pursue answers around {focus_anchor}, {danger}",
            ],
            "explore": [
                f"The route you push at {focus_anchor} turns against you, and {danger}",
                f"You press forward through {focus_anchor}, but {danger}",
            ],
            "use_item": [
                f"Your tools misalign around {focus_anchor}, and {danger}",
                f"The resource play at {focus_anchor} backfires under stress, and {danger}",
            ],
            "retreat": [
                f"Your retreat through {focus_anchor} loses cohesion, and {danger}",
                f"The fallback at {focus_anchor} turns messy, and {danger}",
            ],
            "wait": [
                f"You wait too long around {focus_anchor}, and {danger}",
                f"Hesitation at {focus_anchor} gives the threat an opening, and {danger}",
            ],
        }

    selected = _stable_pick(options[choice], f"{seed_base}:consequence:{choice}:{tier}")
    return _sentence(selected)


def _choice_aftermath_line(
    *,
    choice: ActionType,
    tier: ResolutionTier,
    focus_anchor: str,
    location_label: str,
    seed_base: str,
) -> str:
    if tier == "favorable":
        options: dict[ActionType, list[str]] = {
            "attack": [
                f"With enemies reeling near {focus_anchor}, you can press the advantage or secure the wounded before they regroup",
                f"Control of the line near {focus_anchor} is now yours, and your next call decides whether this becomes a decisive win",
            ],
            "defend": [
                f"You now own the tempo around {focus_anchor}, and can counterattack on your terms",
                f"The hold at {focus_anchor} gives you breathing room in {location_label}, but only if you act before pressure returns",
            ],
            "talk": [
                f"You have a brief coalition around {focus_anchor}, and your next decision determines whether it becomes durable trust",
                f"The agreement at {focus_anchor} is real but fragile, so the next scene is about converting words into action",
            ],
            "investigate": [
                f"You now know where to look around {focus_anchor}, and the next move decides whether that knowledge becomes leverage",
                f"The thread at {focus_anchor} is exposed, and your next scene is about exploiting it before rivals react",
            ],
            "explore": [
                f"That breakthrough around {focus_anchor} opens a real corridor, and your next decision sets who reaches it first",
                f"You have momentum beyond {focus_anchor}, and the next scene decides whether you secure it or overextend",
            ],
            "use_item": [
                f"The stabilized position at {focus_anchor} gives you initiative, and your next move decides where to spend it",
                f"You bought a strong window around {focus_anchor}, but it only matters if you capitalize immediately",
            ],
            "retreat": [
                f"Your regroup near {focus_anchor} keeps the campaign alive, and the next scene is about reclaiming initiative",
                f"You preserved strength at {focus_anchor}, and now you choose whether to re-engage, reposition, or negotiate",
            ],
            "wait": [
                f"You now see the real pattern around {focus_anchor}, and the next step is to act before it shifts again",
                f"That patience gives you a tactical edge at {focus_anchor}, and your next decision determines how much value you extract",
            ],
        }
    elif tier == "neutral":
        options = {
            "attack": [
                f"The clash around {focus_anchor} is unresolved, so your next scene is about turning pressure into a clear outcome",
                f"You created a crack at {focus_anchor}, but now you must choose whether to widen it or disengage safely",
            ],
            "defend": [
                f"The line at {focus_anchor} still holds, but one wrong call will convert strain into collapse",
                f"You bought time in {location_label}, and the next decision decides whether that time is wasted or weaponized",
            ],
            "talk": [
                f"You are standing in a temporary truce around {focus_anchor}, and the next scene will test whether anyone honors it",
                f"The room around {focus_anchor} is quiet for now, but your next move determines whether it stays that way",
            ],
            "investigate": [
                f"You have enough signal around {focus_anchor} to act, but not enough certainty to be reckless",
                f"The clue chain in {location_label} is half-open, and the next decision determines whether it clarifies or collapses",
            ],
            "explore": [
                f"You reached contested ground near {focus_anchor}, and the next scene is about stabilizing your footing",
                f"The route is still unstable around {focus_anchor}, so your next call must balance speed against safety",
            ],
            "use_item": [
                f"Your temporary fix at {focus_anchor} bought a window, and the next move decides whether that window closes cleanly",
                f"You delayed the worst around {focus_anchor}, but now you need a durable plan before pressure spikes again",
            ],
            "retreat": [
                f"You preserved part of the force at {focus_anchor}, and the next scene decides whether regrouping becomes recovery",
                f"The fallback in {location_label} keeps options open, but only if you define the next objective fast",
            ],
            "wait": [
                f"Time has not solved {focus_anchor}; it has only clarified where the next risk sits",
                f"You avoided a rash move at {focus_anchor}, and now the next decision must convert caution into progress",
            ],
        }
    else:
        options = {
            "attack": [
                f"You are now reacting from a weaker posture in {location_label}, and the next scene starts with damage control",
                f"The failed push around {focus_anchor} hands initiative away, and your next decision must prevent a cascade",
            ],
            "defend": [
                f"With the line compromised at {focus_anchor}, the next scene is about saving cohesion before losses compound",
                f"You no longer control the exchange around {focus_anchor}, so immediate stabilization becomes the priority",
            ],
            "talk": [
                f"Trust has fractured around {focus_anchor}, and your next move determines whether this becomes open conflict",
                f"The social fallout in {location_label} now shapes every option, so recovery and credibility are urgent",
            ],
            "investigate": [
                f"The bad read at {focus_anchor} puts you behind, and the next scene must separate real signals from planted noise",
                f"You lose narrative control around {focus_anchor}, and your next decision decides whether you recover truth or chase more decoys",
            ],
            "explore": [
                f"Your route is compromised around {focus_anchor}, and the next scene begins with survival before progress",
                f"Momentum breaks in {location_label}, so the next move must rebuild direction under pressure",
            ],
            "use_item": [
                f"With your resources misfiring around {focus_anchor}, the next scene is about salvaging trust in your plan",
                f"The failed resource play at {focus_anchor} leaves the group exposed, and your next call must restore control",
            ],
            "retreat": [
                f"The disordered fallback around {focus_anchor} forces a hard regroup, and the next scene opens with triage",
                f"You are pulled into defensive recovery in {location_label}, and the next move must prevent further fragmentation",
            ],
            "wait": [
                f"Hesitation around {focus_anchor} costs initiative, and the next scene begins with your opponents setting pace",
                f"You now need a decisive response in {location_label}, because waiting has already increased the price of action",
            ],
        }

    selected = _stable_pick(options[choice], f"{seed_base}:aftermath:{choice}:{tier}")
    return _sentence(selected)


def _branch_goal_line(
    *,
    choice: ActionType,
    tier: ResolutionTier,
    focus_anchor: str,
    location_label: str,
    seed_base: str,
) -> str:
    goals: dict[ResolutionTier, dict[ActionType, list[str]]] = {
        "favorable": {
            "attack": [
                f"Exploit your advantage around {focus_anchor} before enemy reserves reset the line",
                f"Convert battlefield momentum at {focus_anchor} into lasting control of the area",
            ],
            "defend": [
                f"Turn your stable position at {focus_anchor} into an organized countermove",
                f"Use this defensive success to secure allies and choose the next engagement on your terms",
            ],
            "talk": [
                f"Lock the new agreement around {focus_anchor} into concrete commitments before rivals undermine it",
                f"Use your social momentum in {location_label} to build a coalition that can survive first contact",
            ],
            "investigate": [
                f"Act on the exposed pattern around {focus_anchor} before evidence is moved or destroyed",
                f"Use what you learned near {focus_anchor} to target the real decision-makers next",
            ],
            "explore": [
                f"Secure the route beyond {focus_anchor} before weather, enemies, or doubt close it again",
                f"Push the new corridor in {location_label} toward a strategic objective while the window is open",
            ],
            "use_item": [
                f"Capitalize on your stabilized position around {focus_anchor} before resources run thin",
                f"Translate your resource advantage in {location_label} into a durable strategic foothold",
            ],
            "retreat": [
                f"Re-enter the conflict from strength after consolidating around {focus_anchor}",
                f"Use your orderly regroup in {location_label} to choose a better battlefield",
            ],
            "wait": [
                f"Strike on the pattern you just confirmed around {focus_anchor} before it changes again",
                f"Convert your informational edge in {location_label} into decisive action",
            ],
        },
        "neutral": {
            "attack": [
                f"Decide whether to commit harder around {focus_anchor} or reset before attrition decides the fight",
                f"Turn a contested exchange in {location_label} into a clear tactical objective",
            ],
            "defend": [
                f"Stabilize the line around {focus_anchor} and prevent this from sliding into a rout",
                f"Choose where to absorb pressure in {location_label} so you can regain initiative next",
            ],
            "talk": [
                f"Reinforce fragile trust around {focus_anchor} before the truce collapses",
                f"Use this pause in {location_label} to align your group on one enforceable plan",
            ],
            "investigate": [
                f"Resolve conflicting evidence around {focus_anchor} before acting on incomplete assumptions",
                f"Run one decisive test in {location_label} to separate truth from planted misdirection",
            ],
            "explore": [
                f"Stabilize your route around {focus_anchor} so movement stops bleeding resources",
                f"Choose between safer progress and faster risk through {location_label}",
            ],
            "use_item": [
                f"Turn temporary relief near {focus_anchor} into a durable fix before conditions worsen",
                f"Preserve scarce resources in {location_label} while creating a stronger fallback plan",
            ],
            "retreat": [
                f"Convert this partial regroup around {focus_anchor} into full operational control",
                f"Secure a defensible position in {location_label} before deciding how to re-engage",
            ],
            "wait": [
                f"Use the information gained around {focus_anchor} to choose a concrete next move",
                f"Break the stall in {location_label} before delay turns caution into vulnerability",
            ],
        },
        "negative": {
            "attack": [
                f"Stop the bleeding around {focus_anchor} and re-establish a coherent line before the next hit",
                f"Recover initiative in {location_label} without sacrificing the rest of your force",
            ],
            "defend": [
                f"Rebuild the broken defense around {focus_anchor} before pressure cascades into collapse",
                f"Stabilize survivors in {location_label} and choose a fallback that holds",
            ],
            "talk": [
                f"Repair fractured trust around {focus_anchor} before any joint action is possible",
                f"Contain social fallout in {location_label} and prevent open infighting",
            ],
            "investigate": [
                f"Disentangle false signals around {focus_anchor} before another trap is sprung",
                f"Regain narrative control in {location_label} by validating one reliable source first",
            ],
            "explore": [
                f"Rescue scattered allies around {focus_anchor} and recover a survivable route",
                f"Rebuild direction in {location_label} before terrain and fear fully take over",
            ],
            "use_item": [
                f"Recover from the failed resource play around {focus_anchor} and restore confidence in leadership",
                f"Stabilize exposed positions in {location_label} while preserving remaining supplies",
            ],
            "retreat": [
                f"Turn a broken withdrawal around {focus_anchor} into an organized regroup",
                f"Secure accountability and command in {location_label} before retreat becomes panic",
            ],
            "wait": [
                f"Seize initiative around {focus_anchor} before inaction causes another avoidable loss",
                f"Break paralysis in {location_label} with a clear immediate objective and chain of command",
            ],
        },
    }
    selected = _stable_pick(goals[tier][choice], f"{seed_base}:goal:{choice}:{tier}")
    return _sentence(selected)


def _outcome_story_bundle(
    *,
    choice: ActionType,
    choice_label: str,
    scene_title: str,
    tier: ResolutionTier,
    beat_type: str,
    focus: str,
    location_id: str,
    scene_id: str,
) -> dict[str, str]:
    action_phrase = _normalize_action_phrase(choice_label, choice)
    focus_label = _humanize_token(focus) if focus else "line ahead"
    focus_anchor = _definite(focus_label)
    location_label = _humanize_token(location_id).title() if location_id else "the region"
    seed_base = f"{scene_id}:{choice}:{tier}:{beat_type}:{focus_anchor}"

    tier_intros: dict[ResolutionTier, list[str]] = {
        "favorable": [
            f"When you {action_phrase} at {scene_title}, the decision lands better than expected",
            f"You commit to {action_phrase} at {scene_title}, and the field bends in your favor",
            f"At {scene_title}, your move to {action_phrase} finally gives your side clean momentum",
        ],
        "neutral": [
            f"You {action_phrase} at {scene_title}, and only part of the plan holds together",
            f"At {scene_title}, your call to {action_phrase} buys progress but not control",
            f"The choice to {action_phrase} at {scene_title} keeps you in the fight, though the outcome stays contested",
        ],
        "negative": [
            f"You {action_phrase} at {scene_title}, and the situation breaks against you almost immediately",
            f"At {scene_title}, your attempt to {action_phrase} triggers a hard setback",
            f"The moment you {action_phrase} at {scene_title}, hidden pressure turns active",
        ],
    }

    danger = _danger_detail(
        beat_type=beat_type,
        focus=focus,
        location_id=location_id,
        scene_id=scene_id,
        choice=choice,
    )
    opening = _sentence(_stable_pick(tier_intros[tier], f"{seed_base}:opening"))
    consequence = _choice_consequence_line(
        choice=choice,
        tier=tier,
        focus_anchor=focus_anchor,
        danger=danger,
        seed_base=seed_base,
    )
    aftermath = _choice_aftermath_line(
        choice=choice,
        tier=tier,
        focus_anchor=focus_anchor,
        location_label=location_label,
        seed_base=seed_base,
    )
    branch_goal = _branch_goal_line(
        choice=choice,
        tier=tier,
        focus_anchor=focus_anchor,
        location_label=location_label,
        seed_base=seed_base,
    )

    branch_hook_options: dict[ResolutionTier, list[str]] = {
        "favorable": [
            f"The immediate fallout in {location_label} is momentum: allies move faster, rivals react faster, and the next scene opens on your initiative",
            f"Your success around {focus_anchor} changes the board in {location_label}; fresh opportunities appear, but so do new challengers",
        ],
        "neutral": [
            f"The field in {location_label} stays unstable around {focus_anchor}, and the next scene begins with competing interpretations of what just happened",
            f"You leave this moment with partial control in {location_label}; the next scene is where uncertainty either resolves or explodes",
        ],
        "negative": [
            f"The setback around {focus_anchor} leaves your group exposed in {location_label}, and the next scene starts before anyone is fully ready",
            f"Damage from this choice is still active in {location_label}; the next scene opens with urgency, not preparation",
        ],
    }

    branch_hook = _sentence(_stable_pick(branch_hook_options[tier], f"{seed_base}:branch_hook"))
    continuity = _stable_pick(
        [
            _join_sentences(consequence, aftermath),
            _join_sentences(opening, consequence),
            _join_sentences(opening, consequence, aftermath),
        ],
        f"{seed_base}:continuity",
    )
    return {
        "opening": opening,
        "consequence": consequence,
        "aftermath": aftermath,
        "branch_hook": branch_hook,
        "branch_goal": branch_goal,
        "continuity": continuity,
    }


def _followup_narrative(
    *,
    choice: ActionType,
    choice_label: str,
    scene_title: str,
    tier: ResolutionTier,
    beat_type: str,
    focus: str,
    location_id: str,
    scene_id: str,
) -> str:
    label = choice_label.strip().rstrip(".")
    if not label:
        label = choice.replace("_", " ")
    label_core = label.lower()
    lower_scene_title = scene_title.lower()
    focus_label = _humanize_token(focus) if focus else "the route"
    for prefix in ("try to ", "attempt to ", "choose to "):
        if label_core.startswith(prefix):
            label_core = label_core[len(prefix):]
            break

    danger = _danger_detail(
        beat_type=beat_type,
        focus=focus,
        location_id=location_id,
        scene_id=scene_id,
        choice=choice,
    )

    if choice == "use_item" and tier == "negative" and "waystone" in lower_scene_title:
        return (
            "Your relic fires out of sync with the waystone pulse, and the caravan is dragged onto a false route."
        )

    if tier == "favorable":
        momentum_lines = [
            f"Your call to {label_core} at {scene_title} lands cleanly, and your side moves with real momentum.",
            f"{scene_title} breaks in your favor after you {label_core}, giving you room to press the advantage.",
            f"You {label_core} at {scene_title}, and this time the field bends your way.",
        ]
        return _stable_pick(momentum_lines, f"{scene_id}:{choice}:{tier}:favorable")

    if tier == "neutral":
        complication_by_beat = {
            "travel": f"you make distance, but the line around {focus_label} is still unstable",
            "exploration": f"you gain ground, but hazards around {focus_label} are still live",
            "mystery": f"you gain a clue, but the picture around {focus_label} is still incomplete",
            "social": f"you keep talks alive, but trust remains thin",
            "combat": f"you hold the line, but the exchange is not finished",
            "revelation": f"you uncover the truth, but fallout starts immediately",
            "recovery": "you steady the group, but not enough to call it secure",
        }
        complication = complication_by_beat.get(beat_type, "you move forward, but unfinished trouble follows")
        return f"You {label_core} at {scene_title}, and it only partly works: {complication}."

    # Negative tier.
    if choice == "explore":
        return (
            f"You push ahead at {scene_title}, but {danger}."
        )
    if choice == "investigate":
        return (
            f"While you {label_core} at {scene_title}, {danger}."
        )
    if choice == "talk":
        return (
            f"You try to {label_core} at {scene_title}, and {danger}."
        )
    if choice in {"attack", "defend"}:
        return (
            f"You commit hard at {scene_title}, but {danger}."
        )
    return f"You {label_core} at {scene_title}, and {danger}."


def _extract_followup_focus(scene_spec: SceneSpec, choice_label: str) -> str:
    text_vars = scene_spec.get("text_vars", {})
    if isinstance(text_vars, dict):
        active_entity = text_vars.get("active_entity")
        if isinstance(active_entity, str):
            normalized = active_entity.strip().lower().replace(" ", "_")
            if normalized in _FOLLOWUP_ALLOWED_TAGS:
                return normalized

    metadata = scene_spec.get("metadata", {})
    if isinstance(metadata, dict):
        active_entity = metadata.get("active_entity")
        if isinstance(active_entity, str):
            normalized = active_entity.strip().lower().replace(" ", "_")
            if normalized in _FOLLOWUP_ALLOWED_TAGS:
                return normalized

    keywords = (
        "vault",
        "gate",
        "waystone",
        "route",
        "path",
        "trail",
        "convoy",
        "caravan",
        "shrine",
        "archive",
        "market",
        "catacombs",
        "tunnel",
        "oracle",
        "siege",
        "raid",
        "spy",
        "courier",
        "rebel",
        "beacon",
        "ledger",
    )
    searchable = " ".join(
        [
            str(scene_spec.get("scene_id", "")).lower(),
            str(scene_spec.get("title", "")).lower(),
            choice_label.lower(),
        ]
    )
    for keyword in keywords:
        if keyword in searchable:
            return keyword
    return ""


def _outcome_location_id(scene_spec: SceneSpec, outcome: Outcome) -> str:
    location_id = scene_spec.get("location_id", "")
    player_patch = outcome.get("player", {})
    if isinstance(player_patch, dict):
        patched_location = player_patch.get("location_id")
        if isinstance(patched_location, str) and patched_location:
            location_id = patched_location
    return str(location_id)


def _stable_pick(options: list[str], seed: str) -> str:
    if not options:
        return ""
    idx = sum(ord(ch) for ch in seed) % len(options)
    return options[idx]


def _evolve_followup_focus(
    *,
    state: Any,
    scene_spec: SceneSpec,
    choice: ActionType,
    beat_type: str,
    tier: ResolutionTier,
    depth: int,
    next_location_id: str,
    current_focus: str,
) -> str:
    # Keep early follow-ups anchored to the same motif so the story feels
    # contiguous instead of introducing unrelated nouns immediately.
    if current_focus and depth <= 2:
        return current_focus

    location_candidates: list[str] = []
    for token in _LOCATION_FOCUS_SEEDS.get(next_location_id, ()):
        if token in _FOLLOWUP_ALLOWED_TAGS and token not in location_candidates:
            location_candidates.append(token)

    if location_candidates:
        preferred_location = [token for token in location_candidates if token != current_focus]
        concrete_location = [
            token for token in preferred_location if token not in {"route", "path", "trail"}
        ]
        if concrete_location:
            preferred_location = concrete_location
        if depth >= 3:
            preferred_location = [token for token in preferred_location if token != "waystone"] or preferred_location
        if preferred_location:
            seed = (
                f"loc:{next_location_id}:"
                f"{scene_spec.get('scene_id', '')}:"
                f"{choice}:"
                f"{tier}:"
                f"{depth}:"
                f"{getattr(getattr(state, 'narrative', object()), 'turn_index', 0)}"
            )
            return _stable_pick(preferred_location, seed)

    candidates: list[str] = []

    choice_candidates = _CHOICE_FOCUS_SEEDS.get(choice, ())
    for token in choice_candidates:
        if token in _FOLLOWUP_ALLOWED_TAGS and token not in candidates:
            candidates.append(token)

    beat_candidates: dict[str, tuple[str, ...]] = {
        "travel": ("path", "trail", "route"),
        "exploration": ("tunnel", "catacombs", "trail"),
        "mystery": ("oracle", "archive", "ledger"),
        "social": ("courier", "market", "spy"),
        "combat": ("gate", "siege", "rebel"),
        "recovery": ("shrine", "beacon", "path"),
        "revelation": ("oracle", "beacon", "vault"),
    }
    for token in beat_candidates.get(beat_type, ()):
        if token in _FOLLOWUP_ALLOWED_TAGS and token not in candidates:
            candidates.append(token)

    if tier == "negative":
        for token in ("shrine", "path"):
            if token in _FOLLOWUP_ALLOWED_TAGS and token not in candidates:
                candidates.append(token)

    filtered = [token for token in candidates if token != current_focus]
    if depth >= 3:
        filtered = [token for token in filtered if token != "waystone"] or filtered

    if filtered:
        seed = (
            f"{scene_spec.get('scene_id', '')}:"
            f"{choice}:"
            f"{tier}:"
            f"{depth}:"
            f"{next_location_id}:"
            f"{getattr(getattr(state, 'narrative', object()), 'turn_index', 0)}"
        )
        return _stable_pick(filtered, seed)

    if current_focus:
        return current_focus
    if next_location_id in _LOCATION_FOCUS_SEEDS:
        return _LOCATION_FOCUS_SEEDS[next_location_id][0]
    return "route"


def _pick_neighbor_location(state: Any, seed_key: str) -> str:
    world_facts = getattr(state, "world_facts", {})
    if not isinstance(world_facts, dict):
        return ""

    neighbors_map = world_facts.get("location_neighbors", {})
    if not isinstance(neighbors_map, dict):
        return ""

    current_location = str(getattr(getattr(state, "player", object()), "location_id", ""))
    neighbors_raw = neighbors_map.get(current_location, [])
    if not isinstance(neighbors_raw, list):
        return ""

    neighbors = [neighbor for neighbor in neighbors_raw if isinstance(neighbor, str) and neighbor]
    if not neighbors:
        return ""

    visited = getattr(state, "visited_locations", [])
    visited_set = set(visited) if isinstance(visited, list) else set()

    # Prefer exploratory movement by ranking neighbors with unseen frontier first.
    scored_neighbors: list[tuple[int, str]] = []
    for neighbor in neighbors:
        neighbor_neighbors_raw = neighbors_map.get(neighbor, [])
        if not isinstance(neighbor_neighbors_raw, list):
            neighbor_neighbors_raw = []
        neighbor_neighbors = [
            entry
            for entry in neighbor_neighbors_raw
            if isinstance(entry, str) and entry
        ]
        frontier_unseen = sum(1 for entry in neighbor_neighbors if entry not in visited_set)
        unseen_bonus = 100 if neighbor not in visited_set else 0
        score = unseen_bonus + frontier_unseen
        scored_neighbors.append((score, neighbor))

    if scored_neighbors:
        best_score = max(score for score, _ in scored_neighbors)
        best = [neighbor for score, neighbor in scored_neighbors if score == best_score]
        if len(best) == 1:
            return best[0]
        index = sum(ord(ch) for ch in seed_key) % len(best)
        return best[index]

    index = sum(ord(ch) for ch in seed_key) % len(neighbors)
    return neighbors[index]


def resolve_choice(
    state: Any,
    scene_spec: SceneSpec,
    choice: ActionType,
) -> tuple[Outcome, Observation]:
    """Resolve a player choice into state deltas and player-model observation.

    Each choice uses a three-way roll and returns one of three tiers:
    - favorable
    - neutral
    - negative
    """
    validate_scene_spec(scene_spec)

    choices = scene_spec["choices"]
    if choice not in choices:
        raise ValueError(f"choice {choice!r} is not available in this scene")

    beat_type = scene_spec["beat_type"]
    difficulty = float(scene_spec.get("difficulty", 0.5))

    base_risk = scene_spec.get("base_risk", {})
    risk = (
        float(base_risk.get(choice, _default_risk(choice)))
        if isinstance(base_risk, dict)
        else _default_risk(choice)
    )
    risk = _clamp(risk, 0.0, 1.0)

    health = getattr(getattr(state, "player", object()), "health", 75)

    world_facts_in_state = getattr(state, "world_facts", {})
    if not isinstance(world_facts_in_state, dict):
        world_facts_in_state = {}
    current_location_id = str(getattr(getattr(state, "player", object()), "location_id", ""))
   # --- UPDATED LOGIC ---
    scene_metadata = scene_spec.get("metadata", {})
    
    # 1. Try to get the true entity from the current scene being resolved
    current_active_entity = scene_metadata.get("active_entity")
    
    # 2. Fallback to world_facts only if the scene didn't provide one
    if not current_active_entity:
        current_active_entity = world_facts_in_state.get("active_entity")
        
    if not isinstance(current_active_entity, str):
        current_active_entity = ""
    current_active_entity = current_active_entity.strip().lower()
    # ---------------------
    if not isinstance(current_active_entity, str):
        current_active_entity = ""
    current_active_entity = current_active_entity.strip().lower()

    current_entity_location = world_facts_in_state.get("active_entity_location")
    if not isinstance(current_entity_location, str):
        current_entity_location = ""

    current_chapter_raw = world_facts_in_state.get("current_chapter", 0)
    current_chapter = int(current_chapter_raw) if isinstance(current_chapter_raw, (int, float)) else 0

    current_max_chapters_raw = world_facts_in_state.get("max_chapters", 0)
    current_max_chapters = (
        int(current_max_chapters_raw) if isinstance(current_max_chapters_raw, (int, float)) else 0
    )
    style_key_map: dict[ActionType, str] = {
        "attack": "aggressive",
        "defend": "defensive",
        "talk": "diplomatic",
        "investigate": "inquisitive",
        "explore": "adventurous",
        "use_item": "resourceful",
        "retreat": "cautious",
        "wait": "patient",
    }

    roll_value = _weighted_three_way_roll()
    tier = _resolve_three_way_tier(roll_value)

    effects = scene_spec.get("effects", {})
    effect_for_choice = effects.get(choice, {}) if isinstance(effects, dict) else {}
    if not isinstance(effect_for_choice, dict):
        effect_for_choice = {}

    outcome: Outcome = {
        "resolution_tier": tier,
        "world_facts": {
            "last_choice": choice,
            "last_choice_style": style_key_map[choice],
            "last_scene_id": scene_spec["scene_id"],
            "last_beat_type": beat_type,
            "last_resolution_tier": tier,
            "last_roll_value": roll_value,
            "last_roll_kind": "three_way",
            "last_success": (tier == "favorable") if tier != "neutral" else None,
            f"choice_count_{choice}": int(world_facts_in_state.get(f"choice_count_{choice}", 0)) + 1,
        },
        "metadata": {
            "scene_id": scene_spec["scene_id"],
            "choice": choice,
            "resolution_tier": tier,
            "roll_kind": "three_way",
            "roll_value": roll_value,
            "difficulty": round(difficulty, 4),
            "risk": round(risk, 4),
        },
        "events": [
            {
                "type": "choice_roll_resolved",
                "scene_id": scene_spec["scene_id"],
                "choice": choice,
                "resolution_tier": tier,
                "roll_kind": "three_way",
                "roll_value": roll_value,
            }
        ],
    }

    if tier == "favorable":
        outcome["success"] = True
        _merge_outcomes(outcome, {"world_facts": {"recent_momentum": "positive", "need_recovery": False}})
        _merge_outcomes(
            outcome,
            {"difficulty_signal": (0.25 + difficulty * 0.75)},
        )
    elif tier == "negative":
        outcome["success"] = False
        _merge_outcomes(outcome, {"world_facts": {"recent_momentum": "negative", "need_recovery": True}})
        _merge_outcomes(
            outcome,
            {"difficulty_signal": -(0.25 + difficulty * 0.75)},
        )
    else:
        _merge_outcomes(outcome, {"world_facts": {"recent_momentum": "mixed", "need_recovery": False}})
        _merge_outcomes(outcome, {"difficulty_signal": 0.0})

    health_delta = _default_health_delta(tier, choice, difficulty, risk)
    if health_delta != 0:
        _merge_outcomes(outcome, {"player": {"health_delta": health_delta}})

    _merge_outcomes(outcome, {"tension_delta": _default_tension_delta(tier, beat_type)})

    thread_progress_delta = _default_thread_progress_delta(tier)
    _merge_outcomes(
        outcome,
        {
            "plot_threads": [
                {"thread_id": thread_id, "progress_delta": thread_progress_delta}
                for thread_id in scene_spec.get("thread_ids", [])
            ]
        },
    )

    _merge_outcomes(outcome, _tier_effect_patch(effect_for_choice, tier))

    if health < 70:
        player_patch = outcome.get("player", {})
        if isinstance(player_patch, dict):
            health_delta_raw = player_patch.get("health_delta")
            if isinstance(health_delta_raw, (int, float)) and float(health_delta_raw) < 0.0:
                scaled_delta = int(round(float(health_delta_raw) * _low_health_damage_scale(int(health))))
                if scaled_delta == 0:
                    scaled_delta = -1
                player_patch["health_delta"] = scaled_delta

        tension_delta_raw = outcome.get("tension_delta")
        if isinstance(tension_delta_raw, (int, float)) and float(tension_delta_raw) > 0.0:
            outcome["tension_delta"] = round(
                float(tension_delta_raw) * _low_health_tension_scale(int(health)),
                4,
            )

    choice_tags_map = scene_spec.get("choice_tags", {})
    choice_tags = choice_tags_map.get(choice, []) if isinstance(choice_tags_map, dict) else []
    clean_choice_tags = [tag for tag in choice_tags if isinstance(tag, str)]

    choice_text_map = scene_spec.get("choice_text", {})
    choice_label = (
        str(choice_text_map.get(choice))
        if isinstance(choice_text_map, dict) and isinstance(choice_text_map.get(choice), str)
        else choice.replace("_", " ")
    )
    scene_title = str(scene_spec.get("title", scene_spec["scene_id"]))

    current_turn = int(getattr(getattr(state, "narrative", object()), "turn_index", 0))
    followup_tags = _followup_required_tags(
        choice=choice,
        tier=tier,
        choice_tags=clean_choice_tags,
    )
    followup_primary_tag = followup_tags[0] if followup_tags else ""
    followup_thread_ids = [
        thread_id
        for thread_id in scene_spec.get("thread_ids", [])
        if isinstance(thread_id, str) and thread_id
    ]
    followup_focus = _extract_followup_focus(scene_spec, choice_label)
    source_focus = followup_focus or current_active_entity

    scene_metadata = scene_spec.get("metadata", {})
    generated_followup = bool(scene_metadata.get("generated_followup", False)) if isinstance(scene_metadata, dict) else False
    questline_location = ""
    questline_name = ""
    questline_chapter = 0
    questline_total_chapters = 0
    if isinstance(scene_metadata, dict):
        raw_questline_location = scene_metadata.get("questline_location")
        if isinstance(raw_questline_location, str):
            questline_location = raw_questline_location.strip()

        raw_questline_name = scene_metadata.get("questline_name")
        if isinstance(raw_questline_name, str):
            questline_name = raw_questline_name.strip()

        raw_questline_chapter = scene_metadata.get("questline_chapter")
        if isinstance(raw_questline_chapter, (int, float)) and not isinstance(raw_questline_chapter, bool):
            questline_chapter = max(0, int(raw_questline_chapter))

        raw_questline_total = scene_metadata.get("questline_total_chapters")
        if isinstance(raw_questline_total, (int, float)) and not isinstance(raw_questline_total, bool):
            questline_total_chapters = max(0, int(raw_questline_total))

    questline_active = (
        generated_followup
        and bool(questline_location)
        and questline_total_chapters > 0
    )

    prev_followup_depth_raw = world_facts_in_state.get("followup_depth", 0)
    prev_followup_depth = int(prev_followup_depth_raw) if isinstance(prev_followup_depth_raw, (int, float)) else 0
    prev_followup_mode = world_facts_in_state.get("followup_mode")
    if not isinstance(prev_followup_mode, str):
        prev_followup_mode = "catalog"

    prev_chain_id = world_facts_in_state.get("followup_chain_id")
    if not isinstance(prev_chain_id, str):
        prev_chain_id = ""

    prev_branch_signature = world_facts_in_state.get("followup_branch_signature")
    if not isinstance(prev_branch_signature, str):
        prev_branch_signature = ""

    prev_root_scene = world_facts_in_state.get("followup_root_scene")
    if not isinstance(prev_root_scene, str):
        prev_root_scene = ""

    if generated_followup and not followup_focus:
        existing_focus = world_facts_in_state.get("followup_focus")
        if isinstance(existing_focus, str) and existing_focus:
            followup_focus = existing_focus.strip().lower()

    if generated_followup and prev_root_scene:
        root_scene = prev_root_scene
    else:
        root_scene = scene_spec["scene_id"]

    next_mode = "dynamic"
    provisional_depth = (
        prev_followup_depth + 1
        if (generated_followup and prev_followup_mode == "dynamic")
        else 1
    )

    movement_beats = {"travel", "exploration", "mystery", "social", "revelation"}
    movement_choices = {"explore", "investigate", "retreat", "talk"}
    movement_tier_ok = tier in {"favorable", "neutral"} or (
        tier == "negative" and choice in {"retreat", "wait"} and provisional_depth >= 3
    )
    should_shift_location = (
        generated_followup
        and not questline_active
        and provisional_depth >= 2
        and (beat_type in movement_beats or choice in movement_choices)
        and movement_tier_ok
    )
    if should_shift_location:
        next_location = _pick_neighbor_location(
            state,
            seed_key=f"{scene_spec['scene_id']}:{choice}:{tier}:{current_turn}",
        )
        if next_location:
            _merge_outcomes(
                outcome,
                {
                    "player": {"location_id": next_location},
                    "world_facts": {"route_transition_target": next_location},
                },
            )

    next_location_id = _outcome_location_id(scene_spec, outcome)
    location_transition = bool(next_location_id and next_location_id != current_location_id)
    chapter_transition = bool(
        questline_chapter > 0
        and questline_chapter != current_chapter
    )

# --- FIX 2: Only lock entities during generated followups ---
    active_entity_locked = False
    if generated_followup:
        if current_active_entity and not location_transition and not chapter_transition:
            # Keep noun/entity continuity inside a generated chapter/node until transition.
            followup_focus = current_active_entity
            active_entity_locked = True
        else:
            followup_focus = _evolve_followup_focus(
                state=state,
                scene_spec=scene_spec,
                choice=choice,
                beat_type=beat_type,
                tier=tier,
                depth=provisional_depth,
                next_location_id=next_location_id,
                current_focus=source_focus,
            )
    else:
        # For base authored encounters, the scene's natural focus takes precedence.
        # We break the old lock and adopt the new encounter's focus.
        followup_focus = source_focus

    if not followup_focus:
        followup_focus = current_active_entity or "route"
    # ------------------------------------------------------------

    if generated_followup:
        if questline_active:
            if questline_chapter < questline_total_chapters:
                next_mode = "dynamic"
            else:
                next_mode = "catalog"
        elif provisional_depth < 4:
            next_mode = "dynamic"
        elif (
            tier == "favorable"
            and choice in {"investigate", "retreat", "talk", "wait", "use_item", "defend"}
        ) or (provisional_depth >= 6 and tier != "negative"):
            next_mode = "catalog"
        elif tier == "neutral" and choice in {"retreat", "wait"} and provisional_depth >= 5:
            next_mode = "catalog"
    else:
        if tier == "favorable" and choice in {"wait", "talk"}:
            next_mode = "catalog"
        elif choice == "retreat" and tier in {"favorable", "neutral"}:
            next_mode = "catalog"

    scene_blocklist = world_facts_in_state.get("scene_blocklist", {})
    if not isinstance(scene_blocklist, dict):
        scene_blocklist = {}
    else:
        scene_blocklist = {
            key: value
            for key, value in scene_blocklist.items()
            if isinstance(key, str) and isinstance(value, int) and value >= current_turn
        }

    if next_mode == "catalog" and generated_followup:
        block_until = current_turn + 3
        for blocked_scene_id in {scene_spec["scene_id"], root_scene}:
            if not blocked_scene_id:
                continue
            existing = scene_blocklist.get(blocked_scene_id)
            if isinstance(existing, int):
                scene_blocklist[blocked_scene_id] = max(existing, block_until)
            else:
                scene_blocklist[blocked_scene_id] = block_until

    if next_mode == "dynamic":
        next_depth = provisional_depth
        if generated_followup and prev_chain_id:
            chain_id = prev_chain_id
        else:
            chain_id = f"{scene_spec['scene_id']}:{current_turn}:{choice}"
        step_signature = f"{choice}:{tier}"
        if generated_followup and prev_branch_signature:
            branch_signature = f"{prev_branch_signature}>{step_signature}"
        else:
            branch_signature = step_signature
        if len(branch_signature) > 180:
            branch_signature = branch_signature[-180:]
    else:
        next_depth = 0
        chain_id = ""
        branch_signature = ""

    story_bundle = _outcome_story_bundle(
        choice=choice,
        choice_label=choice_label,
        scene_title=scene_title,
        tier=tier,
        beat_type=beat_type,
        focus=followup_focus,
        location_id=str(scene_spec.get("location_id", "")),
        scene_id=scene_spec["scene_id"],
    )

    resolved_chapter = questline_chapter if questline_chapter > 0 else current_chapter
    resolved_max_chapters = (
        questline_total_chapters if questline_total_chapters > 0 else current_max_chapters
    )
    if next_mode == "dynamic":
        is_in_narrative_chain = True
    elif resolved_max_chapters > 0 and resolved_chapter > 0 and resolved_chapter < resolved_max_chapters:
        is_in_narrative_chain = True
    else:
        is_in_narrative_chain = False

    if location_transition:
        node_type = "transition"
    elif next_mode == "dynamic":
        node_type = "chapter"
    else:
        node_type = "hub"

    active_entity_location = next_location_id or current_location_id or current_entity_location

    _merge_outcomes(
        outcome,
        {
            "world_facts": {
                "followup_turn": current_turn + 1,
                "followup_required_tags": followup_tags,
                "followup_primary_tag": followup_primary_tag,
                "followup_required_location": next_location_id,
                "followup_required_thread_ids": followup_thread_ids,
                "followup_focus": followup_focus,
                "followup_source_entity": source_focus or followup_focus,
                "followup_mode": next_mode,
                "followup_depth": next_depth,
                "followup_chain_id": chain_id,
                "followup_branch_signature": branch_signature,
                "followup_root_scene": root_scene,
                "scene_blocklist": scene_blocklist,
                "followup_narrative": story_bundle["continuity"],
                "followup_story_opening": story_bundle["opening"],
                "followup_story_consequence": story_bundle["consequence"],
                "followup_story_aftermath": story_bundle["aftermath"],
                "followup_branch_hook": story_bundle["branch_hook"],
                "followup_branch_goal": story_bundle["branch_goal"],
                "followup_source_scene": scene_spec["scene_id"],
                "followup_source_choice": choice,
                "followup_source_tier": tier,
                "questline_location": questline_location,
                "questline_name": questline_name,
                "questline_chapter": questline_chapter,
                "questline_total_chapters": questline_total_chapters,
                "followup_previous_location": current_location_id,
                "followup_player_action": choice,
                "followup_player_action_label": choice_label,
                "followup_resolution_tier": tier,
                "followup_roll_value": roll_value,
                "followup_dda_event": story_bundle["consequence"],
                "active_entity": followup_focus,
                "active_entity_locked": active_entity_locked,
                "active_entity_location": active_entity_location,
                "active_entity_chapter": resolved_chapter,
                "current_chapter": resolved_chapter,
                "max_chapters": resolved_max_chapters,
                "is_in_narrative_chain": is_in_narrative_chain,
                "node_type": node_type,
            }
        },
    )

    aggression_signal = 1.0 if choice in {"attack"} else 0.2
    if "aggressive" in choice_tags:
        aggression_signal = max(aggression_signal, 0.9)

    social_intent = 1.0 if choice == "talk" else 0.2
    if "social" in choice_tags:
        social_intent = max(social_intent, 0.85)

    exploration_intent = 1.0 if choice in {"explore", "investigate"} else 0.2
    if "exploration" in choice_tags:
        exploration_intent = max(exploration_intent, 0.85)

    observation: Observation = {
        "choice": choice,
        "choice_tags": clean_choice_tags,
        "risk_level": round(risk, 4),
        "social_intent": round(_clamp(social_intent, 0.0, 1.0), 4),
        "exploration_intent": round(_clamp(exploration_intent, 0.0, 1.0), 4),
        "aggression_signal": round(_clamp(aggression_signal, 0.0, 1.0), 4),
        "beat_type": beat_type,
        "resolution_tier": tier,
        "metadata": {
            "scene_id": scene_spec["scene_id"],
            "difficulty": difficulty,
            "roll_kind": "three_way",
            "roll_value": roll_value,
        },
    }

    if tier == "favorable":
        observation["success"] = True
        observation["failure"] = False
    elif tier == "negative":
        observation["success"] = False
        observation["failure"] = True

    validate_outcome(outcome)
    validate_observation(observation)
    return outcome, observation
