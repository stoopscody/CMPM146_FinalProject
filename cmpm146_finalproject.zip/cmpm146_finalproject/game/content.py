"""Read-only content database for authored JSON story assets."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ContentDB:
    """Read-only content access layer used by AI policy and scene rendering.

    This class loads authored JSON once, validates high-level schema shape, and
    exposes lookup/listing helpers. The DB is intentionally read-only at runtime
    so content selection logic cannot accidentally mutate source content.
    """

    def __init__(self, content_dir: str = "content") -> None:
        """Load content JSON files and build lookup indexes.

        Args:
            content_dir: Directory containing encounters/locations/NPC/items/
                templates/thread JSON files.
        """
        requested_path = Path(content_dir)
        if requested_path.is_absolute():
            resolved_content_dir = requested_path
        else:
            cwd_candidate = Path.cwd() / requested_path
            module_candidate = Path(__file__).resolve().parent.parent / requested_path
            if cwd_candidate.exists():
                resolved_content_dir = cwd_candidate
            else:
                resolved_content_dir = module_candidate

        self.content_dir = resolved_content_dir
        self._encounters = self._load_json("encounters.json", list)
        self._locations_raw = self._load_json("locations.json", list)
        self._npcs_raw = self._load_json("npcs.json", list)
        self._items_raw = self._load_json("items.json", list)
        self._templates = self._load_json("templates.json", dict)
        self._threads = self._load_json("threads.json", list)

        self._locations: dict[str, dict[str, Any]] = {}
        self._npcs: dict[str, dict[str, Any]] = {}
        self._items: dict[str, dict[str, Any]] = {}

        self._validate_and_index_locations()
        self._validate_and_index_npcs()
        self._validate_and_index_items()
        self._validate_and_index_threads()
        self._validate_encounters()
        self._validate_templates()

    def _load_json(self, filename: str, expected_type: type) -> Any:
        file_path = self.content_dir / filename
        if not file_path.exists():
            raise FileNotFoundError(f"Missing content file: {file_path}")

        try:
            with file_path.open("r", encoding="utf-8") as handle:
                value = json.load(handle)
        except json.JSONDecodeError as exc:
            raise ValueError(f"Invalid JSON in {file_path}: {exc}") from exc

        if not isinstance(value, expected_type):
            expected_name = expected_type.__name__
            raise TypeError(f"{file_path} must contain a top-level {expected_name}")
        return value

    def _validate_and_index_locations(self) -> None:
        for idx, location in enumerate(self._locations_raw):
            if not isinstance(location, dict):
                raise TypeError(f"locations[{idx}] must be a dict")
            location_id = location.get("id")
            name = location.get("name")
            if not isinstance(location_id, str) or not location_id:
                raise ValueError(f"locations[{idx}] missing non-empty 'id'")
            if not isinstance(name, str) or not name:
                raise ValueError(f"locations[{idx}] missing non-empty 'name'")
            if location_id in self._locations:
                raise ValueError(f"Duplicate location id: {location_id!r}")
            self._locations[location_id] = dict(location)

    def _validate_and_index_npcs(self) -> None:
        for idx, npc in enumerate(self._npcs_raw):
            if not isinstance(npc, dict):
                raise TypeError(f"npcs[{idx}] must be a dict")
            npc_id = npc.get("id")
            name = npc.get("name")
            if not isinstance(npc_id, str) or not npc_id:
                raise ValueError(f"npcs[{idx}] missing non-empty 'id'")
            if not isinstance(name, str) or not name:
                raise ValueError(f"npcs[{idx}] missing non-empty 'name'")
            if npc_id in self._npcs:
                raise ValueError(f"Duplicate npc id: {npc_id!r}")
            self._npcs[npc_id] = dict(npc)

    def _validate_and_index_items(self) -> None:
        for idx, item in enumerate(self._items_raw):
            if not isinstance(item, dict):
                raise TypeError(f"items[{idx}] must be a dict")
            item_id = item.get("id")
            name = item.get("name")
            if not isinstance(item_id, str) or not item_id:
                raise ValueError(f"items[{idx}] missing non-empty 'id'")
            if not isinstance(name, str) or not name:
                raise ValueError(f"items[{idx}] missing non-empty 'name'")
            if item_id in self._items:
                raise ValueError(f"Duplicate item id: {item_id!r}")
            self._items[item_id] = dict(item)

    def _validate_and_index_threads(self) -> None:
        seen_thread_ids: set[str] = set()
        for idx, thread in enumerate(self._threads):
            if not isinstance(thread, dict):
                raise TypeError(f"threads[{idx}] must be a dict")
            thread_id = thread.get("id")
            title = thread.get("title")
            if not isinstance(thread_id, str) or not thread_id:
                raise ValueError(f"threads[{idx}] missing non-empty 'id'")
            if not isinstance(title, str) or not title:
                raise ValueError(f"threads[{idx}] missing non-empty 'title'")
            if thread_id in seen_thread_ids:
                raise ValueError(f"Duplicate thread id: {thread_id!r}")
            seen_thread_ids.add(thread_id)

    def _validate_encounters(self) -> None:
        valid_location_ids = set(self._locations)
        valid_template_ids = set(self._templates)
        for idx, encounter in enumerate(self._encounters):
            if not isinstance(encounter, dict):
                raise TypeError(f"encounters[{idx}] must be a dict")

            encounter_id = encounter.get("id")
            if not isinstance(encounter_id, str) or not encounter_id:
                raise ValueError(f"encounters[{idx}] missing non-empty 'id'")

            template_id = encounter.get("template_id")
            if not isinstance(template_id, str) or not template_id:
                raise ValueError(f"encounters[{idx}] missing non-empty 'template_id'")
            if template_id not in valid_template_ids:
                raise ValueError(
                    f"encounters[{idx}] references unknown template_id: {template_id!r}"
                )

            beat_types = encounter.get("beat_types")
            if not isinstance(beat_types, list) or not beat_types:
                raise ValueError(f"encounters[{idx}] must contain non-empty 'beat_types'")

            difficulty = encounter.get("difficulty", 0.5)
            if not isinstance(difficulty, (int, float)):
                raise TypeError(f"encounters[{idx}]['difficulty'] must be numeric")

            location_ids = encounter.get("location_ids", [])
            if not isinstance(location_ids, list):
                raise TypeError(f"encounters[{idx}]['location_ids'] must be a list")
            for location_id in location_ids:
                if location_id != "*" and location_id not in valid_location_ids:
                    raise ValueError(
                        f"encounters[{idx}] references unknown location: {location_id!r}"
                    )

            choices = encounter.get("choices")
            if not isinstance(choices, list) or not choices:
                raise ValueError(f"encounters[{idx}] must define non-empty 'choices'")
            for action in choices:
                if not isinstance(action, str) or not action:
                    raise ValueError(f"encounters[{idx}] has invalid choice value: {action!r}")

            choice_text = encounter.get("choice_text")
            if not isinstance(choice_text, dict) or not choice_text:
                raise ValueError(f"encounters[{idx}] must define non-empty 'choice_text'")

    def _validate_templates(self) -> None:
        for key, value in self._templates.items():
            if not isinstance(key, str) or not key:
                raise ValueError("templates keys must be non-empty strings")
            if not isinstance(value, (str, dict, list)):
                raise TypeError(f"templates[{key!r}] must be str, dict, or list")

    def get_location(self, location_id: str) -> dict[str, Any]:
        """Return location definition by id."""
        if location_id not in self._locations:
            raise KeyError(f"Unknown location_id: {location_id!r}")
        return dict(self._locations[location_id])

    def list_encounters(self) -> list[dict[str, Any]]:
        """Return encounter candidates for DMPolicy filtering/scoring."""
        return [dict(encounter) for encounter in self._encounters]

    def list_templates(self) -> dict[str, Any]:
        """Return template map used by scene renderer."""
        return dict(self._templates)

    def list_threads(self) -> list[dict[str, Any]]:
        """Return authored plot-thread seeds."""
        return [dict(thread) for thread in self._threads]

    def list_locations(self) -> list[dict[str, Any]]:
        """Return all locations as read-only copies."""
        return [dict(location) for location in self._locations.values()]

    def list_npcs(self) -> list[dict[str, Any]]:
        """Return all NPC definitions as read-only copies."""
        return [dict(npc) for npc in self._npcs.values()]

    def list_items(self) -> list[dict[str, Any]]:
        """Return all item definitions as read-only copies."""
        return [dict(item) for item in self._items.values()]

    def get_npc(self, npc_id: str) -> dict[str, Any]:
        """Return NPC definition by id."""
        if npc_id not in self._npcs:
            raise KeyError(f"Unknown npc_id: {npc_id!r}")
        return dict(self._npcs[npc_id])
