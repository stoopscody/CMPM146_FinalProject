# Adaptive AI Dungeon Master

Adaptive AI Dungeon Master is a text-based RPG engine for AI coursework. It demonstrates:

- Player modeling with trait inference (EMA + confidence gating)
- Behavior-tree-style beat selection for pacing
- Utility-based encounter selection
- Dynamic Difficulty Adjustment (DDA)
- Optional GOAP planning support for NPC behavior
- Strict module boundaries using shared data contracts

## Project Structure

- `contracts.py`: Canonical payload types and validators
- `main.py`: Runtime loop (interactive and autoplay)
- `game/`
  - `content.py`: JSON loading and content schema validation
  - `state.py`: Authoritative mutable world state and outcome application
  - `scene.py`: Template rendering and action list extraction
  - `resolver.py`: Choice resolution into `Outcome` + `Observation`
  - `logger.py`: JSONL turn logging
- `ai/`
  - `player_model.py`: Trait inference and archetype labeling
  - `dda.py`: Rolling performance to difficulty target mapping
  - `dm_bt.py`: Beat selection based on pacing/tension/preferences
  - `dm_policy.py`: Utility-driven scene selection
  - `goap.py`: Forward-search GOAP planner
  - `npc_agent.py`: NPC intent and optional planning artifact
- `content/`: Authored world data (encounters, templates, locations, threads, NPCs)
- `logs/`: Run output (`.jsonl`)

## Data Contract Boundary Rules

- `DMPolicy` cannot mutate `GameState`.
- `PlayerModel` cannot mutate `GameState`.
- `resolver.resolve_choice(...)` returns deltas only.
- `GameState.apply_outcome(...)` is the only state mutation boundary.
- Validators enforce consistency at module boundaries:
  - `validate_scene_spec(...)`
  - `validate_observation(...)`
  - `validate_outcome(...)`

## Run

From project root (`FinalProject/cmpm146_finalproject`):

```bash
python main.py
```

Autoplay quick test:

```bash
python main.py --autoplay --turns 12 --seed 146
```

Optional args:

- `--turns N`: max turns
- `--seed N`: deterministic randomness
- `--autoplay`: no manual input
- `--log PATH`: explicit log path

## Log Output

Each turn writes one JSON object line containing:

- beat type
- selected scene spec
- rendered scene text
- selected player action
- outcome deltas
- player observation
- trait vector and archetype
- DDA scores
- compact state summary

## Notes

- Python 3.10+ required.
- No external dependencies required for core runtime.
- Content is designed to support dynamic multi-thread progression and repeat reduction via novelty penalties.
